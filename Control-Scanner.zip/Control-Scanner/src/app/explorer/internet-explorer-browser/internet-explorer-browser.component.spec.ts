import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InternetExplorerBrowserComponent } from './internet-explorer-browser.component';

describe('InternetExplorerBrowserComponent', () => {
  let component: InternetExplorerBrowserComponent;
  let fixture: ComponentFixture<InternetExplorerBrowserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InternetExplorerBrowserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InternetExplorerBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
