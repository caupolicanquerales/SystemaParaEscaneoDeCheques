import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import * as connect from 'src/app/jsFiles/controlScanner.js';
import { Observable,interval,Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import { DomSanitizer } from '@angular/platform-browser';
import { ListErrorScannerService } from 'src/app/service/list-error-scanner.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-internet-explorer-browser',
  templateUrl: './internet-explorer-browser.component.html',
  styleUrls: ['./internet-explorer-browser.component.css']
})
export class InternetExplorerBrowserComponent implements OnInit,OnDestroy {

  @Input() typeBrowser:boolean;

  title = 'Ambiente para escaneo';
  onConnected:string;
  serialNumber:string;
  stateTrack:string;
  exceptionInProgress:string;
  inter: Observable<any>;
  destroy$: Subject<boolean> = new Subject<boolean>();
  exception$: Subject<boolean> = new Subject<boolean>();
  imagenes:boolean;
  informationImages:Array<any>=[];
  etiquetaSistema:string;
  etiquetaEscaner:string;
  circleEscaner:boolean;
  circleSistema:boolean;
  serialEscaner:string;
  conectarEscaner:string;
  conectarSistema:string;
  titleImagenes:string;
  alerta:boolean;
  accion:string;
  error:string;
  private IDLE_STATE:string="2";
  private READY_STATE:string="4";
  private POWER_OFF_STATE:string="1";
  private EXCEPTION_STATE:string="6";
  private scanningFlag:boolean;
  private hopperEmpty:any;
  private flowStopped:any;
  private DISCONNECTED_SCANNER:string="ESCANER DESCONECTADO";
  private CONNECTED_SCANNER:string="ESCANER CONECTADO";
  private CONNECT_SCANNER_BUTTON:string="Iniciar Escaner";
  private SHUT_DOWN_SCANNER_BUTTON:string="Cerrar Escaner";
  private CONNECTING_SCANNER:string="CONECTANDO ESCANER";
  private SCANNING:string="ESCANEANDO";
  private LOADED_IMAGES:string="IMAGENES CARGADAS";
  private EMPTY_EXCEPTION:string="";
  private messageWarnigScanning:string="Conectar escaner";
  private messageExceptionScanning:string="Dispositivo en estado de excepción";
  private messageSuccessDeleteImage:string="Imagen eliminada";
  private messageSuccessDeleteAllImages:string="Imagenes eliminadas";

  constructor(private sanitizer: DomSanitizer,private errors:ListErrorScannerService,
    private toastr: ToastrService){
    this.onConnected="";
    this.serialNumber="";
    this.scanningFlag=false;
    this.imagenes=false;
    this.typeBrowser=true;
    this.circleEscaner=false;
    this.alerta=false;
    this.accion=this.EMPTY_EXCEPTION;
    this.titleImagenes='IMAGENES ESCANEADAS';
    this.informationImages=[];
    this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
    this.serialEscaner=this.EMPTY_EXCEPTION;
    this.conectarEscaner=this.CONNECT_SCANNER_BUTTON;
  }

  ngOnInit(){
    connect.initScanner();
  }
  ngOnDestroy(){
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
    this.exception$.next(true);
    this.exception$.unsubscribe();
  }
  
  connectingScanner(){
    if(this.conectarEscaner==this.CONNECT_SCANNER_BUTTON){
      this.alerta=false;
      this.setConnectionScanner();
    }else if(this.conditionShutdownScannerFromReadyState()){
      this.shutDownScannerFromReadyState();
    }else if(this.conditionShutdownScannerFromIdleState()){
      this.shutDownScannerFromIdleState();
    }
  }
  scanning(){
    let state=connect.getStateTrack().toString();
    if(state==this.IDLE_STATE){
      this.accion=this.SCANNING;
      connect.resetExceptionVariables();
      this.getVariablesInScanningProcess();
      connect.goReadyToProcess();
    }else if(state==this.READY_STATE){
      this.accion=this.SCANNING;
      connect.resetValueObjectScanner();
      this.getVariablesInScanningProcess();
    }else if(state==this.POWER_OFF_STATE){
      this.warningMessage(this.messageWarnigScanning);
    }else if(state==this.EXCEPTION_STATE){
      this.warningMessage(this.messageExceptionScanning);
    }
  }

  private setConnectionScanner(){
    this.accion=this.CONNECTING_SCANNER;
    const result= this.getIntervalObservable();
    connect.powerUp();
    result.subscribe(()=>connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionShutDownIntervalConnection(response);
    }));
  }

  private getVariablesInReadyState(){
    const result= this.getIntervalObservable();
    result.subscribe(()=>connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionShutDownIntervalReadyState();
    }));
  }
  private getVariablesInScanningProcess(){
    const result= this.getIntervalObservable();
    result.subscribe(()=>connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionStartScanning();
      this.conditionShutDownIntervalScanning(response);
    }));
  }
  private getVariablesInShutdownProcessInException(){
    const result= this.getIntervalObservableForException();
    connect.flowStop();
    let flagReadyState=false;
    let flagIdleState=false;
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.READY_STATE && flagReadyState==false){
        flagReadyState=true;
        connect.goIdle();
      }else if(response.toString()==this.IDLE_STATE && flagIdleState==false){
        flagIdleState=true;
        connect.powerDown();
      }else if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private shutDownScannerFromReadyState(){
    const result= this.getIntervalObservableForException();
    connect.goIdle();
    let flagIdleState=false;
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.IDLE_STATE && flagIdleState==false){
        flagIdleState=true;
        connect.powerDown();
      }else if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.alerta=false;
        this.accion=this.EMPTY_EXCEPTION;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private shutDownScannerFromIdleState(){
    const result= this.getIntervalObservableForException();
    connect.powerDown();
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.alerta=false;
        this.accion=this.EMPTY_EXCEPTION;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private setShutdownScannerVariables(response){
    this.exception$.next(true);
    this.circleEscaner=false;
    this.conectarEscaner=this.CONNECT_SCANNER_BUTTON;
    this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
    this.imagenes=false;
    this.getVariablesObjectOfScannerControl(response);
  } 
  private getIntervalObservable(){
    this.destroy$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.destroy$));
    return result;
  }
  private getIntervalObservableForException(){
    this.exception$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.exception$));
    return result;
  }
  private conditionShutDownIntervalConnection(response){
    if(this.conditionConnected() && this.conditionSerialNumber()){
      this.destroy$.next(true);
      this.circleEscaner=true;
      this.conectarEscaner=this.SHUT_DOWN_SCANNER_BUTTON;
      this.etiquetaEscaner=this.CONNECTED_SCANNER;
      this.accion=this.EMPTY_EXCEPTION;
      this.getVariablesObjectOfScannerControl(response);
    }else if(this.conditionExceptionConnectingScanner()){
      this.destroy$.next(true);
      this.getAlarmActive();
    }
  }

  private conditionShutDownIntervalReadyState(){
    if(this.conditionConnected() && this.stateTrack==this.READY_STATE){
      this.destroy$.next(true);
    }
  }

  private conditionShutDownIntervalScanning(response){
    if(this.conditionIntervalScanning() && this.scanningFlag==true){
      this.destroy$.next(true);
      let information=[];
      information.push(connect.getGeneralResultScanning());
      information=information.filter(value=>Object.keys(value).length!==0);
      this.informationImages=information[0];
      this.imagenes=true;
      this.scanningFlag=false;
      this.accion=this.LOADED_IMAGES;
      this.getVariablesObjectOfScannerControl(response);
      this.getAlarmActive();
    }
  }
  private getAlarmActive(){
    if(this.conditionExceptionInProgress()){
      this.alerta=true;
      this.accion=this.EMPTY_EXCEPTION;
      this.error=this.getErrorMessage(this.exceptionInProgress);
      this.getVariablesInShutdownProcessInException();
    }
  }
  private conditionIntervalScanning(){
    return (this.conditionConnected() && this.conditionHopperFlowStopped()) || this.conditionExceptionInProgress();
  }
  private conditionHopperFlowStopped(){
    return (this.hopperEmpty && this.hopperEmpty!="") || (this.flowStopped && this.flowStopped!="")
  }
  private conditionConnected(){
    return this.onConnected && this.onConnected!="";
  }
  private conditionSerialNumber(){
    return this.serialEscaner  && this.serialEscaner!="";
  }
  private conditionExceptionInProgress(){
    return this.exceptionInProgress && this.exceptionInProgress!="";
  }
  private conditionExceptionConnectingScanner(){
    let state=connect.getStateTrack().toString();
    return !this.conditionSerialNumber() && this.conditionExceptionInProgress() && state==this.EXCEPTION_STATE;
  }
  private conditionShutdownScannerFromReadyState(){
    let state=connect.getStateTrack().toString();
    return this.conectarEscaner==this.SHUT_DOWN_SCANNER_BUTTON && state==this.READY_STATE;
  }
  private conditionShutdownScannerFromIdleState(){
    let state=connect.getStateTrack().toString();
    return this.conectarEscaner==this.SHUT_DOWN_SCANNER_BUTTON && state==this.IDLE_STATE;
  }
  private conditionStartScanning(){
    if(this.conditionConnected() && this.stateTrack==this.READY_STATE && this.scanningFlag==false){
      this.scanningFlag=true;
      connect.flowStart();
    }
  }
  private getVariablesObjectOfScannerControl(response){
    this.onConnected=response["OnConnected"];
    this.stateTrack=response["tTrackState"];
    this.hopperEmpty=response["OnHopperEmpty"];
    this.flowStopped=response["OnFlowStopped"];
    this.serialEscaner=response["tSerialNumber0"];
    this.exceptionInProgress=response["OnExceptionInProgress"];    
  }
  private getErrorMessage(errorCode:string){
    return this.errors.getErrorMessage(errorCode);
  }
  
  private warningMessage(message){
    this.toastr.warning(message,"Precaucion",{timeOut:2000,});
  }
  private successMessage(message){
    this.toastr.success(message,"Operación exitosa",{timeOut:2000,});
  }
  private informationMessage(message){
    this.toastr.info(message,"Mensaje de información",{timeOut:2000,});
  }

  getImage(imageBase64){
    return this.sanitizer.bypassSecurityTrustResourceUrl('data:image/png;base64,'+imageBase64);
  }
  deleteImageSelected(idDoc){
    this.informationImages=this.informationImages.filter(image=>image.idDoc!=idDoc);
    this.successMessage(this.messageSuccessDeleteImage);
  }
  deleteAllImages(){
    this.informationImages=[];
    this.accion=this.EMPTY_EXCEPTION;
    this.successMessage(this.messageSuccessDeleteAllImages);
  }
  connectSystemClientServer(){
  }

}
