import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import * as connect from 'src/app/jsFiles/controlScanner.js';
import { Observable,interval,Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import { DomSanitizer } from '@angular/platform-browser';
import { ListErrorScannerService } from 'src/app/service/list-error-scanner.service';
import { ToastrService } from 'ngx-toastr';
import { ValidationCm7Service } from 'src/app/service/validation-cm7.service';

@Component({
  selector: 'app-internet-explorer-browser',
  templateUrl: './internet-explorer-browser.component.html',
  styleUrls: ['./internet-explorer-browser.component.css']
})
export class InternetExplorerBrowserComponent implements OnInit,OnDestroy {

  @Input() typeBrowser:boolean;

  title = 'Ambiente para escaneo';
  onConnected:string;
  onDisconnected:string;
  serialNumber:string;
  stateTrack:string;
  exceptionInProgress:string;
  inter: Observable<any>;
  destroy$: Subject<boolean> = new Subject<boolean>();
  exception$: Subject<boolean> = new Subject<boolean>();
  imagenes:boolean;
  informationImages:Array<any>=[];
  etiquetaSistema:string;
  etiquetaEscaner:string;
  circleEscaner:boolean;
  circleSistema:boolean;
  serialEscaner:string;
  conectarEscaner:string;
  conectarSistema:string;
  titleImagenes:string;
  alerta:boolean;
  forceShutDownScanner:boolean;
  accion:string;
  error:string;
  cm7Duplication:Array<any>;
  duplicationCm7Message:string;
  private IDLE_STATE:string="2";
  private READY_STATE:string="4";
  private POWER_OFF_STATE:string="1";
  private EXCEPTION_STATE:string="6";
  private scanningFlag:boolean;
  private hopperEmpty:any;
  private flowStopped:any;
  private DISCONNECTED_SCANNER:string="ESCANER DESCONECTADO";
  private CONNECTED_SCANNER:string="ESCANER CONECTADO";
  private CONNECT_SCANNER_BUTTON:string="Iniciar Escaner";
  private SHUT_DOWN_SCANNER_BUTTON:string="Cerrar Escaner";
  private CONNECTING_SCANNER:string="CONECTANDO ESCANER";
  private SCANNING:string="ESCANEANDO";
  private LOADED_IMAGES:string="IMAGENES CARGADAS";
  private NO_IMAGES:string="NO HAY IMAGENES";
  private EMPTY_EXCEPTION:string="";
  private DISCONNECTED_EXCEPTION="0001600002";
  private CHECKING_CONNECTION_SCANNER:string="Chequear conexión de escaner"
  private messageWarnigScanning:string="Conectar escaner";
  private messageExceptionScanning:string="Dispositivo en estado de excepción";
  private messageSuccessDeleteImage:string="Imagen eliminada";
  private messageSuccessDeleteAllImages:string="Imagenes eliminadas";
  private FORCE_SHUT_DOWN_SCANNER:string="Escaner forzado a cerrar";
  private DUPLICATION_IMAGE:string="CM7 DUPLICADO";

  constructor(private sanitizer: DomSanitizer,private errors:ListErrorScannerService,
    private toastr: ToastrService,private validationCm7:ValidationCm7Service){
    this.onConnected="";
    this.serialNumber="";
    this.scanningFlag=false;
    this.imagenes=false;
    this.typeBrowser=true;
    this.circleEscaner=false;
    this.alerta=false;
    this.forceShutDownScanner=false;
    this.accion=this.EMPTY_EXCEPTION;
    this.titleImagenes='IMAGENES ESCANEADAS';
    this.informationImages=[];
    this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
    this.serialEscaner=this.EMPTY_EXCEPTION;
    this.conectarEscaner=this.CONNECT_SCANNER_BUTTON;
    this.duplicationCm7Message=this.DUPLICATION_IMAGE;
  }

  ngOnInit(){
    connect.initScanner();
  }
  ngOnDestroy(){
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
    this.exception$.next(true);
    this.exception$.unsubscribe();
  }
  
  connectingScanner(){
    connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.connectingScannerCases();
    });
  }
  connectingScannerCases(){
    if(this.conditionConnectingScanner()){
      this.setInitialVariablesForConnectingScanner();
      this.informationImages=[];
      this.setConnectionScanner();
    }else if(this.conditionShutdownScannerFromReadyState()){
      this.setInitialVariablesForConnectingScanner();
      this.shutDownScannerFromReadyState();
    }else if(this.conditionShutdownScannerFromIdleState()){
      this.setInitialVariablesForConnectingScanner();
      this.shutDownScannerFromIdleState();
    }else if(this.conditionDisconnectedScannerWithException()){
      this.setInitialVariablesForConnectingScanner();
      this.accion=this.CHECKING_CONNECTION_SCANNER;
    }else if(this.conditionConnectedScannerWithException()){
      this.setInitialVariablesForConnectingScanner();
      this.accion=this.CONNECTING_SCANNER;
      this.forceShutDownScanner=true;
      this.getVariablesInShutdownProcessInException();
    }
  }

  scanning(){
    let state=connect.getStateTrack().toString();
    if(state==this.IDLE_STATE){
      this.executingScanningProcess();
      connect.goReadyToProcess();
    }else if(state==this.READY_STATE){
      this.executingScanningProcess();
    }else if(state==this.POWER_OFF_STATE){
      this.warningMessage(this.messageWarnigScanning);
    }else if(state==this.EXCEPTION_STATE){
      this.warningMessage(this.messageExceptionScanning);
    }
  }
  private setInitialVariablesForConnectingScanner(){
    this.alerta=false;
    this.imagenes=false;
    this.forceShutDownScanner=false;
  }
  private executingScanningProcess(){
    this.accion=this.SCANNING;
    //connect.resetExceptionVariables();
    connect.resetValueObjectScanner();
    this.getVariablesInScanningProcess();
  }
  private setConnectionScanner(){
    this.accion=this.CONNECTING_SCANNER;
    const result= this.getIntervalObservable();
    connect.powerUp();
    result.subscribe(()=>connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionShutDownIntervalConnection(response);
    }));
  }
  private getVariablesInScanningProcess(){
    const result= this.getIntervalObservable();
    result.subscribe(()=>connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionStartScanning();
      this.conditionShutDownIntervalScanning(response);
    }));
  }
  private getVariablesInShutdownProcessInException(){
    const result= this.getIntervalObservableForException();
    connect.flowStop();
    let flagReadyState=false;
    let flagIdleState=false;
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.READY_STATE && flagReadyState==false){
        flagReadyState=true;
        connect.goIdle();
      }else if(response.toString()==this.IDLE_STATE && flagIdleState==false){
        flagIdleState=true;
        connect.powerDown();
      }else if(this.conditionShutdownScannerVariable(response,flagPowerOffState)){
        flagPowerOffState=true;
        connect.resetExceptionVariables();
        this.setShutdownScannerVariables(response);
      }else if(this.conditionShutdownScannerFromExceptionStateAndDisconnectedException(response)){
        connect.resetConnectedAndDisconnectedVariables();
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private shutDownScannerFromReadyState(){
    const result= this.getIntervalObservableForException();
    connect.goIdle();
    let flagIdleState=false;
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.IDLE_STATE && flagIdleState==false){
        flagIdleState=true;
        connect.powerDown();
      }else if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.alerta=false;
        this.accion=this.EMPTY_EXCEPTION;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private shutDownScannerFromIdleState(){
    const result= this.getIntervalObservableForException();
    connect.powerDown();
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.alerta=false;
        this.accion=this.EMPTY_EXCEPTION;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private setShutdownScannerVariables(response){
    this.exception$.next(true);
    this.circleEscaner=false;
    this.conectarEscaner=this.CONNECT_SCANNER_BUTTON;
    this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
    this.accion=this.getMessageAccionWhenShutDownScanner();
    this.getVariablesObjectOfScannerControl(response);
  } 
  private getIntervalObservable(){
    this.destroy$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.destroy$));
    return result;
  }
  private getIntervalObservableForException(){
    this.exception$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.exception$));
    return result;
  }
  private conditionShutDownIntervalConnection(response){
    if(this.conditionConnected() && this.conditionSerialNumber()){
      this.destroy$.next(true);
      this.circleEscaner=true;
      this.conectarEscaner=this.SHUT_DOWN_SCANNER_BUTTON;
      this.etiquetaEscaner=this.CONNECTED_SCANNER;
      this.accion=this.EMPTY_EXCEPTION;
      this.getVariablesObjectOfScannerControl(response);
    }else if(this.conditionExceptionConnectingScanner()){
      this.destroy$.next(true);
      this.getAlarmActive();
    }
  }
  private conditionShutDownIntervalScanning(response){
    if(this.conditionIntervalScanning() && this.scanningFlag==true){
      this.destroy$.next(true);
      this.arrayImageInformationScanning();
      this.imagenes=true;
      this.scanningFlag=false;
      this.getVariablesObjectOfScannerControl(response);
      this.getAlarmActive();
    }
  }
  private arrayImageInformationScanning(){
    let information=[];
    this.cm7Duplication=[];
    information.push(connect.getGeneralResultScanning());
    information=information.filter(value=>Object.keys(value).length!==0);
    if(information[0] && information[0].length>0){
      this.accion=this.LOADED_IMAGES;
      information[0].forEach(element => {this.informationImages.push(element)});
      this.cm7Duplication=this.validationCm7.findDuplicateCm7(this.informationImages);
    }else{
      this.accion=this.NO_IMAGES;
    }
  }
  private getAlarmActive(){
    if(this.conditionExceptionInProgress()){
      this.alerta=true;
      this.accion=this.EMPTY_EXCEPTION;
      this.error=this.getErrorMessage(this.exceptionInProgress);
      this.getVariablesInShutdownProcessInException();
    }
  }
  private conditionConnectingScanner(){
    return this.conectarEscaner==this.CONNECT_SCANNER_BUTTON && this.conditionConnectingWithoutDisconnectedException();
  }
  private conditionDisconnectedScannerWithException(){
    return this.conectarEscaner==this.CONNECT_SCANNER_BUTTON && this.conditionConnectedNullWithDisconnectedException();
  }
  private conditionConnectedScannerWithException(){
    return this.conectarEscaner==this.CONNECT_SCANNER_BUTTON && this.conditionConnectedWithDisconnectedException();
  }
  private conditionIntervalScanning(){
    return (this.conditionConnected() && this.conditionHopperFlowStopped()) || this.conditionExceptionInProgress();
  }
  private conditionHopperFlowStopped(){
    return (this.hopperEmpty && this.hopperEmpty!="") || (this.flowStopped && this.flowStopped!="")
  }
  private conditionConnected(){
    return this.onConnected && this.onConnected!="";
  }
  private conditionSerialNumber(){
    return this.serialEscaner  && this.serialEscaner!="";
  }
  private conditionExceptionInProgress(){
    return this.exceptionInProgress && this.exceptionInProgress!="";
  }
  private conditionExceptionDisconnected(){
    return this.exceptionInProgress && this.exceptionInProgress==this.DISCONNECTED_EXCEPTION;
  }
  private conditionExceptionConnectingScanner(){
    let state=connect.getStateTrack().toString();
    return !this.conditionSerialNumber() && this.conditionExceptionInProgress() && state==this.EXCEPTION_STATE;
  }
  private conditionConnectingWithoutDisconnectedException(){
    return !this.conditionConnected() && !this.conditionExceptionInProgress();
  }
  private conditionConnectedNullWithDisconnectedException(){
    return !this.conditionConnected() && this.conditionExceptionDisconnected();
  }
  private conditionConnectedWithDisconnectedException(){
    return this.conditionConnected() && this.conditionExceptionDisconnected();
  }
  private conditionShutdownScannerFromReadyState(){
    let state=connect.getStateTrack().toString();
    return this.conectarEscaner==this.SHUT_DOWN_SCANNER_BUTTON && state==this.READY_STATE;
  }
  private conditionShutdownScannerFromIdleState(){
    let state=connect.getStateTrack().toString();
    return this.conectarEscaner==this.SHUT_DOWN_SCANNER_BUTTON && state==this.IDLE_STATE;
  }
  private conditionShutdownScannerFromExceptionStateAndDisconnectedException(response){
    return response.toString()==this.EXCEPTION_STATE && this.exceptionInProgress==this.DISCONNECTED_EXCEPTION;
  }
  private conditionShutdownScannerVariable(response,flagPowerOffState){
    return response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false
  }
  private conditionStartScanning(){
    let state=connect.getStateTrack().toString();
    if(this.conditionConnected() && state==this.READY_STATE && this.scanningFlag==false){
      this.scanningFlag=true;
      connect.flowStart();
    }
  }
  private getVariablesObjectOfScannerControl(response){
    this.onConnected=response["OnConnected"];
    this.onDisconnected=response["OnDisconnected"];
    this.stateTrack=response["tTrackState"];
    this.hopperEmpty=response["OnHopperEmpty"];
    this.flowStopped=response["OnFlowStopped"];
    this.serialEscaner=response["tSerialNumber0"];
    this.exceptionInProgress=response["OnExceptionInProgress"];    
  }
  private getErrorMessage(errorCode:string){
    return this.errors.getErrorMessage(errorCode);
  }
  
  private warningMessage(message){
    this.toastr.warning(message,"Precaucion",{timeOut:2000,});
  }
  private successMessage(message){
    this.toastr.success(message,"Operación exitosa",{timeOut:2000,});
  }
  private informationMessage(message){
    this.toastr.info(message,"Mensaje de información",{timeOut:2000,});
  }
  private getMessageAccionWhenShutDownScanner(){
    return this.forceShutDownScanner==true?this.FORCE_SHUT_DOWN_SCANNER:this.EMPTY_EXCEPTION;
  }
  getImage(imageBase64){
    return this.sanitizer.bypassSecurityTrustResourceUrl('data:image/png;base64,'+imageBase64);
  }
  deleteImageSelected(idDoc){
    this.informationImages=this.informationImages.filter(image=>image.idDoc!=idDoc);
    this.successMessage(this.messageSuccessDeleteImage);
  }
  deleteAllImages(){
    this.informationImages=[];
    this.accion=this.EMPTY_EXCEPTION;
    this.successMessage(this.messageSuccessDeleteAllImages);
  }
  getColorForDuplicationCm7(dr1){
    if(this.cm7Duplication.length>0){
      return this.cm7Duplication.includes(dr1)?'red':'black';
    }
    return 'black';
  }
  getFlagForDuplicationCm7(dr1){
    if(this.cm7Duplication.length>0){
      return this.cm7Duplication.includes(dr1);
    }
    return false;
  }
  
  connectSystemClientServer(){
  }

}
