import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import * as connect from 'src/app/jsFiles/controlScanner.js';
import { Observable,interval,Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import { DomSanitizer } from '@angular/platform-browser';
import { ListErrorScannerService } from 'src/app/service/list-error-scanner.service';
import { ToastrService } from 'ngx-toastr';
import { ValidationCm7Service } from 'src/app/service/validation-cm7.service';

@Component({
  selector: 'app-internet-explorer-browser',
  templateUrl: './internet-explorer-browser.component.html',
  styleUrls: ['./internet-explorer-browser.component.css']
})
export class InternetExplorerBrowserComponent implements OnInit,OnDestroy {

  @Input() typeBrowser:boolean;

  title = 'Ambiente para escaneo';
  onConnected:string;
  onDisconnected:string;
  serialNumber:string;
  stateTrack:string;
  exceptionInProgress:string;
  inter: Observable<any>;
  connecting$: Subject<boolean> = new Subject<boolean>();
  exception$: Subject<boolean> = new Subject<boolean>();
  scanning$: Subject<boolean> = new Subject<boolean>();
  imagenes:boolean;
  informationImages:Array<any>=[];
  etiquetaSistema:string;
  etiquetaEscaner:string;
  circleEscaner:boolean;
  circleSistema:boolean;
  serialEscaner:string;
  conectarEscaner:string;
  conectarSistema:string;
  scanningBotton:string;
  titleImagenes:string;
  alerta:boolean;
  forceShutDownScanner:boolean;
  accion:string;
  error:string;
  cm7Duplication:Array<any>;
  duplicationCm7Message:string;
  connectingScannerFlag:boolean;
  shutdownOrScanningButtonFlag:boolean;
  private IDLE_STATE:string="2";
  private READY_STATE:string="4";
  private POWER_OFF_STATE:string="1";
  private EXCEPTION_STATE:string="6";
  private scanningFlag:boolean;
  private hopperEmpty:any;
  private flowStopped:any;
  private DISCONNECTED_SCANNER:string="ESCANER DESCONECTADO";
  private CONNECTED_SCANNER:string="ESCANER CONECTADO";
  private SHUT_DOWN_SCANNER_BUTTON:string="Cerrar Escaner";
  private CONNECTING_SCANNER:string="CONECTANDO ESCANER";
  private SCANNING:string="ESCANEANDO";
  private LOADED_IMAGES:string="IMAGENES CARGADAS";
  private NO_IMAGES:string="NO HAY IMAGENES";
  private EMPTY_EXCEPTION:string="";
  private DISCONNECTED_EXCEPTION="0001600002";
  private CHECKING_CONNECTION_SCANNER:string="Chequear conexión de escaner"
  private messageWarnigScanning:string="Conectar escaner";
  private messageWarnigShutdownScanner:string="Escaner no esta conectando";
  private messageWarnigScanningProcessError:string="Salga y vuelva a entrar al ambiente";
  private messageExceptionScanning:string="Dispositivo en estado de excepción";
  private messageSuccessDeleteImage:string="Imagen eliminada";
  private messageSuccessDeleteAllImages:string="Imagenes eliminadas";
  private FORCE_SHUT_DOWN_SCANNER:string="Escaner forzado a cerrar";
  private DUPLICATION_IMAGE:string="CM7 DUPLICADO";
  private DUPLICATION_IMAGE_ERROR:string="CM7 DUPLICADO CON ERROR";
  private CM7_ERROR:string="CM7 ILEGIBLE";
  private SCANNING_BUTTON:string="Escanear";

  constructor(private sanitizer: DomSanitizer,private errors:ListErrorScannerService,
    private toastr: ToastrService,private validationCm7:ValidationCm7Service){
    this.onConnected="";
    this.serialNumber="";
    this.scanningFlag=false;
    this.imagenes=false;
    this.typeBrowser=true;
    this.circleEscaner=false;
    this.alerta=false;
    this.forceShutDownScanner=false;
    this.connectingScannerFlag=false;
    this.shutdownOrScanningButtonFlag=false;
    this.accion=this.EMPTY_EXCEPTION;
    this.titleImagenes='IMAGENES ESCANEADAS';
    this.informationImages=[];
    this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
    this.serialEscaner=this.EMPTY_EXCEPTION;
    this.conectarEscaner=this.SHUT_DOWN_SCANNER_BUTTON;
    this.duplicationCm7Message=this.DUPLICATION_IMAGE;
    this.scanningBotton=this.SCANNING_BUTTON;
  }

  ngOnInit(){
    //connect.resetActiveXObject();
    connect.initScanner();
  }
  ngOnDestroy(){
    this.getObservableVariablesTrue();
    this.connecting$.unsubscribe();
    this.exception$.unsubscribe();
    this.scanning$.unsubscribe();
    connect.resetActiveXObject();
  }
  private getObservableVariablesTrue(){
    this.connecting$.next(true);
    this.exception$.next(true);
    this.scanning$.next(true);
  }
  shutdownScanner(){
    this.shutdownOrScanningButtonFlag=true;
    if(this.connectingScannerFlag==true){
      connect.getValueObjectScanner().then(response=>{
        this.getVariablesObjectOfScannerControl(response);
        this.connectingScannerCases();
      });
    }else{
      this.warningMessage(this.messageWarnigShutdownScanner);
    }
  }

  connectingScannerAndScanningProcess(){
    connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.shutdownOrScanningButtonFlag=false;
      if(this.connectingScannerFlag==false){
        this.connectingScannerCases();
      }else if(this.connectingScannerFlag==true && !this.conditionExceptionInProgress()){
        this.scanning();    
      }else if(this.connectingScannerFlag==true && this.conditionExceptionInProgress()){
        this.getObservableVariablesTrue();
        this.warningMessage(this.messageWarnigScanningProcessError);
      }
    });
  }

  private connectingScannerCases(){
    if(this.conditionConnectingScanner()){
      this.setInitialVariablesForConnectingScanner();
      this.informationImages=[];
      this.setConnectionScanner();
    }else if(this.conditionShutdownScannerFromReadyState()){
      this.setInitialVariablesForConnectingScanner();
      this.shutDownScannerFromReadyState();
    }else if(this.conditionShutdownScannerFromIdleState()){
      this.setInitialVariablesForConnectingScanner();
      this.shutDownScannerFromIdleState();
    }else if(this.conditionDisconnectedScannerWithException()){
      this.setInitialVariablesForConnectingScanner();
      this.accion=this.CHECKING_CONNECTION_SCANNER;
    }else if(this.conditionConnectedScannerWithException()){
      this.setInitialVariablesForConnectingScanner();
      this.accion=this.CONNECTING_SCANNER;
      this.forceShutDownScanner=true;
      this.getVariablesInShutdownProcessInException();
    }
  }

  scanning(){
    let state=connect.getStateTrack().toString();
    if(state==this.IDLE_STATE){
      this.executingScanningProcess();
      connect.goReadyToProcess();
    }else if(state==this.READY_STATE){
      this.executingScanningProcess();
    }else if(state==this.POWER_OFF_STATE){
      this.warningMessage(this.messageWarnigScanning);
    }else if(state==this.EXCEPTION_STATE){
      this.warningMessage(this.messageExceptionScanning);
    }
  }
  private setInitialVariablesForConnectingScanner(){
    this.alerta=false;
    this.imagenes=false;
    this.forceShutDownScanner=false;
  }
  private executingScanningProcess(){
    this.accion=this.SCANNING;
    connect.resetValueObjectScanner();
    this.getVariablesInScanningProcess();
  }
  private setConnectionScanner(){
    this.accion=this.CONNECTING_SCANNER;
    const result= this.getIntervalObservableForConnecting();
    connect.powerUp();
    result.subscribe(()=>connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionShutDownIntervalConnection(response);
    }));
  }
  private getVariablesInScanningProcess(){
    const result= this.getIntervalObservableForScanning();
    result.subscribe(()=>connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionStartScanning();
      this.conditionShutDownIntervalScanning(response);
    }));
  }
  private getVariablesInShutdownProcessInException(){
    const result= this.getIntervalObservableForException();
    connect.flowStop();
    let flagReadyState=false;
    let flagIdleState=false;
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.READY_STATE && flagReadyState==false){
        flagReadyState=true;
        connect.goIdle();
      }else if(response.toString()==this.IDLE_STATE && flagIdleState==false){
        flagIdleState=true;
        connect.powerDown();
      }else if(this.conditionShutdownScannerVariable(response,flagPowerOffState)){
        flagPowerOffState=true;
        this.connectingScannerFlag=false;
        connect.resetExceptionVariables();
        this.setShutdownScannerVariables(response);
      }else if(this.conditionShutdownScannerFromExceptionStateAndDisconnectedException(response)){
        connect.resetConnectedAndDisconnectedVariables();
        this.connectingScannerFlag=false;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private shutDownScannerFromReadyState(){
    const result= this.getIntervalObservableForException();
    connect.goIdle();
    let flagIdleState=false;
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.IDLE_STATE && flagIdleState==false){
        flagIdleState=true;
        connect.powerDown();
      }else if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.alerta=false;
        this.accion=this.EMPTY_EXCEPTION;
        this.connectingScannerFlag=false;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private shutDownScannerFromIdleState(){
    const result= this.getIntervalObservableForException();
    connect.powerDown();
    let flagPowerOffState=false;
    result.subscribe(()=>connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.alerta=false;
        this.accion=this.EMPTY_EXCEPTION;
        this.connectingScannerFlag=false;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private setShutdownScannerVariables(response){
    this.exception$.next(true);
    this.circleEscaner=false;
    this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
    this.accion=this.getMessageAccionWhenShutDownScanner();
    this.getVariablesObjectOfScannerControl(response);
  } 
  private getIntervalObservableForConnecting(){
    this.connecting$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.connecting$));
    return result;
  }
  private getIntervalObservableForException(){
    this.exception$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.exception$));
    return result;
  }
  private getIntervalObservableForScanning(){
    this.scanning$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.scanning$));
    return result;
  }
  private conditionShutDownIntervalConnection(response){
    if(this.conditionConnected() && this.conditionSerialNumber()){
      this.connecting$.next(true);
      this.circleEscaner=true;
      this.connectingScannerFlag=true;
      this.etiquetaEscaner=this.CONNECTED_SCANNER;
      this.accion=this.EMPTY_EXCEPTION;
      this.getVariablesObjectOfScannerControl(response);
      this.scanning();
    }else if(this.conditionExceptionConnectingScanner()){
      this.connecting$.next(true);
      this.getAlarmActive();
    }
  }
  private conditionShutDownIntervalScanning(response){
    if(this.conditionIntervalScanning() && this.scanningFlag==true){
      this.scanning$.next(true);
      this.arrayImageInformationScanning();
      this.imagenes=true;
      this.scanningFlag=false;
      this.getVariablesObjectOfScannerControl(response);
      this.getAlarmActive();
    }
  }
  private arrayImageInformationScanning(){
    let information=[];
    this.cm7Duplication=[];
    information.push(connect.getGeneralResultScanning());
    information=information.filter(value=>Object.keys(value).length!==0);
    if(information[0] && information[0].length>0){
      this.accion=this.LOADED_IMAGES;
      information[0].forEach(element => {this.informationImages.push(element)});
      this.cm7Duplication=this.validationCm7.findDuplicateCm7(this.informationImages);
    }else{
      this.accion=this.NO_IMAGES;
    }
  }
  private getAlarmActive(){
    if(this.conditionExceptionInProgress()){
      this.alerta=true;
      this.accion=this.EMPTY_EXCEPTION;
      this.error=this.getErrorMessage(this.exceptionInProgress);
      this.getVariablesInShutdownProcessInException();
    }
  }
  private conditionConnectingScanner(){
    return this.conditionToDetermineConnection() && this.conditionConnectingWithoutDisconnectedException();
  }

  //revisar estas dos condiciones 
  private conditionDisconnectedScannerWithException(){
    return this.connectingScannerFlag==false && this.conditionConnectedNullWithDisconnectedException();
  }
  private conditionConnectedScannerWithException(){
    return this.conditionToDetermineConnection() && this.conditionConnectedWithDisconnectedException();
    //return this.connectingScannerFlag==false && this.conditionConnectedWithDisconnectedException();
  }
  /////////////////////////////////////

  private conditionIntervalScanning(){
    return (this.conditionConnected() && this.conditionHopperFlowStopped()) || this.conditionExceptionInProgress();
  }
  private conditionHopperFlowStopped(){
    return (this.hopperEmpty && this.hopperEmpty!="") || (this.flowStopped && this.flowStopped!="")
  }
  private conditionConnected(){
    return this.onConnected && this.onConnected!="";
  }
  private conditionSerialNumber(){
    return this.serialEscaner  && this.serialEscaner!="";
  }
  private conditionExceptionInProgress(){
    return this.exceptionInProgress && this.exceptionInProgress!="";
  }
  private conditionExceptionDisconnected(){
    return this.exceptionInProgress && this.exceptionInProgress==this.DISCONNECTED_EXCEPTION;
  }
  private conditionExceptionConnectingScanner(){
    let state=connect.getStateTrack().toString();
    return !this.conditionSerialNumber() && this.conditionExceptionInProgress() && state==this.EXCEPTION_STATE;
  }
  private conditionConnectingWithoutDisconnectedException(){
    return !this.conditionConnected() && !this.conditionExceptionInProgress();
  }
  private conditionConnectedNullWithDisconnectedException(){
    return !this.conditionConnected() && this.conditionExceptionDisconnected();
  }
  private conditionConnectedWithDisconnectedException(){
    return this.conditionConnected() && this.conditionExceptionDisconnected();
  }
  private conditionToDetermineConnection(){
    return this.connectingScannerFlag==false && this.shutdownOrScanningButtonFlag==false;
  }
  private conditionToDetermineShutdown(){
    return this.connectingScannerFlag==true && this.shutdownOrScanningButtonFlag==true;
  }
  private conditionShutdownScannerFromReadyState(){
    let state=connect.getStateTrack().toString();
    return this.conditionToDetermineShutdown() && state==this.READY_STATE;
  }
  private conditionShutdownScannerFromIdleState(){
    let state=connect.getStateTrack().toString();
    return this.conditionToDetermineShutdown() && state==this.IDLE_STATE;
  }
  private conditionShutdownScannerFromExceptionStateAndDisconnectedException(response){
    return response.toString()==this.EXCEPTION_STATE && this.exceptionInProgress==this.DISCONNECTED_EXCEPTION;
  }
  private conditionShutdownScannerVariable(response,flagPowerOffState){
    return response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false
  }
  private conditionStartScanning(){
    let state=connect.getStateTrack().toString();
    if(this.conditionConnected() && state==this.READY_STATE && this.scanningFlag==false){
      this.scanningFlag=true;
      connect.flowStart();
    }
  }

  private getVariablesObjectOfScannerControl(response){
    this.onConnected=response["OnConnected"];
    this.onDisconnected=response["OnDisconnected"];
    this.stateTrack=response["tTrackState"];
    this.hopperEmpty=response["OnHopperEmpty"];
    this.flowStopped=response["OnFlowStopped"];
    this.serialEscaner=response["tSerialNumber0"];
    this.exceptionInProgress=response["OnExceptionInProgress"];    
  }
  private getErrorMessage(errorCode:string){
    return this.errors.getErrorMessage(errorCode);
  }
  
  private warningMessage(message){
    this.toastr.warning(message,"Precaucion",{timeOut:2000,});
  }
  private successMessage(message){
    this.toastr.success(message,"Operación exitosa",{timeOut:2000,});
  }
  private informationMessage(message){
    this.toastr.info(message,"Mensaje de información",{timeOut:2000,});
  }
  private getMessageAccionWhenShutDownScanner(){
    return this.forceShutDownScanner==true?this.FORCE_SHUT_DOWN_SCANNER:this.EMPTY_EXCEPTION;
  }
  getImage(imageBase64){
    return this.sanitizer.bypassSecurityTrustResourceUrl('data:image/png;base64,'+imageBase64);
  }
  deleteImageSelected(idDoc){
    this.informationImages=this.informationImages.filter(image=>image.idDoc!=idDoc);
    this.successMessage(this.messageSuccessDeleteImage);
  }
  deleteAllImages(){
    this.informationImages=[];
    this.accion=this.EMPTY_EXCEPTION;
    this.successMessage(this.messageSuccessDeleteAllImages);
  }
  getColorForDuplicationCm7(dr1){
    if(this.cm7Duplication.length>0){
      return this.cm7Duplication.includes(dr1)?'red':'black';
    }
    return 'black';
  }
  getFlagForDuplicationCm7(dr1){
    if(this.getConditionCm7Duplication(dr1)){
      this.duplicationCm7Message=this.DUPLICATION_IMAGE;
      return this.cm7Duplication.includes(dr1);
    }else if(this.getConditionCm7DuplicationWithError(dr1)){
      this.duplicationCm7Message=this.DUPLICATION_IMAGE_ERROR;
      return this.cm7Duplication.includes(dr1);
    }else if(this.getConditionCm7WithError(dr1)){
      this.duplicationCm7Message=this.CM7_ERROR;
      return true;
    }
    return false;
  }
  private getCountingErrorCharacters(dr1){
    if(dr1!=null){
      let numbersInCm7=dr1.replace(/\D/g,'');
      return numbersInCm7.length<=(dr1.length/2);
    }
    return false;
  }
  private getCountingCorrectCm7(dr1){
    if(dr1!=null){
      let numbersInCm7=dr1.replace(/\D/g,'');
      return (numbersInCm7.length-dr1.length)==0;
    }
    return false;
  }
  private getConditionCm7Duplication(dr1){
    return this.cm7Duplication.length>0 && this.getCountingCorrectCm7(dr1) && dr1!=this.EMPTY_EXCEPTION;
  }
  private getConditionCm7DuplicationWithError(dr1){
    return this.cm7Duplication.length>0  && !this.getCountingErrorCharacters(dr1);
  }
  private getConditionCm7WithError(dr1){
    return this.cm7Duplication.length>=0 && this.getCountingErrorCharacters(dr1);
  }
  connectSystemClientServer(){
  }

}
