import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChromeBrowserComponent } from './chrome-browser.component';

describe('ChromeBrowserComponent', () => {
  let component: ChromeBrowserComponent;
  let fixture: ComponentFixture<ChromeBrowserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChromeBrowserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChromeBrowserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
