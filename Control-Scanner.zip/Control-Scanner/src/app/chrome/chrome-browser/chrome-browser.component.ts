import { Component, Input, OnInit } from '@angular/core';
import { DomSanitizer, SafeHtml} from '@angular/platform-browser'
import * as conect from 'src/app/jsfiles/ConnectionToBackground.js';
import { ToastrService } from 'ngx-toastr';
import { InformationFromScannerService } from 'src/app/service/information-from-scanner.service';
import { ListErrorScannerService } from 'src/app/service/list-error-scanner.service';
import { ListExtensionIdsService } from 'src/app/service/list-extension-ids.service';

@Component({
  selector: 'app-chrome-browser',
  templateUrl: './chrome-browser.component.html',
  styleUrls: ['./chrome-browser.component.css']
})
export class ChromeBrowserComponent implements OnInit{

  @Input() typeBrowser:boolean;
  @Input() nameBrowser:string;

  title = 'Ambiente para escaneo';
  etiquetaSistema:string;
  etiquetaEscaner:string;
  circleEscaner:boolean;
  circleSistema:boolean;
  alerta:boolean;
  error:string;
  accion:string;
  serialEscaner:string;
  exception:string;
  titleImagenes:string;
  imagenes:boolean;
  imagen:SafeHtml;
  imageBase64:string;
  connectScannerButton:boolean=false;
  informationFromScanner:any;
  informationImages:Array<any>=[];
  conectarSistema:string;
  conectarEscaner:string;
  forceShutDownScanner:boolean;
  idForExtension:string;
  private CHECKING_SYSTEM:string="SERVER IS OK";
  private EXIT_SYSTEM:string= "EXIT IS OK";
  private resultConnectingScanner={};
  private connectionScannerFlag:boolean=false;
  private connectionSystemFlag:boolean=false;
  private scanningExceptionFlag:boolean=false;
  private messageWarnigConnectionSystem:string="Cerrar el escaner";
  private messageWarnigConnectionScanner:string="Iniciar sistema";
  private messageWarnigScanning:string="Comprobar conexion con el sistema o escaner";
  private messageSuccessDeleteImage:string="Imagen eliminada";
  private messageSuccessDeleteAllImages:string="Imagenes eliminadas";
  private messageInfoToCloseScanner:string="Cerrar escaner";
  private EXCEPTION_STATE:string="6";
  private READY_STATE:string="4";
  private FLOW_STATE:string="5";
  private POWER_OFF_STATE:string="1";
  private IDLE_STATE:string="2";
  private EMPTY_EXCEPTION:string="";
  private EMPTY_ARRAY:string="[]";
  private CONNECTED_SYSTEM:string="SISTEMA CONECTADO";
  private DISCONNECTED_SYSTEM:string="SISTEMA DESCONECTADO";
  private CONNECTED_SCANNER:string="ESCANER CONECTADO";
  private DISCONNECTED_SCANNER:string="ESCANER DESCONECTADO";
  private CONNECTING_SYSTEM:string="CONECTANDO SISTEMA";
  private ERROR_OF_CONNECTION:string="ERROR DE CONEXION";
  private CONNECTING_SCANNER:string="CONECTANDO ESCANER";
  private SHUTTING_DOWN_SCANNER:string="CERRANDO ESCANER";
  private SCANNING:string="ESCANEANDO";
  private LOADING_INFORMATION:string="CARGANDO INFORMACION";
  private LOADED_IMAGES:string="IMAGENES CARGADAS";
  private NO_IMAGES:string="NO HAY IMAGENES";
  private CONNECT_SYSTEM_BUTTON:string="Conectar Sistema";
  private SHUT_DOWN_SYSTEM_BUTTON:string="Cerrar Sistema";
  private CONNECT_SCANNER_BUTTON:string="Iniciar Escaner";
  private SHUT_DOWN_SCANNER_BUTTON:string="Cerrar Escaner";
  private CONNECTED:string='conectado';
  
  constructor(private sanitizer: DomSanitizer,private information:InformationFromScannerService,
    private toastr: ToastrService,private errors:ListErrorScannerService,private extensionId:ListExtensionIdsService){
    this.etiquetaSistema=this.DISCONNECTED_SYSTEM;
    this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
    this.titleImagenes='IMAGENES ESCANEADAS';
    this.circleEscaner=false;
    this.circleSistema=false;
    this.alerta=false;
    this.imagenes=false;
    this.forceShutDownScanner=false;
    this.accion=this.EMPTY_EXCEPTION;
    this.serialEscaner=this.EMPTY_EXCEPTION;
    this.exception=this.EMPTY_EXCEPTION;
    this.conectarSistema=this.CONNECT_SYSTEM_BUTTON;
    this.conectarEscaner=this.CONNECT_SCANNER_BUTTON;
  }

  ngOnInit(){
    this.idForExtension=this.extensionId.getIdExtensionForBrowser(this.nameBrowser);
  }

  connectSystemClientServer(){
    if(this.conectarSistema==this.CONNECT_SYSTEM_BUTTON && this.connectionScannerFlag==false){
      this.accion=this.CONNECTING_SYSTEM;
      this.launchServerSystem();
    }else if(this.conectarSistema==this.SHUT_DOWN_SYSTEM_BUTTON && this.connectionScannerFlag==false)
    {
      this.closeServerSystem();
    }else if(this.connectionScannerFlag==true){
      this.warningMessage(this.messageWarnigConnectionSystem);
    }     
  }
  launchClientSystem(){
    conect.launchClientSystem(this.idForExtension).then(resultado=>{
      if(resultado==this.CONNECTED){
        this.connectionSystemFlag=true;
        setTimeout(()=>{
          this.checkingClientServerSystem();
        },1000)
      }
    }).catch(error=>this.accion=this.ERROR_OF_CONNECTION);
  }

  launchServerSystem(){
    conect.launchServerSystem(this.idForExtension).then(resultado=>{
      if(resultado==this.CONNECTED){
        this.launchClientSystem();
      }
    }).catch(error=>this.accion=this.ERROR_OF_CONNECTION);
  }

  closeServerSystem(){
    conect.closeServerSystem(this.idForExtension).then(resultado=>{
      if(resultado.echo==this.EXIT_SYSTEM){
        this.conectarSistema=this.CONNECT_SYSTEM_BUTTON;
        this.etiquetaSistema=this.DISCONNECTED_SYSTEM;
        this.circleSistema=false;
        this.alerta=false;
      }
    }).catch(error=>this.accion=this.ERROR_OF_CONNECTION);
  }

  checkingClientServerSystem(){
    conect.checkingClientServerSystem(this.idForExtension).then(resultado=>{
      if(resultado.echo==this.CHECKING_SYSTEM){
         this.etiquetaSistema=this.CONNECTED_SYSTEM;
         this.circleSistema=true;
         this.accion=this.EMPTY_EXCEPTION;
         this.conectarSistema=this.SHUT_DOWN_SYSTEM_BUTTON;
      }
    }).catch(error=>this.accion=this.ERROR_OF_CONNECTION);
  }

  connectingScanner(){
    this.alerta=false;
    this.resultConnectingScanner={};
    this.imagenes=false;
    if(this.conectarEscaner==this.CONNECT_SCANNER_BUTTON && this.connectionSystemFlag==true){
      this.accion=this.CONNECTING_SCANNER;
      this.setConnectingScanner();
    }else if(this.conectarEscaner==this.SHUT_DOWN_SCANNER_BUTTON && this.connectionSystemFlag==true){
      this.accion=this.SHUTTING_DOWN_SCANNER;
      this.informationImages=[];
      this.goIdleStateScanner();
    }else if(this.connectionSystemFlag==false){
      this.warningMessage(this.messageWarnigConnectionScanner);
    }
  }

  private setConnectingScanner(){
    conect.connectingScanner(this.idForExtension).then(resultado=>{
      if(resultado){
        this.information.getInformationFromScanning(resultado.echo);
        this.checkingExceptionConnectingScanner();
        this.informationImages=[];
      }
    }).catch(error=>this.accion=this.ERROR_OF_CONNECTION);
  }

  private goIdleStateScanner(){
    conect.goIdleStateScanner(this.idForExtension).then(resultado=>{
      if(resultado){
        this.information.getInformationFromScanning(resultado.echo);
        this.checkingExceptionGoIdleState(this.information);
      }
    }).catch(error=>this.accion=this.ERROR_OF_CONNECTION);
  }

  private shutDownScanner(){
    conect.shutDownScanner(this.idForExtension).then(resultado=>{
      if(resultado){
        this.information.getInformationFromScanning(resultado.echo);
        this.setVariablesForConnectingScanner();
        this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
        this.accion=this.getMessageAccionWhenShutDownScanner();
        this.scanningExceptionFlag=false;
      }
    }).catch(error=>this.accion=this.ERROR_OF_CONNECTION);
  }

  private checkingExceptionGoIdleState(information:InformationFromScannerService){
    if(information.getException()==this.EMPTY_EXCEPTION && information.getConnectingResult()==this.IDLE_STATE){
      this.shutDownScanner();
    }else{
      this.alerta=true;
    }
  }

  private checkingExceptionConnectingScanner(){
    if(this.getConditionForConnetionScanner() || this.scanningExceptionFlag==true){
      this.setVariablesForClosingScanner();
    }else if(this.information.getException()!=this.EMPTY_EXCEPTION){
      this.error=this.getErrorMessage(this.information.getException());
      this.setVariablesForConnectingScanner();
      this.accion=this.EMPTY_EXCEPTION;
      this.alerta=true;
      this.forceShutDownScanner=false;
    }else if(this.getConditionStartingFromFlowState()){
      this.forceShutDownScanner=true;
      this.shutDownScanner();
    }else if(this.getConditionStartingFromExceptionState()){
      this.setVariablesForConnectingScanner();
      this.alerta=false;
      this.forceShutDownScanner=false;
      this.accion="Chequear conexión de escaner o reiniciar sistema";
    }
  }
  private setVariablesForConnectingScanner(){
    this.connectionScannerFlag=false;
    this.serialEscaner="SERIAL: "+this.information.getSerial();
    this.conectarEscaner=this.CONNECT_SCANNER_BUTTON;
    this.circleEscaner=false;
  }
  private setVariablesForClosingScanner(){
    this.etiquetaEscaner=this.CONNECTED_SCANNER;
    this.conectarEscaner=this.SHUT_DOWN_SCANNER_BUTTON;
    this.serialEscaner="SERIAL: "+this.information.getSerial();
    this.connectionScannerFlag=true;
    this.circleEscaner=true;
    this.forceShutDownScanner=false;
    this.accion=this.EMPTY_EXCEPTION;
  }

  scanning(){
    if(this.getConditionalForScanningProcessWithoutException()){
      this.scanningProcessing();
    }else if(!this.getConditionalForSystemOrScannerConnection()){
      this.warningMessage(this.messageWarnigScanning);
    }else if(this.getConditionalForScanningProcessWithException()){
      this.warningMessage(this.messageInfoToCloseScanner);
    }
  }

  private scanningProcessing(){
    this.alerta=false;
    this.accion=this.SCANNING;
    var message="";
    conect.scanningProcessing(this.idForExtension).then(resultado=>{
      if(resultado){
        let initialChunk=this.information.getObjectOfInformation(resultado.echo);
        this.lookingForExceptionInitialChunk(initialChunk,message,resultado.echo);
      }
    }).catch(error=>this.accion=this.ERROR_OF_CONNECTION);
  }

  private lookingForExceptionInitialChunk(initialChunk,message,firstChuckInformation){
    if(this.getConditionForScanning(initialChunk)){
      this.accion=this.LOADING_INFORMATION;
      this.getChucksOfInformation(initialChunk,message,firstChuckInformation);
    }else if(this.getConditionForScanningWithOnlyException(initialChunk)){
      this.getChucksOfInformation(initialChunk,message,firstChuckInformation);
      this.informationImages=[];
    }else if(this.getConditionForScanningWithoutResult(initialChunk)){
      this.getChucksOfInformationWithoutResult(message,firstChuckInformation);
    }
  } 
  private getChucksOfInformation(initialChunk,message,firstChuckInformation){
      message=message.concat(firstChuckInformation);
      conect.callingChuckInformation(message,this.idForExtension).then(response=>{
        let images=this.getInformationFromScanner(response);
        this.informationImages= this.informationImages.concat(images);
        this.accion=this.LOADED_IMAGES;
        this.imagenes=true;
        this.ShutDownScannerFromScanningProcess(this.error);
      });
  }
  private getChucksOfInformationWithoutResult(message,firstChuckInformation){
    message=message.concat(firstChuckInformation);
      this.accion=this.LOADING_INFORMATION;
      conect.callingChuckInformation(message,this.idForExtension).then(res=>{
        let images=this.getInformationFromScanner(res);
        this.accion=this.NO_IMAGES;
        this.imagenes=false;
        this.ShutDownScannerFromScanningProcess(this.error);
      });
  }
  private ShutDownScannerFromScanningProcess(error){
    if(error && error!=this.EMPTY_EXCEPTION){
      this.error=error;
      this.scanningExceptionFlag=true;
      this.alerta=true;
      this.shutDownScanner();
    }
  }

  private getInformationFromScanner(message):Array<any>{
    this.resultConnectingScanner=this.information.getObjectOfInformation(message);
    this.setScannerState(this.resultConnectingScanner);
    this.getExceptionFromScanningProcess(this.resultConnectingScanner);
    this.resultConnectingScanner["docRead"]=this.information.getDocumentInformation(this.resultConnectingScanner["docRead"]);
    this.resultConnectingScanner["docImage"]=this.information.getDocumentInformation(this.resultConnectingScanner["docImage"]);
    this.resultConnectingScanner=this.information.removeFirstAndLastCharOfcmc7(this.resultConnectingScanner);
    return this.information.integrateAllInformationInArray(this.resultConnectingScanner);
  }

  private setScannerState(resultConnectingScanner){
    if(resultConnectingScanner["state"]==this.POWER_OFF_STATE){
      this.serialEscaner=resultConnectingScanner["serial"];
      this.etiquetaEscaner=this.DISCONNECTED_SCANNER;
      this.circleEscaner=false;
    }
  }

  private getExceptionFromScanningProcess(resultConnectingScanner){
    if(resultConnectingScanner["exep"]!=this.EMPTY_EXCEPTION){
      this.error=this.getErrorMessage(resultConnectingScanner["exep"]);
      this.scanningExceptionFlag=true;
      this.alerta=true;
    }else{
      this.error=null;
    }
  }
  
  getImage(imageBase64){
    return this.sanitizer.bypassSecurityTrustResourceUrl('data:image/tiff;base64,'+imageBase64);
  }

  deleteAllImages(){
    this.informationImages=[];
    this.accion=this.EMPTY_EXCEPTION;
    this.successMessage(this.messageSuccessDeleteAllImages);
  }

  deleteImageSelected(idDoc){
    this.informationImages=this.informationImages.filter(image=>image.idDoc!=idDoc);
    this.successMessage(this.messageSuccessDeleteImage);
  }

  private warningMessage(message){
     this.toastr.warning(message,"Precaucion",{timeOut:2000,});
  }
  private successMessage(message){
    this.toastr.success(message,"Operación exitosa",{timeOut:2000,});
  }
  private informationMessage(message){
    this.toastr.info(message,"Mensaje de información",{timeOut:2000,});
  }
  private getErrorMessage(errorCode:string){
    return this.errors.getErrorMessage(errorCode);
  }
  private getConditionalForScanningProcessWithoutException():boolean{
    return (this.getConditionalForSystemOrScannerConnection() && this.scanningExceptionFlag==false);
  }
  private getConditionalForSystemOrScannerConnection():boolean{
    return (this.connectionSystemFlag==true && this.connectionScannerFlag==true); 
  }
  private getConditionalForScanningProcessWithException():boolean{
    return (this.getConditionalForSystemOrScannerConnection() && this.scanningExceptionFlag==true);
  }
  private getConditionForScanningWithOnlyException(initialChunk):boolean{
    return (initialChunk["state"]==this.EXCEPTION_STATE && initialChunk["docImage"]==this.EMPTY_ARRAY);
  }
  private getConditionForScanningWithoutResult(initialChunk):boolean{
    return ((initialChunk["state"]==this.READY_STATE || initialChunk["state"]==this.FLOW_STATE) && initialChunk["docImage"]==this.EMPTY_ARRAY);
  }
  private getConditionForScanning(initialChunk):boolean{
    return (initialChunk["docImage"]!=this.EMPTY_ARRAY);
  }
  private getConditionForConnetionScanner():boolean{
    return (this.information.getException()==this.EMPTY_EXCEPTION && this.information.getConnectingResult()!=this.FLOW_STATE 
    && this.information.getConnectingResult()!=this.EXCEPTION_STATE && this.information.getSerial()!=this.EMPTY_EXCEPTION);
  }
  private getConditionStartingFromFlowState():boolean{
      return this.information.getException()==this.EMPTY_EXCEPTION && this.information.getConnectingResult()==this.FLOW_STATE;
  }
  private getConditionStartingFromExceptionState():boolean{
    return this.information.getException()==this.EMPTY_EXCEPTION && this.information.getSerial()==this.EMPTY_EXCEPTION && 
      (this.information.getConnectingResult()==this.EXCEPTION_STATE || this.information.getConnectingResult()==this.READY_STATE);
  }
  private getMessageAccionWhenShutDownScanner(){
    return this.forceShutDownScanner==true?"Escaner forzado a cerrar":this.EMPTY_EXCEPTION;
  }
}
