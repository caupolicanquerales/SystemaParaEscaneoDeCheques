import { TestBed } from '@angular/core/testing';

import { ChromeBrowserService } from './chrome-browser.service';

describe('ChromeBrowserService', () => {
  let service: ChromeBrowserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChromeBrowserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
