import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppComponent } from './app.component';
import { InformationFromScannerService } from './service/information-from-scanner.service';
import { ListErrorScannerService } from './service/list-error-scanner.service';
import { ChromeBrowserComponent } from './chrome/chrome-browser/chrome-browser.component';
import { InternetExplorerBrowserComponent } from './explorer/internet-explorer-browser/internet-explorer-browser.component';
import { ListExtensionIdsService } from './service/list-extension-ids.service';
import { ValidationCm7Service } from './service/validation-cm7.service';

@NgModule({
  declarations: [
    AppComponent,
    ChromeBrowserComponent,
    InternetExplorerBrowserComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [
    InformationFromScannerService,
    ListErrorScannerService,
    ListExtensionIdsService,
    ValidationCm7Service
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
