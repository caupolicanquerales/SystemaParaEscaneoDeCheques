import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { DataTransmissionService } from 'src/app/service/data-transmission.service';
import { ChromeBrowserService } from 'src/app/chrome-service/chrome-browser.service';
import { InformationMessagesService } from 'src/app/service/information-messages.service';
import { ListErrorScannerService } from 'src/app/service/list-error-scanner.service';
import { FirefoxBrowserService } from 'src/app/firefox-service/firefox-browser.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { interval } from 'rxjs';
import * as connectExplorer from 'src/app/jsFiles/controlScanner.js';
import { ExplorerBrowserService } from 'src/app/explorer-service/explorer-browser.service';

@Component({
  selector: 'app-animation',
  templateUrl: './animation.component.html',
  styleUrls: ['./animation.component.css']
})
export class AnimationComponent implements OnInit, OnDestroy {

  @Input() conectarEscaner;

  alert:boolean;
  circleScanner:boolean;
  circleSystem:boolean;
  images:boolean;
  scanning:string;
  spinner:boolean;
  displayResultInException:boolean;
  conectarSistema:string;
  imagesBatchScanning:Array<any>;
  informationImages:Array<any>=[];
  ready:boolean;
  errorMessage:string;
  standby:boolean;
  paychecksForBatch:string;
  paychecksTotal:string;
  nameBrowser:string;
  animation:boolean;
  private totalChecks:number;
  private BROWSER_FIREFOX="Firefox";
  private CHROME_BROWSER="Chrome";
  private BROWSER_EXPLORER="Explorer";
  private BROWSER_EDGE="Edge";
  private SCANNER_NOT_CONNECTED="-1";
  private DISCONNECTED_EXCEPTION="0001600002";
  private ngUnsubscribe: Subject<void>;
  scanning$: Subject<boolean> = new Subject<boolean>();
  c1:boolean;
  c2:boolean;
  c3:boolean;
  c4:boolean;
  c1Option={c1:true,c2:false,c3:false,c4:false};
  c2Option={c1:false,c2:true,c3:false,c4:false};
  c3Option={c1:false,c2:false,c3:true,c4:false};
  c4Option={c1:false,c2:false,c3:false,c4:true};
  contador:any=[this.c1Option,this.c2Option,this.c3Option,this.c4Option];

  done:string;
  error:string;
  totalPaychecksLabel:string;
  batchPaychecksLabel:string;

  constructor(private dataTransmission:DataTransmissionService,private chromeBrowser:ChromeBrowserService,
    private informationMessages:InformationMessagesService,private errors:ListErrorScannerService,
    private firefoxBrowser:FirefoxBrowserService,private explorerBrowser:ExplorerBrowserService) { 
    this.error="Error";
    this.totalPaychecksLabel="Total cheques";
    this.batchPaychecksLabel="Cheques escaneados";
    this.alert=false;
    this.images=false;
    this.imagesBatchScanning=null;
    this.circleSystem=false;
    this.circleScanner=false;
    this.spinner=false;
  }

  ngOnInit(): void {
    this.ngUnsubscribe = new Subject();
    this.dataTransmission.accion$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.scanning=response;});
    this.dataTransmission.alert$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.getAlertConditionChrome(response)});
    this.dataTransmission.images$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.getImagesVariableChrome(response);});
    this.dataTransmission.connectingSystem$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.conectarSistema=response);
    this.dataTransmission.circleScanner$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.getCircleScannerChrome(response));
    this.dataTransmission.circleSystem$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.getCircleSystemChrome(response));
    this.dataTransmission.imagesBatchScanning$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.imagesBatchScanning=response);
    this.dataTransmission.informationImages$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.informationImages=response);
    this.dataTransmission.scanningAction$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.executingConnectingAndScanningProcessForChrome(response));
    this.dataTransmission.errorCode$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.setErrorMessageChrome(response));
    this.dataTransmission.displayResultInException$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.displayResultInException=response;});
    this.dataTransmission.nameBrowser$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.setAnimation(response));
    this.dataTransmission.resetVariables$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.resetVariablesToShowResultScanning(response));
    this.dataTransmission.spinnerVariable$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.activateAnimationInExplorer(response));
    this.dataTransmission.setConnectingSystem$(this.informationMessages.getMessageInformation(this.getButtonNameChrome()));
    this.dataTransmission.setImages$(false);
    this.getIdExtension();
    this.dataTransmission.initScanner$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.getActivationScannerControlInt(response));
  }
  
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
    this.scanning$.unsubscribe();
  }

  private getIdExtension(): void {
    if(this.nameBrowser==this.CHROME_BROWSER || this.nameBrowser==this.BROWSER_EDGE){
        this.chromeBrowser.getIdExtensionForBrowser(this.nameBrowser);
    }else if(this.nameBrowser==this.BROWSER_FIREFOX){
        this.firefoxBrowser.getIdExtensionForBrowser(this.nameBrowser);
    }
  }

  private executingConnectingAndScanningProcessForChrome(response){
    if(response && (this.nameBrowser==this.CHROME_BROWSER  || this.nameBrowser==this.BROWSER_EDGE)){
      this.spinner=this.getConditionForSpinner();
      this.setInitialVariablesForConnectingAndScanning();
      this.chromeBrowser.connectingScannerAndScanningProcess(this.conectarEscaner);
    }else if(response && this.nameBrowser==this.BROWSER_FIREFOX){
      this.spinner=this.getConditionForSpinner();
      this.setInitialVariablesForConnectingAndScanning();
      this.firefoxBrowser.connectingScannerAndScanningProcess(this.conectarEscaner);
    }
  }

  private getActivationScannerControlInt(response){
    if(this.nameBrowser==this.BROWSER_EXPLORER && response){
      connectExplorer.setIntScannerMethod().then(response=>{
        this.explorerBrowser.getControlScannerObject(connectExplorer);
        this.explorerBrowser.connectingScannerAndScanningProcess();
      });
    }
  }
  private getButtonNameChrome(): string {
    return this.nameBrowser != this.BROWSER_EXPLORER ? "CONNECT_SYSTEM_BUTTON" : "SHUT_DOWN_SCANNER_BUTTON";
  }
  private setInitialVariablesForConnectingAndScanning(){
    this.ready=true;
    this.standby=false;
    this.images=false;
    this.dataTransmission.setImagesBatchScanning$(null);
  }

  private setErrorMessageChrome(errorCode){
    if(errorCode){
      this.spinner=false;
      this.standby=false;
      this.errorMessage=this.errors.getErrorMessage(errorCode);
      this.displayResultInException=this.getConditionToDisplayResultWithException(errorCode);
      this.dataTransmission.setDisplayResultInException$(this.displayResultInException);
    }
  }

  private getImagesVariableChrome(response){
    this.images=response;
    if(this.images){
      this.scanning$.next(true);
      this.getAmountOfPayChecksChrome();
      this.ready=this.getConditionForReadyState();
      this.spinner=this.updateSpinnerCondition();
      this.standby=false;
    }
  }
  private getAlertConditionChrome(response){
    this.alert=response;
    if(!this.alert){
      this.standby=this.getConditionStandbyForAlertChrome();
      this.ready=this.getConditionForReadyState();
    }else{
      this.spinner=false;
      this.standby=false;
      this.ready=false;
      this.getAmountOfPayChecksForExplorer();
    }
  }
  private getConditionForReadyState(){
    return !this.alert  && this.imagesBatchScanning!=null && (this.circleSystem || (this.circleScanner && this.nameBrowser==this.BROWSER_EXPLORER));
  }
  private getConditionForSpinner(){
    return this.images!=null  && (this.circleSystem || this.circleScanner);
  }
  private getConditionStandbyForAlertChrome(){
    return !this.alert && !this.spinner && !this.ready;
  }
  private updateSpinnerCondition(){
    return !this.ready;
  }
  private setConnectingVariableChrome(){
    return this.conectarSistema==this.informationMessages.getMessageInformation("CONNECT_SYSTEM_BUTTON")?false:true;   
  }
  private getCircleSystemChrome(response){
    this.circleSystem=response;
    if(!this.circleSystem){
      this.dataTransmission.setImages$(false);
    }
  }
  private getConditionToDisplayResultWithException(errorCode){
    let totalPayChecks;
    this.dataTransmission.totalPayChecks$.subscribe(response=>{totalPayChecks=response;});
    if(errorCode==this.SCANNER_NOT_CONNECTED || errorCode==this.DISCONNECTED_EXCEPTION && totalPayChecks==0){
      return false;
    }
    return true;
  }
  private getCircleScannerChrome(response){
    this.circleScanner=response;
    if(this.getConditionCircleScanner()){
      this.spinner=false;
      this.standby=true;
      this.ready=false;   
    }else if(this.circleScanner!=null && this.circleScanner && this.nameBrowser==this.BROWSER_EXPLORER){
      this.spinner=this.getConditionForSpinner();
      this.standby=false;
    }
  }

  private getConditionCircleScanner(){
    return this.circleScanner!=null && this.circleSystem!=null && !this.circleScanner && !this.circleSystem && !this.alert;
  }
  private getAmountOfPayChecksForExplorer(){
    if(this.alert && this.nameBrowser==this.BROWSER_EXPLORER){
      this.getAmountOfPayChecksChrome();
    }
  }
  private getAmountOfPayChecksChrome(){
    this.dataTransmission.totalPayChecks$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.totalChecks=response;});
    if(this.imagesBatchScanning){
      this.paychecksForBatch=this.imagesBatchScanning.length.toString();
      this.totalChecks=this.imagesBatchScanning.length+this.totalChecks;
      this.paychecksTotal=this.totalChecks.toString();
      this.dataTransmission.setTotalPayChecks$(this.totalChecks);
      this.dataTransmission.setPayChecksForBatch$(this.imagesBatchScanning.length);
    }
    this.setOptionForReScanning(this.imagesBatchScanning,this.totalChecks);
    this.setOptionForReScanningInternetExplorer(this.imagesBatchScanning,this.totalChecks);
  }
  private setOptionForReScanning(imagesBatchScanning,totalPaychecks){
    if(imagesBatchScanning!=null  && imagesBatchScanning.length==0 && totalPaychecks==0 && !this.alert){
      this.dataTransmission.setReScanningOption$(true);
      this.dataTransmission.setReScanningOrNextOptions$(false);
      this.dataTransmission.setNextOption$(false);
    }
    if(this.conditionReScanAndNextOptionWithoutAlert(imagesBatchScanning,totalPaychecks) || 
          this.conditionReScanAndNextOptionWithAlert(imagesBatchScanning,totalPaychecks)){
      this.dataTransmission.setReScanningOrNextOptions$(true);
      this.dataTransmission.setNextOption$(false);
      this.dataTransmission.setReScanningOption$(false);
    }
    if(imagesBatchScanning!=null  && imagesBatchScanning.length>0 && totalPaychecks>0 && !this.alert){
      this.dataTransmission.setNextOption$(true);
      this.dataTransmission.setReScanningOrNextOptions$(false);
      this.dataTransmission.setReScanningOption$(false);
    }
  }

  private setOptionForReScanningInternetExplorer(imagesBatchScanning,totalPaychecks){
    if(this.conditionExceptionWithoutResult(imagesBatchScanning,totalPaychecks)){
      this.dataTransmission.setReScanningOption$(false);
      this.dataTransmission.setReScanningOrNextOptions$(false);
      this.dataTransmission.setNextOption$(false);
    }
    if(this.conditionExceptionWithPrevioResult(imagesBatchScanning,totalPaychecks)){
      this.dataTransmission.setReScanningOption$(false);
      this.dataTransmission.setReScanningOrNextOptions$(false);
      this.dataTransmission.setNextOption$(true);
      this.dataTransmission.setDisplayResultInException$(true);
    }
  }
  private resetVariablesToShowResultScanning(response){
    if(response){
      this.ready=false;
      this.displayResultInException=false;
      this.alert=false;
      this.standby=true;
    }
  }
  private activateAnimationInExplorer(response){
    if(response && this.nameBrowser==this.BROWSER_EXPLORER){
      this.spinner=response;
      this.startAnimationExplorer();
      this.ready=false;
      this.standby=false;
    }
  }
  private setAnimation(response){
    this.nameBrowser=response
    if(response==this.BROWSER_EXPLORER){
      this.animation=true;
    }else{
      this.animation=false;
    }
  }
  private startAnimationExplorer(){
    let counter=0;
    const result= this.getIntervalObservableForScanning();
    result.subscribe(response=>{
      this.c1=this.contador[counter].c1;
      this.c2=this.contador[counter].c2;
      this.c3=this.contador[counter].c3;
      this.c4=this.contador[counter].c4;
      counter=counter+1;
      if(counter==4){
        counter=0;
      }
    });
  }
  private getIntervalObservableForScanning(){
    this.scanning$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.scanning$));
    return result;
  }
  private conditionExceptionWithoutResult(imagesBatchScanning,totalPaychecks){
    return (imagesBatchScanning!=null  && imagesBatchScanning.length==0 && totalPaychecks==0 && 
              this.alert && this.nameBrowser==this.BROWSER_EXPLORER);
  }
  private conditionExceptionWithPrevioResult(imagesBatchScanning,totalPaychecks){
    return (imagesBatchScanning!=null  && (imagesBatchScanning.length==0 || imagesBatchScanning.length>0) && totalPaychecks>0 &&
      this.alert && this.nameBrowser==this.BROWSER_EXPLORER);
  }
  private conditionReScanAndNextOptionWithoutAlert(imagesBatchScanning,totalPaychecks){
    return imagesBatchScanning!=null  && imagesBatchScanning.length==0 && totalPaychecks>0 && !this.alert;
  }
  private conditionReScanAndNextOptionWithAlert(imagesBatchScanning,totalPaychecks){
    return imagesBatchScanning!=null  && imagesBatchScanning.length>0 && totalPaychecks>0 && this.alert;
  }
}
