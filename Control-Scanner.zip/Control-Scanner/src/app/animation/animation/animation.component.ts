import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import { DataTransmissionService } from 'src/app/service/data-transmission.service';
import { Subject } from 'rxjs';
import { ChromeBrowserService } from 'src/app/chrome-service/chrome-browser.service';
import { InformationMessagesService } from 'src/app/service/information-messages.service';
import { ListErrorScannerService } from 'src/app/service/list-error-scanner.service';
import { FirefoxBrowserService } from 'src/app/firefox-service/firefox-browser.service';

@Component({
  selector: 'app-animation',
  templateUrl: './animation.component.html',
  styleUrls: ['./animation.component.css']
})
export class AnimationComponent implements OnInit {

  @Input() conectarEscaner;
  alert:boolean;
  circleScanner:boolean;
  circleSystem:boolean;
  images:boolean;
  scanning:string;
  spinner:boolean;
  conectarSistema:string;
  imagesBatchScanning:Array<any>;
  informationImages:Array<any>=[];
  ready:boolean;
  errorMessage:string;
  standby:boolean;
  paychecksForBatch:string;
  paychecksTotal:string;
  nameBrowser:string;
  private BROWSER_FIREFOX="Firefox";
  private CHROME_BROWSER="Chrome";

  done:string;
  error:string;
  totalPaychecksLabel:string;
  batchPaychecksLabel:string;

  constructor(private dataTransmission:DataTransmissionService,private chromeBrowser:ChromeBrowserService,
    private informationMessages:InformationMessagesService,private errors:ListErrorScannerService,
    private firefoxBrowser:FirefoxBrowserService) { 
    this.error="Error";
    this.totalPaychecksLabel="Total cheques";
    this.batchPaychecksLabel="Cheques escaneados";
    this.alert=false;
    this.images=false;
    this.imagesBatchScanning=null;
    this.circleSystem=false;
    this.circleScanner=false;
    this.spinner=false;
  }

  ngOnInit(): void {
    this.dataTransmission.accion$.subscribe(response=>{this.scanning=response;});
    this.dataTransmission.alert$.subscribe(response=>{this.getAlertConditionChrome(response)});
    this.dataTransmission.images$.subscribe(response=>{this.getImagesVariableChrome(response);});
    this.dataTransmission.connectingSystem$.subscribe(response=>this.conectarSistema=response);
    this.dataTransmission.circleScanner$.subscribe(response=>this.getCircleScannerChrome(response));
    this.dataTransmission.circleSystem$.subscribe(response=>this.getCircleSystemChrome(response));
    this.dataTransmission.imagesBatchScanning$.subscribe(response=>this.imagesBatchScanning=response);
    this.dataTransmission.informationImages$.subscribe(response=>this.informationImages=response);
    this.dataTransmission.scanningAction$.subscribe(response=>this.executingConnectingAndScanningProcessForChrome(response));
    this.dataTransmission.errorCode$.subscribe(response=>this.setErrorMessageChrome(response));
    this.dataTransmission.nameBrowser$.subscribe(response=>this.nameBrowser=response);
  }
  
  private executingConnectingAndScanningProcessForChrome(response){
    if(response && this.nameBrowser==this.CHROME_BROWSER){
      this.spinner=this.getConditionForSpinner();
      this.setInitialVariablesForConnectingAndScanning();
      this.chromeBrowser.connectingScannerAndScanningProcess(this.conectarEscaner);
    }else if(response && this.nameBrowser==this.BROWSER_FIREFOX){
      this.spinner=this.getConditionForSpinner();
      this.setInitialVariablesForConnectingAndScanning();
      this.firefoxBrowser.connectingScannerAndScanningProcess(this.conectarEscaner);
    }
  }
  private setInitialVariablesForConnectingAndScanning(){
    this.ready=true;
    this.standby=false;
    this.images=false;
    this.dataTransmission.setImagesBatchScanning$(null);
  }
  private setErrorMessageChrome(errorCode){
    this.spinner=false;
    this.errorMessage=this.errors.getErrorMessage(errorCode);
  }

  private getImagesVariableChrome(response){
    this.images=response;
    this.getAmountOfPayChecksChrome();
    this.ready=this.getConditionForReadyStateChrome();

  }
  private getAlertConditionChrome(response){
    this.alert=response;
    this.standby=this.getConditionStandbyForAlertChrome();
    this.ready=this.getConditionForReadyStateChrome();
  }
  private getConditionForReadyStateChrome(){
    return !this.alert  && this.imagesBatchScanning!=null && this.circleSystem;
  }
  private getConditionForSpinner(){
    return this.images!=null  && this.circleSystem;
  }
  private getConditionStandbyForAlertChrome(){
    return !this.alert && !this.spinner;
  }
  private setConnectingVariableChrome(){
    return this.conectarSistema==this.informationMessages.getMessageInformation("CONNECT_SYSTEM_BUTTON")?false:true;   
  }
  private getCircleSystemChrome(response){
    this.circleSystem=response;
    if(!this.circleSystem){
      this.standby=true;
      this.dataTransmission.setImages$(false);
    }
  }
  private getCircleScannerChrome(response){
    this.circleScanner=response;
    if(this.circleScanner!=null && !this.circleScanner && !this.alert){
      this.spinner=false;
      this.standby=true;
      this.ready=false;   
    }
  }
  private getAmountOfPayChecksChrome(){
    if(this.informationImages){
      this.paychecksTotal=this.informationImages.length.toString();
    }
    if(this.imagesBatchScanning){
      this.paychecksForBatch=this.imagesBatchScanning.length.toString();
    }
  }
}
