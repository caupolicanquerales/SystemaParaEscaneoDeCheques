import { Injectable } from '@angular/core';
import { InformationFromScannerService } from '../service/information-from-scanner.service';
import { ListErrorScannerService } from '../service/list-error-scanner.service';
import { ListExtensionIdsService } from '../service/list-extension-ids.service';
import * as connectFirefox from 'src/app/jsfiles/ConnectingToBackgroundFirefox.js';
import { InformationMessagesService } from '../service/information-messages.service';
import { DataTransmissionService } from '../service/data-transmission.service';
import { Observable,of,from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FirefoxBrowserService {

  error:string;
  informationImages:Array<any>=[];
  connectingSystem:string;
  connectingScanner:string;
  forceShutDownScanner:boolean;
  idForExtension:string;
  private CHECKING_SYSTEM:string="SERVER IS OK";
  private EXIT_SYSTEM:string= "EXIT IS OK FIREFOX";
  private EXIT_LAUNCH_SOCKET:string="SALIR";
  private resultConnectingScanner={};
  private connectionScannerFlag:boolean=false;
  private connectionSystemFlag:boolean=false;
  private scanningExceptionFlag:boolean=false;
  private EXCEPTION_STATE:string="6";
  private READY_STATE:string="4";
  private FLOW_STATE:string="5";
  private POWER_OFF_STATE:string="1";
  private IDLE_STATE:string="2";
  private EMPTY_EXCEPTION:string="";
  private EMPTY_ARRAY:string="[]";
  private CONNECTED:string='conectado';
  
  constructor(private information:InformationFromScannerService,
    private errors:ListErrorScannerService,private extensionId:ListExtensionIdsService,
    private informationMessages:InformationMessagesService,private dataTransmission:DataTransmissionService) { }
    

    getIdExtensionForBrowser(nameBrowser){
      this.idForExtension=this.extensionId.getIdExtensionForBrowser(nameBrowser);
    }

    connectSystemClientServer(connectingSystem){
      this.connectingSystem=connectingSystem;
      if(this.getConditionForConnectingSystem()){
        this.sendAccion$(this.informationMessages.getMessageInformation("CONNECTING_SYSTEM"));
        this.launchServerSystem();
      }else if(this.getConditionForShutdownSystemAndScanner()){
        this.shuttingDownScanner();
      }else if(this.getConditionForShutdownSystem()){
        this.shutDownLaunchSocketServerApp();
      }    
    }
    
    private launchServerSystem(){
      const serverObservable= from(connectFirefox.launchServerSystem(this.idForExtension));
      serverObservable.subscribe(res=>this.launchClientSystem(res),
        error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
    }
    private launchClientSystem(response){
      if(response==this.CONNECTED){
        const clientObservable= from(connectFirefox.launchClientSystem(this.idForExtension));
        clientObservable.subscribe(res=>this.checkingClientServerSystem(res),
          error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
      }
    }
    private checkingClientServerSystem(response){
      if(response==this.CONNECTED){
        this.connectionSystemFlag=true;
        setTimeout(()=>{
          const checkingObservable= from(connectFirefox.checkingClientServerSystem(this.idForExtension));
          checkingObservable.subscribe(res=>this.setVariablesWhenCheckingClientServerSystem(res),
            error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
        },1000);
      }
    }
    private setVariablesWhenCheckingClientServerSystem(response){
      if(response==this.CHECKING_SYSTEM){
        this.sendLabelSystem$(this.informationMessages.getMessageInformation("CONNECTED_SYSTEM"));
        this.sendCircleSystem$(true);
        this.sendAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
        this.sendConnectingSystem$(this.informationMessages.getMessageInformation("SHUT_DOWN_SYSTEM_BUTTON"));
      }
    }

    private closeServerSystem(){
      const  closeServerObservable= from(connectFirefox.closeServerSystem(this.idForExtension));
      closeServerObservable.subscribe(res=>this.closeServerSystemResult(res),
        error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
   }
    private closeServerSystemResult(resultado){
      if(resultado==this.EXIT_SYSTEM){
        this.sendConnectingSystem$(this.informationMessages.getMessageInformation("CONNECT_SYSTEM_BUTTON"));
        this.sendLabelSystem$(this.informationMessages.getMessageInformation("DISCONNECTED_SYSTEM"));
        this.sendCircleSystem$(false);
        this.sendImages$(true);
        this.sendAlert$(false);
        this.sendScanningAction$(false);
      }
    }

    private shutDownLaunchSocketServerApp(){
      const shutDownLaunchSocketObservable= from(connectFirefox.shutDownLaunchSocketApp(this.idForExtension));
      shutDownLaunchSocketObservable.subscribe(res=>this.getShutDownLaunchSocketServerResult(res),
        error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
    }
    private getShutDownLaunchSocketServerResult(resultado){
      if(resultado==this.EXIT_LAUNCH_SOCKET){
        this.closeServerSystem();
      }
    }
  
    connectingScannerAndScanningProcess(connectingScanner){
      this.connectingScanner=connectingScanner
      this.sendAlert$(false);
      if(this.getConditionInitialForConnectingScannerAndScanning()){
        this.sendAccion$(this.informationMessages.getMessageInformation("CONNECTING_SCANNER"));
        this.resultConnectingScanner={};
        this.setConnectingScanner();
      }else if(this.getConditionForScanningAction()){
        this.scanning();
      }
    }
  
    private shuttingDownScanner(){
      if(this.connectionSystemFlag==true){
        this.sendAccion$(this.informationMessages.getMessageInformation("SHUTTING_DOWN_SCANNER"));
        //this.sendInformationImages$(new Array<any>());
        this.goIdleStateScanner();
      }else if(this.connectionSystemFlag==false){
        this.sendWarningMessage$(this.informationMessages.getMessageInformation("messageWarnigConnectionScanner"))
      }
    }
    
    private setConnectingScanner(){
      const connectingScannerObservable= from(connectFirefox.connectingScanner(this.idForExtension));
      connectingScannerObservable.subscribe(res=>this.getConnectionScannerResponse(res),
        error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION"))); 
    }
    private getConnectionScannerResponse(resultado){
      if(resultado){
        this.information.getInformationFromScanning(resultado);
        this.sendInformationImages$(new Array<any>());
        this.checkingExceptionConnectingScanner();
      }
    }
    private goIdleStateScanner(){
      const goIdleStatecannerObservable= from(connectFirefox.goIdleStateScanner(this.idForExtension));
      goIdleStatecannerObservable.subscribe(res=>this.getIdleStateScannerResult(res),
        error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
    }
    private getIdleStateScannerResult(resultado){
      if(resultado){
        this.information.getInformationFromScanning(resultado);
        this.checkingExceptionGoIdleState(this.information);
      }
    }
    private checkingExceptionGoIdleState(information:InformationFromScannerService){
      if(information.getException()==this.EMPTY_EXCEPTION && information.getConnectingResult()==this.IDLE_STATE){
        this.shutDownScannerAndSystem();
      }else{
        this.sendAlert$(true);
      }
    }
    private shutDownScanner(){
      const shutDownScannerObservable= from(connectFirefox.shutDownScanner(this.idForExtension));
      shutDownScannerObservable.subscribe(res=>this.getShutDownScannerResult(res),
        error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
   }
    private shutDownScannerAndSystem(){
      const shutDownScannerObservable= from(connectFirefox.shutDownScanner(this.idForExtension));
      shutDownScannerObservable.subscribe(res=>this.getShutDownScannerAndSystemResult(res),
        error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
    }

    private getShutDownScannerResult(resultado){
      if(resultado){
        this.information.getInformationFromScanning(resultado);
        this.setVariablesForConnectingScanner();
        this.sendLabelScanner$(this.informationMessages.getMessageInformation("DISCONNECTED_SCANNER"));
        this.sendAccion$(this.getMessageAccionWhenShutDownScanner());
        this.scanningExceptionFlag=false;
      }
    }
    private getShutDownScannerAndSystemResult(resultado){
      this.getShutDownScannerResult(resultado);
      this.shutDownLaunchSocketServerApp();
    }
    private checkingExceptionConnectingScanner(){
      if(this.getConditionForConnetionScanner() || this.scanningExceptionFlag==true){
        this.setVariablesForClosingScanner();
        this.scanning();
      }else if(this.information.getException()!=this.EMPTY_EXCEPTION){
        this.error=this.getErrorMessage(this.information.getException());
        this.sendErrorCode$(this.information.getException());
        this.setVariablesForConnectingScanner();
        this.sendAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
        this.sendAlert$(true);
        this.forceShutDownScanner=false;
        this.shutDownScannerAndSystem();
      }else if(this.getConditionStartingFromFlowState()){
        this.forceShutDownScanner=true;
        this.shutDownScanner();
      }else if(this.getConditionStartingFromExceptionState()){
        this.setVariablesForConnectingScanner();
        this.sendAlert$(false);
        this.forceShutDownScanner=false;
        this.sendAccion$(this.informationMessages.getMessageInformation("CHECKING_CONNECTION_SCANNER"));
      }
    }
    private setVariablesForConnectingScanner(){
      this.connectionScannerFlag=false;
      this.sendSerialScanner$("SERIAL: "+this.information.getSerial());
      this.sendCircleScanner$(false);
    }
    private setVariablesForClosingScanner(){
      this.sendLabelScanner$(this.informationMessages.getMessageInformation("CONNECTED_SCANNER"));
      this.sendSerialScanner$("SERIAL: "+this.information.getSerial());
      this.connectionScannerFlag=true;
      this.sendCircleScanner$(true);
      this.forceShutDownScanner=false;
      this.sendAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
    }
  
    private scanning(){
      if(this.getConditionalForScanningProcessWithoutException()){
        this.scanningProcessing();
      }else if(!this.getConditionalForSystemOrScannerConnection()){
        this.sendWarningMessage$(this.informationMessages.getMessageInformation("messageWarnigScanning"));
      }else if(this.getConditionalForScanningProcessWithException()){
        this.sendWarningMessage$(this.informationMessages.getMessageInformation("messageInfoToCloseScanner"));
      }
    }
  
    private scanningProcessing(){
      this.sendAlert$(false);
      this.sendAccion$(this.informationMessages.getMessageInformation("SCANNING"));
      var message=this.informationMessages.getMessageInformation("EMPTY_EXCEPTION");
      const scanningProcessingObservable= from(connectFirefox.scanningProcessing(this.idForExtension));
      scanningProcessingObservable.subscribe(res=>this.getChuckOfInformations(res,message),
        error=>this.sendAccion$(this.informationMessages.getMessageInformation("ERROR_OF_CONNECTION")));
    }
    private getChuckOfInformations(resultado,message){
      if(resultado){
        let initialChunk=this.information.getObjectOfInformation(resultado);
        this.lookingForExceptionInitialChunk(initialChunk,message,resultado);
      }
    }
    private lookingForExceptionInitialChunk(initialChunk,message,firstChuckInformation){
      if(this.getConditionForScanning(initialChunk)){
        this.sendAccion$(this.informationMessages.getMessageInformation("LOADING_INFORMATION"));
        this.getChucksOfInformation(initialChunk,message,firstChuckInformation);
      }else if(this.getConditionForScanningWithOnlyException(initialChunk)){
        this.getChucksOfInformation(initialChunk,message,firstChuckInformation);
        this.sendInformationImages$(new Array<any>());
      }else if(this.getConditionForScanningWithoutResult(initialChunk)){
        this.getChucksOfInformationWithoutResult(message,firstChuckInformation);
      }
    } 
    private getChucksOfInformation(initialChunk,message,firstChuckInformation){
      message=message.concat(firstChuckInformation);
      this.dataTransmission.informationImages$.subscribe(response=>this.informationImages=response);
      const callingChuckInformationObservable= from(connectFirefox.callingChuckInformation(message,this.idForExtension));
      callingChuckInformationObservable.subscribe(res=>this.getInformationFromScanningProcess(res),error=>error);
    }
    private getInformationFromScanningProcess(response){
      let images=this.getInformationFromScanner(response);
      this.informationImages= this.informationImages.concat(images);
      this.sendInformationImages$(this.informationImages);
      this.sendImagesBatchScanning$(images);
      this.sendAccion$(this.informationMessages.getMessageInformation("LOADED_IMAGES"));
      this.sendImages$(true);
      this.ShutDownScannerFromScanningProcess(this.resultConnectingScanner["exep"]);
    }

    private getChucksOfInformationWithoutResult(message,firstChuckInformation){
      message=message.concat(firstChuckInformation);
      this.error=this.getErrorMessage(this.information.getException());
      this.sendAccion$(this.informationMessages.getMessageInformation("LOADING_INFORMATION"));
      const callingChuckInformationObservable= from(connectFirefox.callingChuckInformation(message,this.idForExtension));
      callingChuckInformationObservable.subscribe(res=>this.callingChuckInformationWithoutResult(res),error=>error);
    }
    private callingChuckInformationWithoutResult(response){
      let images=this.getInformationFromScanner(response);
      this.sendImagesBatchScanning$(images);
      this.sendAccion$(this.informationMessages.getMessageInformation("NO_IMAGES"));
      this.sendImages$(false);
      this.ShutDownScannerFromScanningProcess(this.resultConnectingScanner["exep"]);
    }
    private ShutDownScannerFromScanningProcess(error){
      if(error && error!=this.EMPTY_EXCEPTION){
        this.error=error;
        this.scanningExceptionFlag=true;
        this.sendAlert$(true); 
      }
        this.shutDownScannerAndSystem();
      
    }
  
    private getInformationFromScanner(message):Array<any>{
      this.resultConnectingScanner=this.information.getObjectOfInformation(message);
      this.setScannerState(this.resultConnectingScanner);
      this.getExceptionFromScanningProcess(this.resultConnectingScanner);
      this.resultConnectingScanner["docRead"]=this.information.getDocumentInformation(this.resultConnectingScanner["docRead"]);
      this.resultConnectingScanner["docImage"]=this.information.getDocumentInformation(this.resultConnectingScanner["docImage"]);
      this.resultConnectingScanner=this.information.removeFirstAndLastCharOfcmc7(this.resultConnectingScanner);
      return this.information.integrateAllInformationInArray(this.resultConnectingScanner);
    }
  
    private setScannerState(resultConnectingScanner){
      if(resultConnectingScanner["state"]==this.POWER_OFF_STATE){
        this.sendSerialScanner$(resultConnectingScanner["serial"]);
        this.sendLabelScanner$(this.informationMessages.getMessageInformation("DISCONNECTED_SCANNER"));
        this.sendCircleScanner$(false);
      }
    }
  
    private getExceptionFromScanningProcess(resultConnectingScanner){
      if(resultConnectingScanner["exep"]!=this.EMPTY_EXCEPTION){
        this.sendErrorCode$(resultConnectingScanner["exep"]);
        this.scanningExceptionFlag=true;
        this.sendAlert$(true);
      }else{
        this.sendErrorCode$(null);
      }
    }
  
    private getErrorMessage(errorCode:string){
      return this.errors.getErrorMessage(errorCode);
    }
    private getConditionalForScanningProcessWithoutException():boolean{
      return (this.getConditionalForSystemOrScannerConnection() && this.scanningExceptionFlag==false);
    }
    private getConditionalForSystemOrScannerConnection():boolean{
      return (this.connectionSystemFlag==true && this.connectionScannerFlag==true); 
    }
    private getConditionalForScanningProcessWithException():boolean{
      return (this.getConditionalForSystemOrScannerConnection() && this.scanningExceptionFlag==true);
    }
    private getConditionForScanningWithOnlyException(initialChunk):boolean{
      return (initialChunk["state"]==this.EXCEPTION_STATE && initialChunk["docImage"]==this.EMPTY_ARRAY);
    }
    private getConditionForScanningWithoutResult(initialChunk):boolean{
      return ((initialChunk["state"]==this.READY_STATE || initialChunk["state"]==this.FLOW_STATE) && initialChunk["docImage"]==this.EMPTY_ARRAY);
    }
    private getConditionForScanning(initialChunk):boolean{
      return (initialChunk["docImage"]!=this.EMPTY_ARRAY);
    }
    private getConditionForConnetionScanner():boolean{
      return (this.information.getException()==this.EMPTY_EXCEPTION && this.information.getConnectingResult()!=this.FLOW_STATE 
      && this.information.getConnectingResult()!=this.EXCEPTION_STATE && this.information.getSerial()!=this.EMPTY_EXCEPTION);
    }
    private getConditionStartingFromFlowState():boolean{
        return this.information.getException()==this.EMPTY_EXCEPTION && this.information.getConnectingResult()==this.FLOW_STATE;
    }
    private getConditionStartingFromExceptionState():boolean{
      return this.information.getException()==this.EMPTY_EXCEPTION && this.information.getSerial()==this.EMPTY_EXCEPTION && 
        (this.information.getConnectingResult()==this.EXCEPTION_STATE || this.information.getConnectingResult()==this.READY_STATE);
    }
    private getConditionInitialForConnectingScannerAndScanning(){
      return this.connectingScanner==this.informationMessages.getMessageInformation("SCANNING_BUTTON") && this.connectionSystemFlag==true && this.connectionScannerFlag==false;
    }
    private getConditionForScanningAction(){
      return this.connectingScanner==this.informationMessages.getMessageInformation("SCANNING_BUTTON") &&  this.connectionScannerFlag==true;
    }
    private getConditionForShutdownSystemAndScanner(){
      return this.connectingSystem==this.informationMessages.getMessageInformation("SHUT_DOWN_SYSTEM_BUTTON") && this.connectionSystemFlag==true && this.connectionScannerFlag==true;
    }
    private getConditionForShutdownSystem(){
      return this.connectingSystem==this.informationMessages.getMessageInformation("SHUT_DOWN_SYSTEM_BUTTON") && this.connectionSystemFlag==true && this.connectionScannerFlag==false;
    }
    private getConditionForConnectingSystem(){
      return this.connectingSystem==this.informationMessages.getMessageInformation("CONNECT_SYSTEM_BUTTON") && this.connectionScannerFlag==false;
    }
    private getMessageAccionWhenShutDownScanner(){
      return this.forceShutDownScanner==true?this.informationMessages.getMessageInformation("FORCE_SHUT_DOWN_SCANNER"):this.EMPTY_EXCEPTION;
    }
    private sendAccion$(message){
      this.dataTransmission.setAccion$(message);
    }
    private sendAlert$(alert){
      this.dataTransmission.setAlert$(alert);
    }
    private sendImages$(images){
      this.dataTransmission.setImages$(images);
    }
    private sendLabelSystem$(labelSystem){
      this.dataTransmission.setLabelSystem$(labelSystem);
    }
    private sendLabelScanner$(labelScanner){
      this.dataTransmission.setLabelScanner$(labelScanner);
    }
    private sendCircleScanner$(circleScanner){
      this.dataTransmission.setCircleScanner$(circleScanner);
    }
    private sendCircleSystem$(circleSystem){
      this.dataTransmission.setCircleSystem$(circleSystem);
    }
    private sendSerialScanner$(serialScanner){
      this.dataTransmission.setSerialScanner$(serialScanner);
    }
    private sendErrorCode$(errorCodeMessage){
      this.dataTransmission.setErrorCode$(errorCodeMessage);
    }
    private sendWarningMessage$(warningMessage){
      this.dataTransmission.setWarningMessage$(warningMessage);
    }
    private sendSuccessMessage$(successMessage){
      this.dataTransmission.setSuccessMessage$(successMessage);
    }
    private sendConnectingSystem$(connectingSystem){
      this.dataTransmission.setConnectingSystem$(connectingSystem);
    }
    private sendInformationImages$(informationImages){
      this.dataTransmission.setInformationImages$(informationImages);
    }
    private sendImagesBatchScanning$(imagesBatchScanning){
      this.dataTransmission.setImagesBatchScanning$(imagesBatchScanning);
    }
    private sendScanningAction$(scanningAction){
      this.dataTransmission.setScanningAction$(scanningAction);
    }
}