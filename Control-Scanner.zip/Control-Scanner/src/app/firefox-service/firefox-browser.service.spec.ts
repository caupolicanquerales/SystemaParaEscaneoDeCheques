import { TestBed } from '@angular/core/testing';

import { FirefoxBrowserService } from './firefox-browser.service';

describe('FirefoxBrowserService', () => {
  let service: FirefoxBrowserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirefoxBrowserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
