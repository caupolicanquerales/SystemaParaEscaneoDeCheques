import { Component, Input, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { DataTransmissionService } from '../service/data-transmission.service';
import { InformationMessagesService } from '../service/information-messages.service';
import { ValidationCm7Service } from '../service/validation-cm7.service';
import { ChromeBrowserService } from 'src/app/chrome-service/chrome-browser.service';
import { ExplorerBrowserService } from 'src/app/explorer-service/explorer-browser.service';
import * as connect from 'src/app/jsFiles/controlScanner.js';
import { FirefoxBrowserService } from '../firefox-service/firefox-browser.service';

@Component({
  selector: 'app-main-front-prototype',
  templateUrl: './main-front-prototype.component.html',
  styleUrls: ['./main-front-prototype.component.css']
})
export class MainFrontPrototypeComponent implements OnInit {

  @Input() typeBrowser:boolean;
  @Input() nameBrowser:string;

  title = 'Ambiente para escaneo';
  etiquetaSistema:string;
  circleSistema:boolean;
  etiquetaEscaner:string;
  circleEscaner:boolean;
  accion:string;
  error:string;
  serialEscaner:string;
  conectarSistema:string;
  conectarEscaner:string;
  titleImagenes:string;
  imagenes:boolean;
  informationImages:Array<any>=[];
  duplicationCm7Message:string;
  cm7Duplication:Array<any>;
  private EMPTY_EXCEPTION="";
  private BROWSER_EXPLORER="Explorer";
  private BROWSER_FIREFOX="Firefox";
  private CHROME_BROWSER="Chrome";

  constructor(private toastr: ToastrService,private informationMessages:InformationMessagesService,
    private validationCm7:ValidationCm7Service,private sanitizer: DomSanitizer,private dataTransmission:DataTransmissionService,
    private chromeBrowser:ChromeBrowserService,private explorerBrowser:ExplorerBrowserService,
    private firefoxBrowser:FirefoxBrowserService) { 
    this.titleImagenes='IMAGENES ESCANEADAS';
    this.circleEscaner=false;
    this.circleSistema=false;
    this.cm7Duplication=[];
    this.conectarEscaner=this.informationMessages.getMessageInformation("SCANNING_BUTTON");
    this.duplicationCm7Message=this.informationMessages.getMessageInformation("DUPLICATION_IMAGE");
    this.setInicialVariables();
  }

  ngOnInit(): void {
    this.dataTransmission.accion$.subscribe(response=>{this.accion=response;});
    this.dataTransmission.images$.subscribe(response=>{this.imagenes=response});
    this.dataTransmission.labelSystem$.subscribe(response=>{this.etiquetaSistema=response;});
    this.dataTransmission.labelScanner$.subscribe(response=>{this.etiquetaEscaner=response;});
    this.dataTransmission.serialScanner$.subscribe(response=>this.serialEscaner=response);
    this.dataTransmission.connectingSystem$.subscribe(response=>this.conectarSistema=response);
    this.dataTransmission.circleSystem$.subscribe(response=>this.circleSistema=response);
    this.dataTransmission.circleScanner$.subscribe(response=>this.circleEscaner=response);
    this.dataTransmission.informationImages$.subscribe(response=>this.getDuplicationCm7(response));
    this.dataTransmission.warningMessage$.subscribe(response=>this.warningMessage(response));
    this.dataTransmission.setConnectingSystem$(this.informationMessages.getMessageInformation(this.getButtonNameChrome()));
    this.dataTransmission.setNameBrowser$(this.nameBrowser);
    this.getIdExtension();
    this.getActivationScannerControlInt();
  }

  private setInicialVariables(){
    this.dataTransmission.setLabelSystem$(this.informationMessages.getMessageInformation("DISCONNECTED_SYSTEM"));
    this.dataTransmission.setLabelScanner$(this.informationMessages.getMessageInformation("DISCONNECTED_SCANNER"));
    this.dataTransmission.setAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
    this.dataTransmission.setSerialScanner$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
    this.dataTransmission.setCircleScanner$(false);
    this.dataTransmission.setCircleScanner$(false);
    this.dataTransmission.setInformationImages$(this.informationImages);
  }
  connectSystemClientServer(){
    if(this.nameBrowser==this.BROWSER_EXPLORER){
      this.explorerBrowser.shutdownScanner();
    }else if (this.nameBrowser==this.BROWSER_FIREFOX){
      this.firefoxBrowser.connectSystemClientServer(this.conectarSistema);
    }else{
      this.chromeBrowser.connectSystemClientServer(this.conectarSistema);
    }
  }
  connectingScannerAndScanningProcess(){
    if(this.nameBrowser==this.BROWSER_EXPLORER){
      this.explorerBrowser.connectingScannerAndScanningProcess();
    }else {
      this.dataTransmission.setScanningAction$(true);
    }
  }
  deleteAllImages(){
    this.dataTransmission.setInformationImages$(new Array<any>());
    this.accion=this.informationMessages.getMessageInformation("EMPTY_EXCEPTION");
    this.successMessage(this.informationMessages.getMessageInformation("messageSuccessDeleteAllImages"));
  }

  getColorForDuplicationCm7(dr1){
    this.validationCm7.getCm7DuplicationArray(this.cm7Duplication);
    return this.validationCm7.getColorForDuplicationCm7(dr1);
  }
  getFlagForDuplicationCm7(dr1){
    this.validationCm7.getCm7DuplicationArray(this.cm7Duplication);
    if(this.nameBrowser==this.BROWSER_EXPLORER){
      this.validationCm7.getFlagForDuplicationCm7Explorer(dr1);
    }
    return this.validationCm7.getFlagForDuplicationCm7Chrome(dr1);
  }
  private getIdExtension(){
    if(this.nameBrowser==this.CHROME_BROWSER){
      this.chromeBrowser.getIdExtensionForBrowser(this.nameBrowser);
    }else if(this.nameBrowser==this.BROWSER_FIREFOX){
      this.firefoxBrowser.getIdExtensionForBrowser(this.nameBrowser);
    }
  }
  private getActivationScannerControlInt(){
    if(this.nameBrowser==this.BROWSER_EXPLORER){
      connect.initScanner();
      this.explorerBrowser.getControlScannerObject(connect);
    }
  }

  getImage(imageBase64){
    return this.sanitizer.bypassSecurityTrustResourceUrl('data:image/png;base64,'+imageBase64);
  }
  deleteImageSelected(idDoc){
    this.informationImages=this.informationImages.filter(image=>image.idDoc!=idDoc);
    this.dataTransmission.setInformationImages$(this.informationImages);
    this.successMessage(this.informationMessages.getMessageInformation("messageSuccessDeleteImage"));
  }

  private getDuplicationCm7(informationImages){
    this.informationImages=informationImages;
    this.cm7Duplication=[];
    if(informationImages!=null &&  informationImages.length>0){
      this.cm7Duplication=this.validationCm7.findDuplicateCm7(informationImages);
    }
  }

  private warningMessage(message){
      if(message!=null && message!=this.EMPTY_EXCEPTION){
        this.toastr.warning(message,"Precaucion",{timeOut:2000,});
      }
  }
  private successMessage(message){
    this.toastr.success(message,"Operación exitosa",{timeOut:2000,});
  }
  
  private informationMessage(message){
    this.toastr.info(message,"Mensaje de información",{timeOut:2000,});
  }
  private getButtonNameChrome(){
    return this.nameBrowser!=this.BROWSER_EXPLORER?"CONNECT_SYSTEM_BUTTON":"SHUT_DOWN_SCANNER_BUTTON";
  }
  conditionAnimationForChromeOrFireFox(){
    return this.nameBrowser!=this.BROWSER_EXPLORER && this.typeBrowser!=null;
  }
  conditionAnimationForExplorer(){
    return this.nameBrowser==this.BROWSER_EXPLORER && this.typeBrowser==null;
  }
  conditionLabelConnectingSystem(){
    return this.typeBrowser!=null;
  } 
}
