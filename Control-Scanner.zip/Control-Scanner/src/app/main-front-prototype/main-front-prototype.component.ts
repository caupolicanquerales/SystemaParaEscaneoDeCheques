import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { DomSanitizer,SafeUrl } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { DataTransmissionService } from '../service/data-transmission.service';
import { InformationMessagesService } from '../service/information-messages.service';
import { ValidationCm7Service } from '../service/validation-cm7.service';
import { ChromeBrowserService } from 'src/app/chrome-service/chrome-browser.service';
import { ExplorerBrowserService } from 'src/app/explorer-service/explorer-browser.service';
import { FirefoxBrowserService } from '../firefox-service/firefox-browser.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-main-front-prototype',
  templateUrl: './main-front-prototype.component.html',
  styleUrls: ['./main-front-prototype.component.css']
})
export class MainFrontPrototypeComponent implements OnInit, OnDestroy {

  @Input() typeBrowser:boolean;
  @Input() nameBrowser:string;

  title = 'Ambiente para escaneo';
  etiquetaSistema:string;
  circleSistema:boolean;
  etiquetaEscaner:string;
  circleEscaner:boolean;
  accion:string;
  error:string;
  serialEscaner:string;
  conectarSistema:string;
  conectarEscaner:string;
  titleImagenes:string;
  imagenes:boolean;
  informationImages:Array<any>=[];
  duplicationCm7Message:string;
  cm7Duplication:Array<any>;
  idDocF:Array<string>;
  idDocR:Array<string>;
  urlF:SafeUrl;
  urlR:SafeUrl;
  urlRArray:Array<Array<SafeUrl>>;
  urlFArray:Array<Array<SafeUrl>>;
  enableButtonReScanning:boolean;
  enableButtonNext:boolean;
  enableScanningInitial:boolean;
  nameButtonNext:string;
  totalPayChecks:number;
  private alert:boolean;
  private reScanningOption:boolean;
  private reScanning:boolean;
  private nextOption:boolean;
  private reScanningAndNext:boolean;
  private displayResultInException:boolean;
  private ngUnsubscribe: Subject<void>;
  private errorCode:string;
  private EMPTY_EXCEPTION="";
  private BROWSER_EXPLORER="Explorer";
  private BROWSER_FIREFOX="Firefox";
  private CHROME_BROWSER="Chrome";
  private BROWSER_EDGE="Edge";
  private SCANNER_NOT_CONNECTED="-1";
  private DISCONNECTED_EXCEPTION="0001600002";
  private errorConnection=[this.SCANNER_NOT_CONNECTED,this.DISCONNECTED_EXCEPTION];

  constructor(private toastr: ToastrService,private informationMessages:InformationMessagesService,
    private validationCm7:ValidationCm7Service,private sanitizer: DomSanitizer,
    private dataTransmission:DataTransmissionService,private chromeBrowser:ChromeBrowserService,
    private explorerBrowser:ExplorerBrowserService,private firefoxBrowser:FirefoxBrowserService) { 
    this.titleImagenes='IMAGENES ESCANEADAS';
    this.circleEscaner=false;
    this.circleSistema=false;
    this.cm7Duplication=[];
    this.idDocR=new Array<string>();
    this.idDocF=new Array<string>();
    this.urlRArray= new Array<Array<SafeUrl>>();
    this.urlFArray= new Array<Array<SafeUrl>>();
    this.alert=false;
    this.enableScanningInitial=true;
    this.conectarEscaner=this.informationMessages.getMessageInformation("SCANNING_BUTTON");
    this.duplicationCm7Message=this.informationMessages.getMessageInformation("DUPLICATION_IMAGE");
    this.setInicialVariables();
  }

  ngOnInit(): void {
    this.ngUnsubscribe = new Subject();
    this.enableButtonReScanning=false;
    this.enableButtonNext=false;  
    this.dataTransmission.accion$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.accion=response;});
    this.dataTransmission.alert$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{
      this.alert=response;
      this.updateButtons();
    });
    this.dataTransmission.images$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{
      this.imagenes=response;
      this.updateButtons();
    });
    this.dataTransmission.labelSystem$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.etiquetaSistema=response;});
    this.dataTransmission.labelScanner$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.etiquetaEscaner=response;});
    this.dataTransmission.serialScanner$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.serialEscaner=response);
    this.dataTransmission.connectingSystem$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.connectingScannerAndScanningForFireFoxAndChrome(response));
    this.dataTransmission.circleSystem$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.circleSistema=response);
    this.dataTransmission.circleScanner$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.circleEscaner=response);
    this.dataTransmission.displayResultInException$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.updateButtonInExceptionInExplorer(response));
    this.dataTransmission.informationImages$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.getDuplicationCm7(response));
    this.dataTransmission.warningMessage$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>this.warningMessage(response));
    this.dataTransmission.errorCode$.pipe(takeUntil(this.ngUnsubscribe)).subscribe(response=>{this.errorCode=response;});
    this.dataTransmission.setConnectingSystem$(this.informationMessages.getMessageInformation(this.getButtonNameChrome()));
    this.dataTransmission.setNameBrowser$(this.nameBrowser);
  }
  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
  private setInicialVariables(){
    this.dataTransmission.setReScanningOrNextOptions$(false);
    this.dataTransmission.setNextOption$(false);
    this.dataTransmission.setReScanningOption$(false);
    this.dataTransmission.setLabelSystem$(this.informationMessages.getMessageInformation("DISCONNECTED_SYSTEM"));
    this.dataTransmission.setLabelScanner$(this.informationMessages.getMessageInformation("DISCONNECTED_SCANNER"));
    this.dataTransmission.setAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
    this.dataTransmission.setSerialScanner$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
    this.dataTransmission.setCircleScanner$(false);
    this.dataTransmission.setCircleScanner$(false);
    this.dataTransmission.setImages$(false);
    this.dataTransmission.setInformationImages$(this.informationImages);
  }
 
  connectSystemClientServer(){
    this.enableScanningInitial=false;
    this.enableButtonNext=false;
    if(this.nameBrowser==this.BROWSER_EXPLORER){
      this.dataTransmission.setInitScanner$(true);
    }else if (this.nameBrowser==this.BROWSER_FIREFOX){
      this.resetVariablesImages();
      this.firefoxBrowser.connectSystemClientServer(this.conectarSistema);
    }else{
      this.chromeBrowser.connectSystemClientServer(this.conectarSistema);
    }
  }
  
  private connectingScannerAndScanningForFireFoxAndChrome(response){
    this.conectarSistema=response
    if(this.conectarSistema==this.informationMessages.getMessageInformation("SHUT_DOWN_SYSTEM_BUTTON")) {
      this.dataTransmission.setScanningAction$(true);
    }
  }
  private resetVariablesImages(){
    this.idDocR=new Array<string>();
    this.idDocF=new Array<string>();
    this.urlRArray= new Array<Array<SafeUrl>>();
    this.urlFArray= new Array<Array<SafeUrl>>();
  }
  deleteAllImages(){
    this.dataTransmission.setInformationImages$(new Array<any>());
    this.accion=this.informationMessages.getMessageInformation("EMPTY_EXCEPTION");
    this.successMessage(this.informationMessages.getMessageInformation("messageSuccessDeleteAllImages"));
  }

  getColorForDuplicationCm7(dr1){
    this.validationCm7.getCm7DuplicationArray(this.cm7Duplication);
    return this.validationCm7.getColorForDuplicationCm7(dr1);
  }
  getFlagForDuplicationCm7(dr1){
    this.validationCm7.getCm7DuplicationArray(this.cm7Duplication);
    if(this.nameBrowser==this.BROWSER_EXPLORER){
      this.validationCm7.getFlagForDuplicationCm7Explorer(dr1);
    }
    return this.validationCm7.getFlagForDuplicationCm7Chrome(dr1);
  }

  onClickBack(){
    if(this.reScanningAndNext || (this.alert && this.displayResultInException)){
      this.resetOptionScanning();
      //this.dataTransmission.setDisplayResultInException$(false);
      this.dataTransmission.setResetVariables$(true);
      this.updateTotalPayChecks();
      this.setButtonsStatus();
      this.connectSystemClientServer();
    }
  }

  onClickNext(){
    const mappedTicket = this.mapCheckCapturedFromScanner();
    if(mappedTicket && mappedTicket.length>0 && !this.reScanningOption){
      this.enableScanningInitial=true;
      this.setButtonsStatus();
      this.resetOptionScanning();
    }else if(this.getConditionReScanningAndNextOption(mappedTicket)){
      this.enableScanningInitial=true;
      this.setButtonsStatus();
      this.resetOptionScanning();
    }else if(this.getConditionReScanningOption(mappedTicket) || (mappedTicket==null && this.alert)){
      this.resetOptionScanning();
      this.setButtonsStatus();
      this.dataTransmission.setResetVariables$(true);
      this.connectSystemClientServer();
    }
  }
  private updateTotalPayChecks(){
    let payChecksForBatch=null;
    this.dataTransmission.totalPayChecks$.subscribe(response=>{this.totalPayChecks=response;});
    this.dataTransmission.payChecksForBatch$.subscribe(response=>{payChecksForBatch=response;});
    if(this.getConditionToUpdateTotalPayChecks(this.totalPayChecks,payChecksForBatch)){
        this.dataTransmission.setTotalPayChecks$(this.totalPayChecks-payChecksForBatch);
    }
  }
  private getConditionToUpdateTotalPayChecks(totalPayChecks,payChecksForBatch){
    return totalPayChecks!=null && payChecksForBatch!=null && totalPayChecks>0 && (totalPayChecks-payChecksForBatch)>=0;
  }

  private getConditionReScanningAndNextOption(mappedTicket){
    this.dataTransmission.totalPayChecks$.subscribe(response=>{this.totalPayChecks=response;});
    return (mappedTicket && mappedTicket.length==0 && this.reScanningAndNext) || this.getConditionReScanningWithAlert();
  }
  private getConditionReScanningWithAlert(){
  return this.alert && this.totalPayChecks>0 && this.errorCode && !this.errorConnection.includes(this.errorCode);
  }
  private getConditionReScanningOption(mappedTicket){
    return this.reScanningOption || (mappedTicket && mappedTicket.length==0);
  }
  private mapCheckCapturedFromScanner(){
    let mappedTicket=null;
    this.dataTransmission.imagesBatchScanning$.subscribe(response => {
      mappedTicket= response;
    });
    return mappedTicket;
  }

  getImageF(imageBase64,idDoc,index){
    if(!this.idDocF.includes(idDoc)){
      this.idDocF.push(idDoc);
      this.urlF=this.sanitizer.bypassSecurityTrustResourceUrl('data:image/png;base64,'+imageBase64);
      let row= new Array<SafeUrl>();
      row.push(this.urlF);
      this.urlFArray.push(row);
      return this.urlF;
    }
    return this.urlFArray[index][0];
  }
  getImageR(imageBase64,idDoc,index){
    if(!this.idDocR.includes(idDoc)){
      this.idDocR.push(idDoc);
      this.urlR=this.sanitizer.bypassSecurityTrustResourceUrl('data:image/png;base64,'+imageBase64);
      let row= new Array<SafeUrl>();
      row.push(this.urlR);
      this.urlRArray.push(row);
      return this.urlR;
    }
    return this.urlRArray[index][0];
  }
  deleteImageSelected(idDoc){
    this.informationImages=this.informationImages.filter(image=>image.idDoc!=idDoc);
    this.dataTransmission.setInformationImages$(this.informationImages);
    this.successMessage(this.informationMessages.getMessageInformation("messageSuccessDeleteImage"));
  }

  private getDuplicationCm7(informationImages){
    this.cm7Duplication=[];
    if(informationImages!=null &&  informationImages.length>0){
      this.cm7Duplication=this.validationCm7.findDuplicateCm7(informationImages);
    }
    this.informationImages=informationImages;
  }
  
  private warningMessage(message){
      if(message!=null && message!=this.EMPTY_EXCEPTION){
        this.toastr.warning(message,"Precaucion",{timeOut:2000,});
      }
  }
  private successMessage(message){
    this.toastr.success(message,"Operación exitosa",{timeOut:2000,});
  }
  
  private informationMessage(message){
    this.toastr.info(message,"Mensaje de información",{timeOut:2000,});
  }
  private getButtonNameChrome(){
    return this.nameBrowser!=this.BROWSER_EXPLORER?"CONNECT_SYSTEM_BUTTON":"SHUT_DOWN_SCANNER_BUTTON";
  }
  conditionAnimationForChromeOrFireFox(){
    return this.nameBrowser!=null && this.typeBrowser!=null;
  }
  conditionAnimationForExplorer(){
    return this.nameBrowser==this.BROWSER_EXPLORER && this.typeBrowser==null;
  }
  conditionLabelConnectingSystem(){
    return this.typeBrowser!=null;
  }
  private updateButtons(): void {
    this.enableButtonNext=this.enableNextButton();
    this.enableButtonReScanning=this.enableBackButton();
    this.nameButtonNext=this.getNameOfNextButton();
  }
  private setButtonsStatus(){
    this.enableButtonNext=false;
    this.enableButtonReScanning=false;
  }
  private enableNextButton(): boolean {
    this.getOptionScanning();
    if(this.alert && !this.nextOption && this.nameBrowser==this.BROWSER_EXPLORER){
      return false;
    }
    return (this.reScanning || this.nextOption || this.reScanningAndNext) || this.alert;
  }
  private enableBackButton(): boolean {
      this.getOptionScanning();
      this.dataTransmission.totalPayChecks$.subscribe(response=>this.totalPayChecks=response);
      return (this.reScanningAndNext || (this.alert && this.displayResultInException && this.totalPayChecks>0 && this.nameBrowser!=this.BROWSER_EXPLORER));
  }

  private getOptionScanning(){
    this.dataTransmission.reScanningOption$.subscribe(response=>{this.reScanning=response;});
    this.dataTransmission.nextOption$.subscribe(response=>{this.nextOption=response;});
    this.dataTransmission.reScanningOrNextOptions$.subscribe(response=>{this.reScanningAndNext=response;});
  }
  private resetOptionScanning(){
    this.dataTransmission.setReScanningOption$(false);
    this.dataTransmission.setNextOption$(false);
    this.dataTransmission.setReScanningOrNextOptions$(false);
  }
  private getNameOfNextButton():string{
    this.getOptionScanning();
     if(this.reScanning || (this.alert && this.displayResultInException!=null && !this.displayResultInException)){
        return 'Reescanear';
    }
    if(this.nextOption || this.reScanningAndNext || (this.alert && this.displayResultInException)){
        return 'Siguiente';
    }
  }
  private updateButtonInExceptionInExplorer(reponse){
    this.displayResultInException=reponse;
    if(this.displayResultInException && this.nameBrowser==this.BROWSER_EXPLORER){
      this.updateButtons();
    }
  }
}
