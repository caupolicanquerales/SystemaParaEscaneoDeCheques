import { Component, Input, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { DataTransmissionService } from '../service/data-transmission.service';
import { InformationMessagesService } from '../service/information-messages.service';
import { ValidationCm7Service } from '../service/validation-cm7.service';
import { ChromeBrowserService } from 'src/app/chrome-service/chrome-browser.service';
import { ListErrorScannerService } from '../service/list-error-scanner.service';

@Component({
  selector: 'app-main-front-prototype',
  templateUrl: './main-front-prototype.component.html',
  styleUrls: ['./main-front-prototype.component.css']
})
export class MainFrontPrototypeComponent implements OnInit {

  @Input() typeBrowser:boolean;
  @Input() nameBrowser:string;

  title = 'Ambiente para escaneo';
  etiquetaSistema:string;
  circleSistema:boolean;
  etiquetaEscaner:string;
  circleEscaner:boolean;
  alerta:boolean;
  accion:string;
  error:string;
  errorCode:string;
  serialEscaner:string;
  conectarSistema:string;
  conectarEscaner:string;
  titleImagenes:string;
  imagenes:boolean;
  informationImages:Array<any>=[];
  duplicationCm7Message:string;
  cm7Duplication:Array<any>;
  private EMPTY_EXCEPTION="";
  private BROWSER_EXPLORER="Explorer";
  
  constructor(private toastr: ToastrService,private informationMessages:InformationMessagesService,
    private validationCm7:ValidationCm7Service,private sanitizer: DomSanitizer,private dataTransmission:DataTransmissionService,
    private chromeBrowser:ChromeBrowserService,private errors:ListErrorScannerService) { 
    this.titleImagenes='IMAGENES ESCANEADAS';
    this.circleEscaner=false;
    this.circleSistema=false;
    this.alerta=false;
    this.imagenes=false;
    this.cm7Duplication=[];
    this.conectarEscaner=this.informationMessages.getMessageInformation("SCANNING_BUTTON");
    this.duplicationCm7Message=this.informationMessages.getMessageInformation("DUPLICATION_IMAGE");
    this.setInicialVariables();
  }

  ngOnInit(): void {
    this.dataTransmission.accion$.subscribe(response=>{this.accion=response;});
    this.dataTransmission.alert$.subscribe(response=>{this.alerta=response;});
    this.dataTransmission.images$.subscribe(response=>{this.imagenes=response;});
    this.dataTransmission.labelSystem$.subscribe(response=>{this.etiquetaSistema=response;});
    this.dataTransmission.labelScanner$.subscribe(response=>{this.etiquetaEscaner=response;});
    this.dataTransmission.serialScanner$.subscribe(response=>this.serialEscaner=response);
    this.dataTransmission.connectingSystem$.subscribe(response=>this.conectarSistema=response);
    this.dataTransmission.errorCode$.subscribe(response=>this.setErrorMessage(response));
    this.dataTransmission.circleSystem$.subscribe(response=>this.circleSistema=response);
    this.dataTransmission.circleScanner$.subscribe(response=>this.circleEscaner=response);
    this.dataTransmission.informationImages$.subscribe(response=>this.getDuplicationCm7(response));
    this.getIdExtension();
  }

  private setInicialVariables(){
    this.dataTransmission.setLabelSystem$(this.informationMessages.getMessageInformation("DISCONNECTED_SYSTEM"));
    this.dataTransmission.setLabelScanner$(this.informationMessages.getMessageInformation("DISCONNECTED_SCANNER"));
    this.dataTransmission.setAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
    this.dataTransmission.setSerialScanner$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
    this.dataTransmission.setConnectingSystem$(this.informationMessages.getMessageInformation("CONNECT_SYSTEM_BUTTON"));
    this.dataTransmission.setCircleScanner$(false);
    this.dataTransmission.setCircleScanner$(false);
    this.dataTransmission.setInformationImages$(this.informationImages);
  }
  private getIdExtension(){
    if(this.nameBrowser!=this.BROWSER_EXPLORER){
      this.chromeBrowser.getIdExtensionForBrowser(this.nameBrowser);
    }
  }
  connectSystemClientServer(){
    if(this.nameBrowser==this.BROWSER_EXPLORER){

    }else{
      this.chromeBrowser.connectSystemClientServer(this.conectarSistema);
    }
  }
  connectingScannerAndScanningProcess(){
    if(this.nameBrowser==this.BROWSER_EXPLORER){

    }else{
      this.chromeBrowser.connectingScannerAndScanningProcess(this.conectarEscaner);
    }
  }

  getImage(imageBase64){
    return this.sanitizer.bypassSecurityTrustResourceUrl('data:image/tiff;base64,'+imageBase64);
  }
  deleteImageSelected(idDoc){
    this.informationImages=this.informationImages.filter(image=>image.idDoc!=idDoc);
    this.dataTransmission.setInformationImages$(this.informationImages);
    this.successMessage(this.informationMessages.getMessageInformation("messageSuccessDeleteImage"));
  }

  deleteAllImages(){
    this.dataTransmission.setInformationImages$(new Array<any>());
    this.accion=this.informationMessages.getMessageInformation("EMPTY_EXCEPTION");
    this.successMessage(this.informationMessages.getMessageInformation("messageSuccessDeleteAllImages"));
  }

  getColorForDuplicationCm7(dr1){
    if(this.cm7Duplication.length>0 && !dr1.includes(this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER"))){
      return this.cm7Duplication.includes(dr1)?'red':'black';
    }
    return 'black';
  }
  getFlagForDuplicationCm7(dr1){
    if(this.getConditionCm7Duplication(dr1)){
      this.duplicationCm7Message=this.informationMessages.getMessageInformation("DUPLICATION_IMAGE");
      return this.cm7Duplication.includes(dr1);
    }else if(this.getConditionCm7DuplicationWithError(dr1)){
      this.duplicationCm7Message=this.informationMessages.getMessageInformation("DUPLICATION_IMAGE_ERROR");
      return this.cm7Duplication.includes(dr1);
    }else if(this.getConditionCm7WithError(dr1)){
      this.duplicationCm7Message=this.informationMessages.getMessageInformation("CM7_ERROR");
      return true;
    }
    return false;
  }
  private getDuplicationCm7(informationImages){
    this.informationImages=informationImages;
    this.cm7Duplication=[];
    if(informationImages!=null &&  informationImages.length>0){
      this.cm7Duplication=this.validationCm7.findDuplicateCm7(informationImages);
    }
  }
  private getConditionCm7Duplication(dr1){
    return this.cm7Duplication.length>0 && !dr1.includes(this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER")) && dr1!=this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER");
  }
  private getConditionCm7DuplicationWithError(dr1){
    return this.cm7Duplication.length>0 && dr1.includes(this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER")) && !this.getCountingErrorCharacters(dr1);
  }
  private getConditionCm7WithError(dr1){
    return this.cm7Duplication.length>=0 && this.getCountingErrorCharacters(dr1);
  }
  private getCountingErrorCharacters(dr1){
    let splitDr1=dr1.split(this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER"));
    if(splitDr1){
      splitDr1.filter(item=>item==this.EMPTY_EXCEPTION);
      return splitDr1.length>=(dr1.length/2);
    }
    return false;
  }
  private warningMessage(message){
      this.toastr.warning(message,"Precaucion",{timeOut:2000,});
  }
  
  private successMessage(message){
    this.toastr.success(message,"Operación exitosa",{timeOut:2000,});
  }
  
  private informationMessage(message){
    this.toastr.info(message,"Mensaje de información",{timeOut:2000,});
  }
  private setErrorMessage(errorCode){
    this.errorCode=errorCode;
    this.error=this.errors.getErrorMessage(errorCode);
  }
}
