import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MainFrontPrototypeComponent } from './main-front-prototype.component';

describe('MainFrontPrototypeComponent', () => {
  let component: MainFrontPrototypeComponent;
  let fixture: ComponentFixture<MainFrontPrototypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MainFrontPrototypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MainFrontPrototypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
