import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeHtml} from '@angular/platform-browser'
import * as detectingBrowser from 'src/app/jsfiles/DetectingBrowser.js';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  typeBrowser:boolean;
  nameBrowser:string;
  brandBrowser:boolean;
  private EXPLORER_BROWSER="Explorer";
  private FIREFOX_BROWSER="Firefox";
  private CHROME_BROWSER="Chrome";
  private EDGE_BROWSER="Edge";

  constructor(){
    this.typeBrowser=null; 
    this.nameBrowser='';     
  }
  ngOnInit(){
    this.getTypeOfBrowser();
  }
  getTypeOfBrowser(){
    this.nameBrowser=detectingBrowser.detectingTypeOfBrowser();
    if(this.nameBrowser==this.EXPLORER_BROWSER){
      this.typeBrowser=null;
    }
    if(this.nameBrowser==this.FIREFOX_BROWSER){
      this.typeBrowser=false;
    }
    if(this.nameBrowser==this.CHROME_BROWSER
      || this.nameBrowser==this.EDGE_BROWSER){
      this.typeBrowser=true;
    }
  }


}
