import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ListExtensionIdsService {

  idExtension={
    Chrome:"lkmhhpnhpbokjiglplbfidgjijlfgbpi",
    Edge:"flmaeakblaohpdfhbbomoanppgbmoked",
    Firefox:"",
    Opera:"",
    Safari:""
  }
  constructor() { }
  
  getIdExtensionForBrowser(nameBrowser:string){
    return this.idExtension[nameBrowser];
  }
}
