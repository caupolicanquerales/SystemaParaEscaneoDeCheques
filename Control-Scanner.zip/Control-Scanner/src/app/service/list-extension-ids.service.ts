import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ListExtensionIdsService {

  idExtension={
    Chrome:["flmaeakblaohpdfhbbomoanppgbmoked","lkmhhpnhpbokjiglplbfidgjijlfgbpi"],
    Edge:["flmaeakblaohpdfhbbomoanppgbmoked"],
    Firefox:"icbc@example.org",
    Opera:"",
    Safari:""
  }
  constructor() { }
  
  getIdExtensionForBrowser(nameBrowser:string){
    return this.idExtension[nameBrowser];
  }
}
