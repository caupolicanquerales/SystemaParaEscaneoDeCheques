import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ListExtensionIdsService {

  idExtension={
    Chrome:"lkmhhpnhpbokjiglplbfidgjijlfgbpi",
    Edge:"flmaeakblaohpdfhbbomoanppgbmoked",
    Firefox:"icbs@example.org",
    Opera:"",
    Safari:""
  }
  constructor() { }
  
  getIdExtensionForBrowser(nameBrowser:string){
    return this.idExtension[nameBrowser];
  }
}
