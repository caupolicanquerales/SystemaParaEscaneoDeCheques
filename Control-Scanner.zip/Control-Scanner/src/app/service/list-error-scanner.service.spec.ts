import { TestBed } from '@angular/core/testing';

import { ListErrorScannerService } from './list-error-scanner.service';

describe('ListErrorScannerService', () => {
  let service: ListErrorScannerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ListErrorScannerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
