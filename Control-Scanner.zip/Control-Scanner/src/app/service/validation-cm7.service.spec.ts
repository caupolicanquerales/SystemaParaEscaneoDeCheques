import { TestBed } from '@angular/core/testing';

import { ValidationCm7Service } from './validation-cm7.service';

describe('ValidationCm7Service', () => {
  let service: ValidationCm7Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ValidationCm7Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
