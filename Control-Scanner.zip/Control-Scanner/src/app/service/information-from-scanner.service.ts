import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InformationFromScannerService {

  private variablesScannerResponse:Array<string>=["state","serial","exep"];
  private resultConnectingScanner={};
  
  constructor() { }

  getConnectingResult(){
    return this.resultConnectingScanner[this.variablesScannerResponse[0]];
  }
  getSerial(){
    return this.resultConnectingScanner[this.variablesScannerResponse[1]];
  }
  getException(){
    return this.resultConnectingScanner[this.variablesScannerResponse[2]];
  }
  getInformationFromConnectingScanner(message){
    this.resultConnectingScanner={};
    let object= message.split(",");
    object.forEach(item=>{
      let change=item.replace("{","");
      change=change.replace("}","");
      let array=change.split(":");
      this.resultConnectingScanner[array[0]]=array[1];
    });
  }
  getInformationFromScanning(message){
    let object= message.split("*sc*");
    object.forEach(item=>{
      let change=item.replace("{","");
      change=change.replace("}","");
      let array=change.split(":");
      this.resultConnectingScanner[array[0]]=array[1];
    });
    return this.resultConnectingScanner;
  }

  getObjectOfInformation(information){
    let object= information.split("*sc*");
    let objectInformation={};
    object.forEach(item=>{
      let change=item.replace("{","");
      change=change.slice(0, -1);
      let array=change.split(":");
      objectInformation[array[0]]=array[1];
    });
    return objectInformation;
  }

  getDocumentInformation(document){
    document=document.replace("[","");
    document=document.slice(0, -1);
    let documents= document.split(";");
    return this.getArrayOfObjectInformation(documents);
  }
  private getArrayOfObjectInformation(documents){
    let arrayOfObject=[];
    documents.filter(doc=>doc!="").forEach(doc => {
      let change=doc.replace("{","");
      change=change.slice(0, -1);
      let array=change.split(",");
      arrayOfObject.push(this.getObjectInformation(array));
    });
    return arrayOfObject;
  }
  private getObjectInformation(array){
    let docObject={};
    array.forEach(item => {
      let change=item.split(">");
      docObject[change[0]]=change[1];
    });
    return docObject;
  }
  removeFirstAndLastCharOfcmc7(resultConnectingScanner){
    resultConnectingScanner["docRead"].forEach(item => {
      item.dr1=item.dr1.substring(1);
      item.dr1=item.dr1.slice(0, -1);
    });
    return resultConnectingScanner;
  }
  integrateAllInformationInArray(resultConnectingScanner){
    let index=0;
    let array=[];
    resultConnectingScanner["docRead"].forEach(docItem => {
      let newObject={...docItem,...resultConnectingScanner["docImage"][index]};
      array.push(newObject);
      index++;
    });
    return array;
  }
}
