import { TestBed } from '@angular/core/testing';

import { ListExtensionIdsService } from './list-extension-ids.service';

describe('ListExtensionIdsService', () => {
  let service: ListExtensionIdsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ListExtensionIdsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
