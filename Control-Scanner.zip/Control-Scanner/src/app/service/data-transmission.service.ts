import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataTransmissionService {

  private accionSource= new BehaviorSubject<string>(null);
  accion$= this.accionSource.asObservable();

  private alertSource= new BehaviorSubject<boolean>(null);
  alert$= this.alertSource.asObservable();

  private imagesSource= new BehaviorSubject<boolean>(null);
  images$= this.imagesSource.asObservable();

  private labelSystemSource= new BehaviorSubject<string>(null);
  labelSystem$= this.labelSystemSource.asObservable();

  private labelScannerSource= new BehaviorSubject<string>(null);
  labelScanner$= this.labelScannerSource.asObservable();

  private circleScannerSource= new BehaviorSubject<boolean>(null);
  circleScanner$= this.circleScannerSource.asObservable();

  private circleSystemSource= new BehaviorSubject<boolean>(null);
  circleSystem$= this.circleSystemSource.asObservable();

  private serialScannerSource= new BehaviorSubject<string>(null);
  serialScanner$= this.serialScannerSource.asObservable();

  private errorCodeSource= new BehaviorSubject<string>(null);
  errorCode$= this.errorCodeSource.asObservable();

  private warningMessageSource= new BehaviorSubject<string>(null);
  warningMessage$= this.warningMessageSource.asObservable();

  private successMessageSource= new BehaviorSubject<string>(null);
  successMessage$= this.successMessageSource.asObservable();
  
  private connectingSystemButton= new BehaviorSubject<string>(null);
  connectingSystem$= this.connectingSystemButton.asObservable();

  private informationImagesSource= new BehaviorSubject<any>(null);
  informationImages$= this.informationImagesSource.asObservable();

  constructor() { }

  setAccion$(message:string){
    this.accionSource.next(message);
  }
  setAlert$(alert:boolean){
    this.alertSource.next(alert);
  }
  setImages$(images:boolean){
    this.imagesSource.next(images);
  }
  setLabelSystem$(labelSystem:string){
    this.labelSystemSource.next(labelSystem);
  }
  setLabelScanner$(labelScanner:string){
    this.labelScannerSource.next(labelScanner);
  }
  setCircleScanner$(circleScanner:boolean){
    this.circleScannerSource.next(circleScanner);
  }
  setCircleSystem$(circleSystem:boolean){
    this.circleSystemSource.next(circleSystem);
  }
  setSerialScanner$(serialScanner:string){
    this.serialScannerSource.next(serialScanner);
  }
  setErrorCode$(errorCode:string){
    this.errorCodeSource.next(errorCode);
  }
  setWarningMessage$(warningMessage:string){
    this.warningMessageSource.next(warningMessage);
  }
  setSuccessMessage$(successMessage:string){
    this.successMessageSource.next(successMessage);
  }
  setConnectingSystem$(connectingSystem:string){
    this.connectingSystemButton.next(connectingSystem);
  }
  setInformationImages$(informationImages:Array<any>){
    this.informationImagesSource.next(informationImages);
  }
}
