import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataTransmissionService {

  private accionSource= new BehaviorSubject<string>(null);
  accion$= this.accionSource.asObservable();

  private alertSource= new BehaviorSubject<boolean>(null);
  alert$= this.alertSource.asObservable();

  private imagesSource= new BehaviorSubject<boolean>(null);
  images$= this.imagesSource.asObservable();

  private labelSystemSource= new BehaviorSubject<string>(null);
  labelSystem$= this.labelSystemSource.asObservable();

  private labelScannerSource= new BehaviorSubject<string>(null);
  labelScanner$= this.labelScannerSource.asObservable();

  private circleScannerSource= new BehaviorSubject<boolean>(null);
  circleScanner$= this.circleScannerSource.asObservable();

  private circleSystemSource= new BehaviorSubject<boolean>(null);
  circleSystem$= this.circleSystemSource.asObservable();

  private serialScannerSource= new BehaviorSubject<string>(null);
  serialScanner$= this.serialScannerSource.asObservable();

  private errorCodeSource= new BehaviorSubject<string>(null);
  errorCode$= this.errorCodeSource.asObservable();

  private warningMessageSource= new BehaviorSubject<string>(null);
  warningMessage$= this.warningMessageSource.asObservable();

  private successMessageSource= new BehaviorSubject<string>(null);
  successMessage$= this.successMessageSource.asObservable();
  
  private connectingSystemButton= new BehaviorSubject<string>(null);
  connectingSystem$= this.connectingSystemButton.asObservable();

  private informationImagesSource= new BehaviorSubject<any>(null);
  informationImages$= this.informationImagesSource.asObservable();

  private imagesBatchScanningSource= new BehaviorSubject<any>(null);
  imagesBatchScanning$= this.imagesBatchScanningSource.asObservable();

  private duplicationCm7MessageSource= new BehaviorSubject<string>(null);
  duplicationCm7Message$= this.duplicationCm7MessageSource.asObservable();

  private progressSpinnerSource= new BehaviorSubject<boolean>(null);
  progressSpinner$= this.progressSpinnerSource.asObservable();

  private scanningActionSource= new BehaviorSubject<boolean>(null);
  scanningAction$= this.scanningActionSource.asObservable();

  private nameBrowserSource= new BehaviorSubject<string>(null);
  nameBrowser$= this.nameBrowserSource.asObservable();

  private initScannerSource= new BehaviorSubject<boolean>(null);
  initScanner$= this.initScannerSource.asObservable();

  private totalPayChecksSource= new BehaviorSubject<number>(null);
  totalPayChecks$= this.totalPayChecksSource.asObservable();

  private payChecksForBatchSource= new BehaviorSubject<number>(null);
  payChecksForBatch$= this.payChecksForBatchSource.asObservable();

  private displayResultInExceptionSource= new BehaviorSubject<boolean>(null);
  displayResultInException$= this.displayResultInExceptionSource.asObservable();

  private reScanningOptionSource= new BehaviorSubject<boolean>(null);
  reScanningOption$= this.reScanningOptionSource.asObservable();

  private reScanningOrNextOptionSource= new BehaviorSubject<boolean>(null);
  reScanningOrNextOptions$= this.reScanningOrNextOptionSource.asObservable();

  private nextOptionSource= new BehaviorSubject<boolean>(null);
  nextOption$= this.nextOptionSource.asObservable();

  private resetVariablesSource= new BehaviorSubject<boolean>(null);
  resetVariables$= this.resetVariablesSource.asObservable();
  
  private spinnerVariableSource= new BehaviorSubject<boolean>(null);
  spinnerVariable$= this.spinnerVariableSource.asObservable();
  

  constructor() { }

  setAccion$(message:string){
    this.accionSource.next(message);
  }
  setAlert$(alert:boolean){
    this.alertSource.next(alert);
  }
  setImages$(images:boolean){
    this.imagesSource.next(images);
  }
  setLabelSystem$(labelSystem:string){
    this.labelSystemSource.next(labelSystem);
  }
  setLabelScanner$(labelScanner:string){
    this.labelScannerSource.next(labelScanner);
  }
  setCircleScanner$(circleScanner:boolean){
    this.circleScannerSource.next(circleScanner);
  }
  setCircleSystem$(circleSystem:boolean){
    this.circleSystemSource.next(circleSystem);
  }
  setSerialScanner$(serialScanner:string){
    this.serialScannerSource.next(serialScanner);
  }
  setErrorCode$(errorCode:string){
    this.errorCodeSource.next(errorCode);
  }
  setWarningMessage$(warningMessage:string){
    this.warningMessageSource.next(warningMessage);
  }
  setSuccessMessage$(successMessage:string){
    this.successMessageSource.next(successMessage);
  }
  setConnectingSystem$(connectingSystem:string){
    this.connectingSystemButton.next(connectingSystem);
  }
  setInformationImages$(informationImages:Array<any>){
    this.informationImagesSource.next(informationImages);
  }
  setImagesBatchScanning$(imagesBatchScanning:Array<any>){
    this.imagesBatchScanningSource.next(imagesBatchScanning);
  }
  setDuplicationCm7Message$(duplicationCm7Message:string){
    this.duplicationCm7MessageSource.next(duplicationCm7Message);
  }
  setProgressSpinner$(progressSpinner:boolean){
    this.progressSpinnerSource.next(progressSpinner);
  }
  setScanningAction$(scanningAction:boolean){
    this.scanningActionSource.next(scanningAction);
  }
  setNameBrowser$(nameBrowser:string){
    this.nameBrowserSource.next(nameBrowser);
  }
  setInitScanner$(initScanner:boolean){
    this.initScannerSource.next(initScanner);
  }
  setTotalPayChecks$(totalPayChecks:number){
    this.totalPayChecksSource.next(totalPayChecks);
  }
  setPayChecksForBatch$(payChecksForBatch:number){
    this.payChecksForBatchSource.next(payChecksForBatch);
  }
  setDisplayResultInException$(displayResultInException:boolean){
    this.displayResultInExceptionSource.next(displayResultInException);
  }
  setReScanningOption$(reScanningOption:boolean){
    this.reScanningOptionSource.next(reScanningOption);
  }
  setReScanningOrNextOptions$(reScanningOrNextOption:boolean){
    this.reScanningOrNextOptionSource.next(reScanningOrNextOption);
  }
  setNextOption$(nextOption:boolean){
    this.nextOptionSource.next(nextOption);
  }
  setResetVariables$(resetVariables:boolean){
    this.resetVariablesSource.next(resetVariables);
  }
  setSpinnerVariable$(spinnerVariable:boolean){
    this.spinnerVariableSource.next(spinnerVariable);
  }
}
