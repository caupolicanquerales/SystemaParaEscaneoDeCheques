import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InformationMessagesService {

  messages:any={
    "CONNECTED_SYSTEM":"SISTEMA CONECTADO",
    "DISCONNECTED_SYSTEM":"SISTEMA DESCONECTADO",
    "CONNECTED_SCANNER":"ESCANER CONECTADO",
    "DISCONNECTED_SCANNER":"ESCANER DESCONECTADO",
    "CONNECTING_SYSTEM":"CONECTANDO SISTEMA",
    "ERROR_OF_CONNECTION":"ERROR DE CONEXION",
    "CONNECTING_SCANNER":"CONECTANDO ESCANER",
    "SHUTTING_DOWN_SCANNER":"CERRANDO ESCANER",
    "SCANNING":"ESCANEANDO",
    "LOADING_INFORMATION":"CARGANDO INFORMACION",
    "LOADED_IMAGES":"IMAGENES CARGADAS",
    "NO_IMAGES":"NO HAY IMAGENES",
    "CONNECT_SYSTEM_BUTTON":"Conectar Sistema",
    "SHUT_DOWN_SYSTEM_BUTTON":"Cerrar Sistema",
    "CONNECT_SCANNER_BUTTON":"Iniciar Escaner",
    "SCANNING_BUTTON":"Escanear",
    "SHUT_DOWN_SCANNER_BUTTON":"Cerrar Escaner",
    "CHECKING_CONNECTION_SCANNER":"Chequear conexión de escaner o reiniciar sistema",
    "FORCE_SHUT_DOWN_SCANNER":"Escaner forzado a cerrar",
    "CONNECTED":'conectado',
    "DUPLICATION_IMAGE":"CM7 DUPLICADO",
    "DUPLICATION_IMAGE_ERROR":"CM7 DUPLICADO CON ERROR",
    "CM7_ERROR":"CM7 ILEGIBLE",
    "CONTAIN_ERROR_CHARACTER":"+",
    "EMPTY_EXCEPTION":"",
    "messageWarnigConnectionScanner":"Iniciar sistema",
    "messageWarnigScanning":"Comprobar conexion con el sistema o escaner",
    "messageSuccessDeleteImage":"Imagen eliminada",
    "messageSuccessDeleteAllImages":"Imagenes eliminadas",
    "messageInfoToCloseScanner":"Cerrar escaner"
  }

  constructor() { }
  
  getMessageInformation(message){
    return this.messages[message]; 
  }
}
