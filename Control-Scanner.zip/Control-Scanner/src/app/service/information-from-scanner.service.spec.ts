import { TestBed } from '@angular/core/testing';

import { InformationFromScannerService } from './information-from-scanner.service';

describe('InformationFromScannerService', () => {
  let service: InformationFromScannerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InformationFromScannerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
