import { Injectable } from '@angular/core';
import { DataTransmissionService } from './data-transmission.service';
import { InformationMessagesService } from './information-messages.service';

@Injectable({
  providedIn: 'root'
})
export class ValidationCm7Service {

  private cm7Duplication:Array<any>;
  private EMPTY_EXCEPTION="";

  constructor(private informationMessages:InformationMessagesService,private dataTransmission:DataTransmissionService) { }

  getCm7DuplicationArray(cm7Duplication){
    this.cm7Duplication=cm7Duplication;
  }

  findDuplicateCm7(informationImages:Array<any>){
    let object={};
    let result=[];
    informationImages.forEach(infoImage=>{
      if(object[infoImage.dr1]!=null){
        object[infoImage.dr1]+=1;
        return 
      }
      object[infoImage.dr1]=1;
    });
    for(var cm7 in object){
      if(object[cm7]>=2){
        result.push(cm7);
      }
    }
    return result;
  }
  getColorForDuplicationCm7(dr1){
    if(this.cm7Duplication.length>0 && !dr1.includes(this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER"))){
      return this.cm7Duplication.includes(dr1)?'red':'black';
    }
    return 'black';
  }

  getFlagForDuplicationCm7Chrome(dr1){
    if(this.getConditionCm7DuplicationChrome(dr1)){
      this.dataTransmission.setDuplicationCm7Message$(this.informationMessages.getMessageInformation("DUPLICATION_IMAGE"));
      return this.cm7Duplication.includes(dr1);
    }else if(this.getConditionCm7DuplicationWithErrorChrome(dr1)){
      this.dataTransmission.setDuplicationCm7Message$(this.informationMessages.getMessageInformation("DUPLICATION_IMAGE_ERROR"));
      return this.cm7Duplication.includes(dr1);
    }else if(this.getConditionCm7WithErrorChrome(dr1)){
      this.dataTransmission.setDuplicationCm7Message$(this.informationMessages.getMessageInformation("CM7_ERROR"));
      return true;
    }
    return false;
  }
  private getConditionCm7DuplicationChrome(dr1){
    return this.cm7Duplication.length>0 && !dr1.includes(this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER")) && dr1!=this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER");
  }
  private getConditionCm7DuplicationWithErrorChrome(dr1){
    return this.cm7Duplication.length>0 && dr1.includes(this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER")) && !this.getCountingErrorCharactersChrome(dr1);
  }
  private getConditionCm7WithErrorChrome(dr1){
    return this.cm7Duplication.length>=0 && this.getCountingErrorCharactersChrome(dr1);
  }
  private getCountingErrorCharactersChrome(dr1){
    let splitDr1=dr1.split(this.informationMessages.getMessageInformation("CONTAIN_ERROR_CHARACTER"));
    if(splitDr1){
      splitDr1.filter(item=>item==this.EMPTY_EXCEPTION);
      return splitDr1.length>=(dr1.length/2);
    }
    return false;
  }

  getFlagForDuplicationCm7Explorer(dr1){
    if(this.getConditionCm7DuplicationExplorer(dr1)){
      this.dataTransmission.setDuplicationCm7Message$(this.informationMessages.getMessageInformation("DUPLICATION_IMAGE"));
      return this.cm7Duplication.includes(dr1);
    }else if(this.getConditionCm7DuplicationWithErrorExplorer(dr1)){
      this.dataTransmission.setDuplicationCm7Message$(this.informationMessages.getMessageInformation("DUPLICATION_IMAGE_ERROR"));
      return this.cm7Duplication.includes(dr1);
    }else if(this.getConditionCm7WithErrorExplorer(dr1)){
      this.dataTransmission.setDuplicationCm7Message$(this.informationMessages.getMessageInformation("CM7_ERROR"));
      return true;
    }
    return false;
  }
  private getCountingErrorCharactersExplorer(dr1){
    if(dr1!=null){
      let numbersInCm7=dr1.replace(/\D/g,'');
      return numbersInCm7.length<=(dr1.length/2);
    }
    return false;
  }
  private getCountingCorrectCm7(dr1){
    if(dr1!=null){
      let numbersInCm7=dr1.replace(/\D/g,'');
      return (numbersInCm7.length-dr1.length)==0;
    }
    return false;
  }
  private getConditionCm7DuplicationExplorer(dr1){
    return this.cm7Duplication.length>0 && this.getCountingCorrectCm7(dr1) && dr1!=this.EMPTY_EXCEPTION;
  }
  private getConditionCm7DuplicationWithErrorExplorer(dr1){
    return this.cm7Duplication.length>0  && !this.getCountingErrorCharactersExplorer(dr1);
  }
  private getConditionCm7WithErrorExplorer(dr1){
    return this.cm7Duplication.length>=0 && this.getCountingErrorCharactersExplorer(dr1);
  }
}
