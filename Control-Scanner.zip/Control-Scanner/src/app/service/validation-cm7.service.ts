import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ValidationCm7Service {

  constructor() { }

  findDuplicateCm7(informationImages:Array<any>){
    let object={};
    let result=[];
    informationImages.forEach(infoImage=>{
      if(object[infoImage.dr1]!=null){
        object[infoImage.dr1]+=1;
        return 
      }
      object[infoImage.dr1]=1;
    });
    for(var cm7 in object){
      if(object[cm7]>=2){
        result.push(cm7);
      }
    }
    return result;
  }
}
