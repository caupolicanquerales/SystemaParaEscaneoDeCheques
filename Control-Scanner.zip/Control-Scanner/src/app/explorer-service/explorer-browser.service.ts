import { Injectable } from '@angular/core';
import { interval, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DataTransmissionService } from '../service/data-transmission.service';
import { InformationMessagesService } from 'src/app/service/information-messages.service';

@Injectable({
  providedIn: 'root'
})
export class ExplorerBrowserService {

  connect:any;
  onConnected:string;
  onDisconnected:string;
  hopperEmpty:any;
  flowStopped:any;
  serialEscaner:string;
  exceptionInProgress:string;
  stateTrack:string;
  connecting$: Subject<boolean> = new Subject<boolean>();
  exception$: Subject<boolean> = new Subject<boolean>();
  scanning$: Subject<boolean> = new Subject<boolean>();
  shutdownOrScanningButtonFlag:boolean;
  forceShutDownScanner:boolean;
  connectingScannerFlag:boolean;
  informationImages:Array<any>;
  private IDLE_STATE:string="2";
  private READY_STATE:string="4";
  private POWER_OFF_STATE:string="1";
  private EXCEPTION_STATE:string="6";
  private DISCONNECTED_EXCEPTION="0001600002";
  private scanningFlag:boolean;
  
  constructor(private dataTransmission:DataTransmissionService,private informationMessages:InformationMessagesService) { 
    this.forceShutDownScanner=false;
    this.connectingScannerFlag=false;
    this.shutdownOrScanningButtonFlag=false;
    this.connect=null;
    this.scanningFlag=false;
    this.onConnected="";
  }
  getControlScannerObject(connect){
    this.connect=connect;
  }
  destroyObservables(){
    this.getObservableVariablesTrue();
    this.connecting$.unsubscribe();
    this.exception$.unsubscribe();
    this.scanning$.unsubscribe();
    //connect.resetActiveXObject();
  }
  private getObservableVariablesTrue(){
    this.connecting$.next(true);
    this.exception$.next(true);
    this.scanning$.next(true);
  }
  shutdownScanner(){
    this.shutdownOrScanningButtonFlag=true;
    if(this.connectingScannerFlag==true){
      this.connect.getValueObjectScanner().then(response=>{
        this.getVariablesObjectOfScannerControl(response);
        this.connectingScannerCases();
      });
    }else{
      this.sendWarningMessage$(this.informationMessages.getMessageInformation("messageWarnigShutdownScanner"));
    }
  }

  connectingScannerAndScanningProcess(){
    this.connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.shutdownOrScanningButtonFlag=false;
      if(this.connectingScannerFlag==false){
        this.connectingScannerCases();
      }else if(this.connectingScannerFlag==true && !this.conditionExceptionInProgress()){
        this.scanning();    
      }else if(this.connectingScannerFlag==true && this.conditionExceptionInProgress()){
        this.getObservableVariablesTrue();
        this.sendWarningMessage$(this.informationMessages.getMessageInformation("messageWarnigScanningProcessError"));
      }
    });
  }

  private connectingScannerCases(){
    if(this.conditionConnectingScanner()){
      this.setInitialVariablesForConnectingScanner();
      this.sendInformationImages$(new Array<any>());
      this.setConnectionScanner();
    }else if(this.conditionShutdownScannerFromReadyState()){
      this.setInitialVariablesForConnectingScanner();
      this.shutDownScannerFromReadyState();
    }else if(this.conditionShutdownScannerFromIdleState()){
      this.setInitialVariablesForConnectingScanner();
      this.shutDownScannerFromIdleState();
    }else if(this.conditionDisconnectedScannerWithException()){
      this.setInitialVariablesForConnectingScanner();
      this.sendAccion$(this.informationMessages.getMessageInformation("CHECKING_CONNECTION_SCANNER"));
    }else if(this.conditionConnectedScannerWithException()){
      this.setInitialVariablesForConnectingScanner();
      this.sendAccion$(this.informationMessages.getMessageInformation("CONNECTING_SCANNER"));
      this.forceShutDownScanner=true;
      this.getVariablesInShutdownProcessInException();
    }
  }

  private scanning(){
    let state=this.connect.getStateTrack().toString();
    if(state==this.IDLE_STATE){
      this.executingScanningProcess();
      this.connect.goReadyToProcess();
    }else if(state==this.READY_STATE){
      this.executingScanningProcess();
    }else if(state==this.POWER_OFF_STATE){
      this.sendWarningMessage$(this.informationMessages.getMessageInformation("messageWarnigScanning"));
    }else if(state==this.EXCEPTION_STATE){
      this.sendWarningMessage$(this.informationMessages.getMessageInformation("messageExceptionScanning"));
    }
  }
  private setInitialVariablesForConnectingScanner(){
    this.sendAlert$(false);
    this.sendImages$(false);
    this.forceShutDownScanner=false;
  }
  private executingScanningProcess(){
    this.sendAccion$(this.informationMessages.getMessageInformation("SCANNING"));
    this.connect.resetValueObjectScanner();
    this.getVariablesInScanningProcess();
  }
  private setConnectionScanner(){
    this.sendAccion$(this.informationMessages.getMessageInformation("CONNECTING_SCANNER"));
    const result= this.getIntervalObservableForConnecting();
    this.connect.powerUp();
    result.subscribe(()=>this.connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionShutDownIntervalConnection(response);
    }));
  }
  private getVariablesInScanningProcess(){
    const result= this.getIntervalObservableForScanning();
    result.subscribe(()=>this.connect.getValueObjectScanner().then(response=>{
      this.getVariablesObjectOfScannerControl(response);
      this.conditionStartScanning();
      this.conditionShutDownIntervalScanning(response);
    }));
  }
  private getVariablesInShutdownProcessInException(){
    const result= this.getIntervalObservableForException();
    this.connect.flowStop();
    let flagReadyState=false;
    let flagIdleState=false;
    let flagPowerOffState=false;
    result.subscribe(()=>this.connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.READY_STATE && flagReadyState==false){
        flagReadyState=true;
        this.connect.goIdle();
      }else if(response.toString()==this.IDLE_STATE && flagIdleState==false){
        flagIdleState=true;
        this.connect.powerDown();
      }else if(this.conditionShutdownScannerVariable(response,flagPowerOffState)){
        flagPowerOffState=true;
        this.connectingScannerFlag=false;
        this.connect.resetExceptionVariables();
        this.setShutdownScannerVariables(response);
      }else if(this.conditionShutdownScannerFromExceptionStateAndDisconnectedException(response)){
        this.connect.resetConnectedAndDisconnectedVariables();
        this.connectingScannerFlag=false;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private shutDownScannerFromReadyState(){
    const result= this.getIntervalObservableForException();
    this.connect.goIdle();
    let flagIdleState=false;
    let flagPowerOffState=false;
    result.subscribe(()=>this.connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.IDLE_STATE && flagIdleState==false){
        flagIdleState=true;
        this.connect.powerDown();
      }else if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.sendAlert$(false);
        this.sendAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
        this.connectingScannerFlag=false;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private shutDownScannerFromIdleState(){
    const result= this.getIntervalObservableForException();
    this.connect.powerDown();
    let flagPowerOffState=false;
    result.subscribe(()=>this.connect.getStateTrackScanner().then(response=>{
      if(response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false){
        flagPowerOffState=true;
        this.sendAlert$(false);
        this.sendAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
        this.connectingScannerFlag=false;
        this.setShutdownScannerVariables(response);
      }
    }));
  }
  private setShutdownScannerVariables(response){
    this.exception$.next(true);
    this.sendCircleScanner$(false);
    this.sendLabelScanner$(this.informationMessages.getMessageInformation("DISCONNECTED_SCANNER"));
    this.sendAccion$(this.getMessageAccionWhenShutDownScanner());
    this.getVariablesObjectOfScannerControl(response);
  } 
  private getIntervalObservableForConnecting(){
    this.connecting$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.connecting$));
    return result;
  }
  private getIntervalObservableForException(){
    this.exception$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.exception$));
    return result;
  }
  private getIntervalObservableForScanning(){
    this.scanning$.next(false);
    const inter= interval(300);
    const result= inter.pipe(takeUntil(this.scanning$));
    return result;
  }
  private conditionShutDownIntervalConnection(response){
    if(this.conditionConnected() && this.conditionSerialNumber()){
      this.connecting$.next(true);
      this.sendCircleScanner$(true);
      this.connectingScannerFlag=true;
      this.sendLabelScanner$(this.informationMessages.getMessageInformation("CONNECTED_SCANNER"));
      this.sendAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
      this.getVariablesObjectOfScannerControl(response);
      this.scanning();
    }else if(this.conditionExceptionConnectingScanner()){
      this.connecting$.next(true);
      this.getAlarmActive();
    }
  }
  private conditionShutDownIntervalScanning(response){
    if(this.conditionIntervalScanning() && this.scanningFlag==true){
      this.scanning$.next(true);
      this.arrayImageInformationScanning();
      this.sendImages$(true);
      this.scanningFlag=false;
      this.getVariablesObjectOfScannerControl(response);
      this.getAlarmActive();
    }
  }
  private arrayImageInformationScanning(){
    this.dataTransmission.informationImages$.subscribe(response=>this.informationImages=response);
    let information=[];
    information.push(this.connect.getGeneralResultScanning());
    information=information.filter(value=>Object.keys(value).length!==0);
    if(information[0] && information[0].length>0){
      this.sendAccion$(this.informationMessages.getMessageInformation("LOADED_IMAGES"));
      information[0].forEach(element => {this.informationImages.push(element)});
      this.sendInformationImages$(this.informationImages);
    }else{
      this.sendAccion$(this.informationMessages.getMessageInformation("NO_IMAGES"));
    }
  }
  private getAlarmActive(){
    if(this.conditionExceptionInProgress()){
      this.sendAlert$(true);
      this.sendAccion$(this.informationMessages.getMessageInformation("EMPTY_EXCEPTION"));
      this.sendErrorCode$(this.exceptionInProgress);
      this.getVariablesInShutdownProcessInException();
    }
  }
  private conditionConnectingScanner(){
    return this.conditionToDetermineConnection() && this.conditionConnectingWithoutDisconnectedException();
  }

  //revisar estas dos condiciones 
  private conditionDisconnectedScannerWithException(){
    return this.connectingScannerFlag==false && this.conditionConnectedNullWithDisconnectedException();
  }
  private conditionConnectedScannerWithException(){
    return this.conditionToDetermineConnection() && this.conditionConnectedWithDisconnectedException();
    //return this.connectingScannerFlag==false && this.conditionConnectedWithDisconnectedException();
  }
  /////////////////////////////////////

  private conditionIntervalScanning(){
    return (this.conditionConnected() && this.conditionHopperFlowStopped()) || this.conditionExceptionInProgress();
  }
  private conditionHopperFlowStopped(){
    return (this.hopperEmpty && this.hopperEmpty!="") || (this.flowStopped && this.flowStopped!="")
  }
  private conditionConnected(){
    return this.onConnected && this.onConnected!="";
  }
  private conditionSerialNumber(){
    return this.serialEscaner  && this.serialEscaner!="";
  }
  private conditionExceptionInProgress(){
    return this.exceptionInProgress && this.exceptionInProgress!="";
  }
  private conditionExceptionDisconnected(){
    return this.exceptionInProgress && this.exceptionInProgress==this.DISCONNECTED_EXCEPTION;
  }
  private conditionExceptionConnectingScanner(){
    let state=this.connect.getStateTrack().toString();
    return !this.conditionSerialNumber() && this.conditionExceptionInProgress() && state==this.EXCEPTION_STATE;
  }
  private conditionConnectingWithoutDisconnectedException(){
    return !this.conditionConnected() && !this.conditionExceptionInProgress();
  }
  private conditionConnectedNullWithDisconnectedException(){
    return !this.conditionConnected() && this.conditionExceptionDisconnected();
  }
  private conditionConnectedWithDisconnectedException(){
    return this.conditionConnected() && this.conditionExceptionDisconnected();
  }
  private conditionToDetermineConnection(){
    return this.connectingScannerFlag==false && this.shutdownOrScanningButtonFlag==false;
  }
  private conditionToDetermineShutdown(){
    return this.connectingScannerFlag==true && this.shutdownOrScanningButtonFlag==true;
  }
  private conditionShutdownScannerFromReadyState(){
    let state=this.connect.getStateTrack().toString();
    return this.conditionToDetermineShutdown() && state==this.READY_STATE;
  }
  private conditionShutdownScannerFromIdleState(){
    let state=this.connect.getStateTrack().toString();
    return this.conditionToDetermineShutdown() && state==this.IDLE_STATE;
  }
  private conditionShutdownScannerFromExceptionStateAndDisconnectedException(response){
    return response.toString()==this.EXCEPTION_STATE && this.exceptionInProgress==this.DISCONNECTED_EXCEPTION;
  }
  private conditionShutdownScannerVariable(response,flagPowerOffState){
    return response.toString()==this.POWER_OFF_STATE && flagPowerOffState==false
  }
  private conditionStartScanning(){
    let state=this.connect.getStateTrack().toString();
    if(this.conditionConnected() && state==this.READY_STATE && this.scanningFlag==false){
      this.scanningFlag=true;
      this.connect.flowStart();
    }
  }

  private getVariablesObjectOfScannerControl(response){
    this.onConnected=response["OnConnected"];
    this.onDisconnected=response["OnDisconnected"];
    this.stateTrack=response["tTrackState"];
    this.hopperEmpty=response["OnHopperEmpty"];
    this.flowStopped=response["OnFlowStopped"];
    this.serialEscaner=response["tSerialNumber0"];
    this.exceptionInProgress=response["OnExceptionInProgress"];    
  }
  
  private getMessageAccionWhenShutDownScanner(){
    return this.forceShutDownScanner==true?this.informationMessages.getMessageInformation("FORCE_SHUT_DOWN_SCANNER"):this.informationMessages.getMessageInformation("EMPTY_EXCEPTION");
  }

  private sendAccion$(message){
    this.dataTransmission.setAccion$(message);
  }
  private sendAlert$(alert){
    this.dataTransmission.setAlert$(alert);
  }
  private sendImages$(images){
    this.dataTransmission.setImages$(images);
  }
  private sendLabelScanner$(labelScanner){
    this.dataTransmission.setLabelScanner$(labelScanner);
  }
  private sendCircleScanner$(circleScanner){
    this.dataTransmission.setCircleScanner$(circleScanner);
  }
  private sendSerialScanner$(serialScanner){
    this.dataTransmission.setSerialScanner$(serialScanner);
  }
  private sendErrorCode$(errorCodeMessage){
    this.dataTransmission.setErrorCode$(errorCodeMessage);
  }
  private sendWarningMessage$(warningMessage){
    this.dataTransmission.setWarningMessage$(warningMessage);
  }
  private sendSuccessMessage$(successMessage){
    this.dataTransmission.setSuccessMessage$(successMessage);
  }
  private sendInformationImages$(informationImages){
    this.dataTransmission.setInformationImages$(informationImages);
  }
}
