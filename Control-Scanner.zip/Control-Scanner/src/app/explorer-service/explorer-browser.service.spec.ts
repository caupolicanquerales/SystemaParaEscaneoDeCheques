import { TestBed } from '@angular/core/testing';

import { ExplorerBrowserService } from './explorer-browser.service';

describe('ExplorerBrowserService', () => {
  let service: ExplorerBrowserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExplorerBrowserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
