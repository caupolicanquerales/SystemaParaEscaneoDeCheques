var scannerControl;
var STATE_POWER_OFF = 1;
var STATE_IDLE = 2;
var STATE_RECOVERY = 3;
var STATE_READY = 4;
var STATE_FLOWING = 5;
var STATE_EXCEPTION = 6;
var STATE_MTR = 7;
var STATE_MACHINE_DEAD = 8;
var inCloseScanner = false;
var imageStoragePath;
var configDir;
var readerini;
var endorseini;
var imageini;
var docDIN = 0;
var valueObjectsScanner={};
var FLAG_TO_GET_ALL_IMAGES=0;
var objectDocReadComplete={};
var generalResultScanning=[];

export function resetVariablesScannerControl()
{
    scannerControl.OnBlackBandEvent = null;
    scannerControl.OnCLICaptured = null;
    scannerControl.OnDocComplete = null;
    scannerControl.OnDocImageComplete = null;
    scannerControl.OnDocImageSnippetComplete = null;
    scannerControl.OnDocReadComplete = null;
    scannerControl.OnDocRejected = null;
    scannerControl.OnFlowStopped = null;
    scannerControl.OnHopperEmpty = null;
    scannerControl.OnIdle = null;
    scannerControl.OnMachineDead = null;
    scannerControl.OnMakeReadyToFlowComplete = null;
    scannerControl.OnMFilmGetFilmLengthComplete = null;
    scannerControl.OnMFilmSkip = null;
    scannerControl.OnMFilmSlewComplete = null;
    scannerControl.OnMTREntered = null;
    scannerControl.OnMTRExited = null;
    scannerControl.OnMTRResponse = null;
    scannerControl.OnMTRResponseBinary = null;
    scannerControl.OnNVMReadComplete = null;
    scannerControl.OnPocketChange = null;
    scannerControl.OnPoweredDown = null;
    scannerControl.OnPoweredUp = null;
    scannerControl.OnPoweringUp = null;
    scannerControl.OnReadying = null;
    scannerControl.OnReadyToProcess = null;
    scannerControl.OnRecoveryComplete = null;
    scannerControl.OnRepassVerify = null;
    scannerControl.OnStackerButtonPressed = null;
    scannerControl.OnStateException = null;
    scannerControl.OnWarning = null;
    scannerControl.Quit();
    scannerControl=null;
}
export function resetActiveXObject(){
    scannerControl.Quit();
    scannerControl=null;
    window.setTimeout(CollectGarbage,10);
}

export function initScanner()
{
    inCloseScanner = 0;
    scannerControl = new ActiveXObject("ScannerControl.ScannerControl");
    imageStoragePath = scannerControl.imageFolder;
    console.log("imageStoragePath=[" + imageStoragePath + "]");
    configDir = imageStoragePath;
    readerini = configDir + "\\READER.INI";
    endorseini = configDir + "\\ENDORSE.INI";
    imageini = configDir + "\\IMAGE.INI";
                
    scannerControl.OnBlackBandEvent = function(args) {
        valueObjectsScanner["OnBlackBandEvent"]= args;
    }
    scannerControl.OnCLICaptured = function(args) {
        valueObjectsScanner["OnCLICaptured"]= args;
    }
    scannerControl.OnConnected = function(args) {
        valueObjectsScanner["OnConnected"]= args;
        valueObjectsScanner["OnDisconnected"]= null;
    }
    scannerControl.OnDisconnected = function(args) {
        valueObjectsScanner["OnDisconnected"]= args;
        valueObjectsScanner["OnConnected"]= null;
    }
    
    scannerControl.OnDocComplete = function(args) {
        valueObjectsScanner["OnDocComplete"]= args;
    }

    scannerControl.OnDocImageComplete = function(args) {
        valueObjectsScanner["OnDocImageComplete"]= args;
        let objectDocImageComplete={}; 
        if(FLAG_TO_GET_ALL_IMAGES!=0){
            objectDocImageComplete["idDoc"] = scannerControl.imgDocId.toString();
            let img1FrontPtr= scannerControl.img1FrontPtr;
            let img1RearPtr= scannerControl.img1RearPtr;
            let img1FrontSize= scannerControl.img1FrontSize;
            let img1RearSize= scannerControl.img1RearSize;
            objectDocImageComplete["imgFront"] =convertImageToBase64(img1FrontPtr,img1FrontSize);
            objectDocImageComplete["imgRear"] =convertImageToBase64(img1RearPtr,img1RearSize);
            let objetResultDoc={...objectDocReadComplete,...objectDocImageComplete};
            generalResultScanning.push(objetResultDoc);
        }
        FLAG_TO_GET_ALL_IMAGES=1;
    }

    scannerControl.OnDocImageSnippetComplete = function(args) {
        valueObjectsScanner["OnDocImageSnippetComplete"]= args;
    }
    
    scannerControl.OnDocReadComplete = function(args) {
        valueObjectsScanner["OnDocImageComplete"]= args;
        objectDocReadComplete={};
        FLAG_TO_GET_ALL_IMAGES=0;
        objectDocReadComplete["idDoc"] = scannerControl.rRdrDocId.toString();
        objectDocReadComplete["dr1"] =removeFirstAndLastCharacter(scannerControl.rRdr1CodeLine);
        objectDocReadComplete["dr2"] =removeFirstAndLastCharacter(scannerControl.rRdr2CodeLine);
        objectDocReadComplete["dr3"] =removeFirstAndLastCharacter(scannerControl.rRdr3CodeLine);
        objectDocReadComplete["err1"] =scannerControl.rRdr1CantReadCount;
        objectDocReadComplete["err2"] =scannerControl.rRdr2CantReadCount;
        objectDocReadComplete["err3"] =scannerControl.rRdr3CantReadCount;
        scannerControl.DocAccept();
        scannerControl.DocProcess();
    }
    scannerControl.OnDocRejected = function(args) {
        valueObjectsScanner["OnDocRejected"]= args;
    }
    scannerControl.OnExceptionComplete = function(args) {
        valueObjectsScanner["OnExceptionComplete"]= scannerControl.epExceptionCode;
    }
    scannerControl.OnExceptionInProgress = function(args) {
        valueObjectsScanner["OnExceptionInProgress"]= scannerControl.epExceptionCode;
        valueObjectsScanner["tTrackState"]= scannerControl.tTrackState;
    }
    scannerControl.OnFlowStopped = function(args) {
        valueObjectsScanner["OnFlowStopped"]= args;
        valueObjectsScanner["tTrackState"]= scannerControl.tTrackState;
    }
    scannerControl.OnHopperEmpty = function(args) {
        valueObjectsScanner["OnHopperEmpty"]= args;
        valueObjectsScanner["tTrackState"]= scannerControl.tTrackState;
    }
    scannerControl.OnIdle = function(args) {
        valueObjectsScanner["OnIdle"]= args;
        valueObjectsScanner["tTrackState"]=scannerControl.tTrackState;
    }
    scannerControl.OnMachineDead = function(args) {
        valueObjectsScanner["OnMachineDead"]= args;
    }
    scannerControl.OnMakeReadyToFlowComplete = function(args) {
        valueObjectsScanner["OnMakeReadyToFlowComplete"]= args;
    }
    scannerControl.OnMFilmGetFilmLengthComplete = function(args) {
        valueObjectsScanner["OnMFilmGetFilmLengthComplete"]= args;
    }
    scannerControl.OnMFilmSkip = function(args) {
        valueObjectsScanner["OnMFilmSkip"]= args;
    }
    scannerControl.OnMFilmSlewComplete = function(args) {
        valueObjectsScanner["OnMFilmSlewComplete"]= args;
    }
    scannerControl.OnMTREntered = function(args) {
        valueObjectsScanner["OnMTREntered"]= args;
    }
    scannerControl.OnMTRExited = function(args) {
        valueObjectsScanner["OnMTRExited"]= args;
    }
    scannerControl.OnMTRResponse = function(args) {
        valueObjectsScanner["OnMTRResponse"]= args;
    }
    scannerControl.OnMTRResponseBinary = function(args) {
        valueObjectsScanner["OnMTRResponseBinary"]= args;
    }
    scannerControl.OnNVMReadComplete = function(args) {
        valueObjectsScanner["OnNVMReadComplete"]= args;
    }
    scannerControl.OnPocketChange = function(args) {
        valueObjectsScanner["OnPocketChange"]= args;
    }
    scannerControl.OnPoweredDown = function(args) {
        valueObjectsScanner["OnPoweredDown"]= args;
        valueObjectsScanner["tTrackState"]= scannerControl.tTrackState;
    }
    scannerControl.OnPoweredUp = function(args) {
        valueObjectsScanner["OnPoweredUp"]= args;
        valueObjectsScanner["tTrackState"]= scannerControl.tTrackState;
    }
    scannerControl.OnPoweringUp = function(args) {
        scannerControl.iEndFontSetup = endorseini;
        scannerControl.iEndorserLines = 0;
        scannerControl.iEndRearSequenceNumberIncrement = 1;
        scannerControl.iEndRearSequenceNumberStart = 1;
        scannerControl.iImageStoragePath = imageStoragePath;
        scannerControl.iImgCarSetupFilePath = imageini;
        scannerControl.iImgImageDirectory = "";
        scannerControl.iOptions = 0;
        scannerControl.iRdrFontLoadPath = readerini;
        valueObjectsScanner["tSerialNumber0"]= scannerControl.tSerialNumber0;
        valueObjectsScanner["tTrackState"]=scannerControl.tTrackState;
    }
    scannerControl.OnReadying = function(args) {
        valueObjectsScanner["OnReadying"]= args;
        valueObjectsScanner["tTrackState"]= scannerControl.tTrackState;
    }
    scannerControl.OnReadyToProcess = function(args) {
        valueObjectsScanner["tTrackState"]= scannerControl.tTrackState;
        valueObjectsScanner["OnReadyToProcess"]= args;
    }
    scannerControl.OnRecoveryComplete = function(args) {
        valueObjectsScanner["OnRecoveryComplete"]= args;
    }
    scannerControl.OnRepassVerify = function(args) {
        valueObjectsScanner["OnRepassVerify"]= args;
    }
    scannerControl.OnStackerButtonPressed = function(args) {
        valueObjectsScanner["OnStackerButtonPressed"]= args;
    }
    scannerControl.OnStateException = function(args) {
        valueObjectsScanner["OnStateException"]= args;
    }
    scannerControl.OnWarning = function(args) {
        valueObjectsScanner["OnWarning"]= args;
    }
}

export function closeScanner()
{
    inCloseScanner = true;
    if(scannerControl.tTrackState != STATE_POWER_OFF)
    {
        if(scannerControl.tTrackState == STATE_FLOWING)
        {
            flowStop();
        }
        if (scannerControl.tTrackState != STATE_IDLE)
        {
            goIdle();
        }
        powerDown();
    }
}

export function flowStart()
{
    generalResultScanning=[];
    scannerControl.FlowStart(0);
}

export function goIdle()
{
    scannerControl.GoIdle();
}

export function goReadyToProcess()
{
    scannerControl.iEndorserLines = 0;
    scannerControl.iEndRearSequenceNumberIncrement = 1;
    scannerControl.iEndRearSequenceNumberStart = 1;
    scannerControl.iImageStoragePath = imageStoragePath;
    scannerControl.iImgCarSetupFilePath = imageini;
    scannerControl.iImgImageDirectory = "";
    scannerControl.iOptions = 0;
    scannerControl.iRdrFontLoadPath = readerini;
    //Endorse options
    scannerControl.pEndFrontOptions = 0;
    scannerControl.pEndRearOptions = 0;
    scannerControl.pEndFrontLine1 = "";
    scannerControl.pEndFrontLine2 = "";
    scannerControl.pEndFrontLine3 = "";
    scannerControl.pEndFrontLine4 = "";
    scannerControl.pEndRearLine1 = "";
    scannerControl.pEndRearLine2 = "";
    scannerControl.pEndRearLine3 = "";
    scannerControl.pEndRearLine4 = "";
    scannerControl.pEndFrontFontNumber = 0;
    scannerControl.pEndRearFontNumber = 0;
    scannerControl.pEndFrontLogoNumber = 0;
    scannerControl.pEndRearLogoNumber = 0;
    scannerControl.pEndFrontLogoPosition = 0;
    scannerControl.pEndRearLogoPosition = 0;
    //stamp
    scannerControl.pStmpOptions = 0;
    scannerControl.pStmpFrontPosition = 0;
    scannerControl.pStmpRearPosition = 0;
    //Encoder data
    scannerControl.pEncData = "";
    scannerControl.pEncOptions = 0;
    //Mfilmer
    scannerControl.pMfilmOptions = 0;
    scannerControl.pMfilmVerticalAnnotation = "";
    //Image
    scannerControl.pImgOptions = parseInt("05", 16);	//00000101
    scannerControl.pImgFilename = "IM" + docDIN;
    //exception handling
    scannerControl.pXcpDeleteAllowed = false;
    scannerControl.pXcpIdentify = "";
    scannerControl.pXcpOptions = 0;
    //Pocket
    scannerControl.pStkPocket = 1;
    scannerControl.GoReadyToProcess();
}

export function flowStop()
{
    scannerControl.FlowStop();
}

export function powerUp()
{
    scannerControl.pupOptions = 1;
    scannerControl.PowerUp();
}

export function powerDown()
{
    scannerControl.PowerDown();
}

export function getValueObjectScanner(){
    return new Promise(function(resolve,reject){
            resolve(valueObjectsScanner);
        }); 
}
export function getStateTrackScanner(){
    return new Promise(function(resolve,reject){
        resolve(scannerControl.tTrackState);
    });
}
export function getStateTrack(){
    return scannerControl.tTrackState;
}
export function getGeneralResultScanning(){
    return generalResultScanning;
}
export function resetValueObjectScanner(){
    valueObjectsScanner["OnFlowStopped"]= null;
    valueObjectsScanner["OnHopperEmpty"]= null;
}
export function resetExceptionVariables(){
    valueObjectsScanner["OnExceptionInProgress"] = null;
    valueObjectsScanner["OnExceptionComplete"] = null;
}
export function resetConnectedAndDisconnectedVariables(){
    valueObjectsScanner["OnConnected"]= null;
    valueObjectsScanner["OnDisconnected"]= null;
}

function convertImageToBase64(imgPtr,imgSize){
    if (imgSize != 0)
    {
        var imageBase64 = scannerControl.GetImage(imgPtr,imgSize);
        return imageBase64;
    }
    return "";
}
function removeFirstAndLastCharacter(rdrCodeLine){
    console.log(typeof(rdrCodeLine));
    if(rdrCodeLine && rdrCodeLine!=""){
        let codeLine=rdrCodeLine.substring(1).trim();
        codeLine=codeLine.substring(0,codeLine.length-1);
        return codeLine;
    }
    return rdrCodeLine;
}
