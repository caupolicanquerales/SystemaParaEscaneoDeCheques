
export function detectingTypeOfBrowser(){
    let chromeAgent = navigator.userAgent.indexOf("Chrome") > -1;
    let edgeAgent = navigator.userAgent.indexOf("Edg/") > -1; 
    let firefoxAgent = navigator.userAgent.indexOf("Firefox") > -1;
    let operaAgent = navigator.userAgent.indexOf("OP") > -1;
    if(chromeAgent && !edgeAgent){
        return "Chrome";
    }
    if(edgeAgent && chromeAgent){
        return "Edge";
    }
    if(firefoxAgent){
        return "Firefox";
    }
    if(operaAgent){
        return "Opera";
    }
    return "Explorer";
} 