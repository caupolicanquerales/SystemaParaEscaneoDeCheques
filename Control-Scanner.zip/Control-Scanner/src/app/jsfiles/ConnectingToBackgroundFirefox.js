

export function launchServerSystem(extensionId) {

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "launchServerSystem",
            message: extensionId
        }, "*");

        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)

                reject(event.data.message)
            }
        }, false);

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}

export function launchClientSystem(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "launchClientSystem",
            message: extensionId
        }, "*");
        
        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);
        
    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}


export function closeServerSystem(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "closeServerSystem",
            message: extensionId
        }, "*");
        
        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);
        

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}

export function shutDownScanner(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "shutDownScanner",
            message: extensionId
        }, "*");
        
        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}

export function goIdleStateScanner(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "goIdleStateScanner",
            message: extensionId
        }, "*");
        
        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}

export function checkingClientServerSystem(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "checkingClientServerSystem",
            message: extensionId
        }, "*");

        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}

export function connectingScanner(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "connectingScanner",
            message: extensionId
        }, "*");

        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}

export function scanningProcessing(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "scanningProcessing",
            message: extensionId
        }, "*");

        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}

export function shutDownLaunchSocketApp(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        window.postMessage({
            direction: "shutDownLaunchSocketApp",
            message: extensionId
        }, "*");

        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}

export async function callingChuckInformation(message,extensionId){
    let chunk="";
    let information=message;
    while(chunk !== "END_MESSAGE"){
        chunk= await chunkOfInformation(extensionId);
        if(chunk !== "END_MESSAGE"){
            information=information.concat(chunk);
        }
        console.log(information);
    }
    return information;
}

export function chunkOfInformation(extensionId){

    var p1 = new Promise(function(resolve, reject) {
        
        window.postMessage({
            direction: "chuckOfInformation",
            message: extensionId
        }, "*");

        var event_ref_res = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleResponse") {
                
                window.removeEventListener("message", event_ref_res)
                
                resolve(event.data.message)
            }
        }, false);

        var event_ref_err = window.addEventListener("message", function(event) {
            if (event.source == window &&
                event.data.direction &&
                event.data.direction == "handleError") {
                
                window.removeEventListener("message", event_ref_err)
                
                reject(event.data.message)
            }
        }, false);

    });

    return p1.then(
        (response) => {return response;}
    ).catch(
        (error) => {return error;}
    );
}
