

export function launchServerSystem(extensionId) {
    let directionCommand="launchServerSystem";
    return executing(extensionId,directionCommand);
}
export function launchClientSystem(extensionId){
    let directionCommand="launchClientSystem";
    return executing(extensionId,directionCommand);
}
export function closeServerSystem(extensionId){
    let directionCommand="closeServerSystem";
    return executing(extensionId,directionCommand);
}
export function shutDownScanner(extensionId){
    let directionCommand="shutDownScanner";
    return executing(extensionId,directionCommand);
}
export function goIdleStateScanner(extensionId){
    let directionCommand="goIdleStateScanner";
    return executing(extensionId,directionCommand);
}
export function checkingClientServerSystem(extensionId){
    let directionCommand="checkingClientServerSystem";
    return executing(extensionId,directionCommand);
}
export function connectingScanner(extensionId){
    let directionCommand="connectingScanner";
    return executing(extensionId,directionCommand);
}
export function scanningProcessing(extensionId){
    let directionCommand="scanningProcessing";
    return executing(extensionId,directionCommand);
}
export function shutDownLaunchSocketApp(extensionId){
    let directionCommand="shutDownLaunchSocketApp";
    return executing(extensionId,directionCommand);
}
export function chunkOfInformation(extensionId){
    let directionCommand="chuckOfInformation";
    return executing(extensionId,directionCommand);
}
async function executing(extensionId,directionCommand){
    const p1= await getPromise(extensionId,directionCommand);
    return p1;
}
function getPromise(extensionId,directionCommand){
    var event_ref_res=null;
    var event_ref_err=null;
    return new Promise(function(resolve, reject) {
        window.postMessage({
            direction: directionCommand,
            message: extensionId
        }, "*");
        event_ref_res=methodToAddEventListenerResolve(resolve);
        event_ref_err=methodToAddEventListenerReject(reject);
    }).then((response)=>{
        window.removeEventListener("message", event_ref_res,false);
        return response;
    }).catch((error)=>{
        window.removeEventListener("message", event_ref_err,false);
        return error;});
}


export async function callingChuckInformation(message,extensionId){
    let chunk="";
    let information=message;
    while(chunk !== "END_MESSAGE"){
        chunk= await chunkOfInformation(extensionId);
        if(chunk !== "END_MESSAGE"){
            information=information.concat(chunk);
        }
    }
    return information;
}

function methodToAddEventListenerResolve(resolve){
    var event_ref_res = window.addEventListener("message", function(event) {
        if (event.source == window &&
            event.data.direction &&
            event.data.direction == "handleResponse") {
            resolve(event.data.message);
        }
    }, false);
    return event_ref_res;
}
function methodToAddEventListenerReject(reject){
    var event_ref_err = window.addEventListener("message", function(event) {
        if (event.source == window &&
            event.data.direction &&
            event.data.direction == "handleError") {
            reject(event.data.message)
        }
    }, false);
    return event_ref_err;
}


