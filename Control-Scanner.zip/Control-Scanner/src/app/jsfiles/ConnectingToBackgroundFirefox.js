
var extensionId = "icbs@example.org";

export function callingBackground(){
    return new Promise(function(resolve,reject){
        var sending =browser.runtime.sendMessage({connecting: "callingBackground"});
        sending.then(function(message){
            resolve(message);
        }, handleError);    
    });
}
function handleResponse(message) {
    console.log(`Message from the background script:  ${message.response}`);
  }
  
  function handleError(error) {
    console.log(`Error: ${error}`);
  }
  