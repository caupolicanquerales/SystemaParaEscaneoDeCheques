//var editorExtensionId = "lkmhhpnhpbokjiglplbfidgjijlfgbpi";
//var extensionIdEdge="flmaeakblaohpdfhbbomoanppgbmoked";


export function launchClientSystem(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "launchClient"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function launchServerSystem(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "launchServer"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function closeServerSystem(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "closeServer"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}
export function shutDownLaunchSocketApp(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "shutDownLaunchSocketApp"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function shutDownScanner(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "shutDownScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function goIdleStateScanner(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "goIdleStateScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function checkingClientServerSystem(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "checkingClientServerSystem"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function connectingScanner(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "connectingScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    });
}

export function scanningProcessing(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "scanning"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    });   
}

export async function callingChuckInformation(message,extensionId){
    let chunk="";
    let information=message;
    while(chunk!="END_MESSAGE"){
        let valor= await chuckOfInformation(extensionId);
        chunk=valor.echo;
        if(chunk!="END_MESSAGE"){
            information=information.concat(chunk);
        }
    }
    return information; 
}

export function chuckOfInformation(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "chuckOfInformation"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    });   
}