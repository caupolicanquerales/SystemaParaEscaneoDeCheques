
export function launchClientSystem(extensionId){
    return executinglaunchClientSystem(extensionId);
}
export function launchServerSystem(extensionId){
    return executinglaunchServerSystem(extensionId);
}
export function checkingClientServerSystem(extensionId){
    return executingcheckingClientServerSystem(extensionId);
}
export function closeServerSystem(extensionId){
    return executingcloseServerSystem(extensionId);
}
export function connectingScanner(extensionId){
    return executingconnectingScanner(extensionId);
}
export function goIdleStateScanner(extensionId){
    return executinggoIdleStateScanner(extensionId);
}
export function shutDownScanner(extensionId){
    return executingshutDownScanner(extensionId);
}
export function scanningProcessing(extensionId){
    return executingscanningProcessing(extensionId);
}
export function callingChuckInformation(message,extensionId){
    return executingcallingChuckInformation(message,extensionId);
}
async function executinglaunchClientSystem(extensionId){
    const p1= await launchClientSystemPromise(extensionId);
    return p1;
}
async function executinglaunchServerSystem(extensionId){
    const p1= await launchServerSystemPromise(extensionId);
    return p1;
}
async function executingcheckingClientServerSystem(extensionId){
    const p1= await checkingClientServerSystemPromise(extensionId);
    return p1;
}
async function executingcloseServerSystem(extensionId){
    const p1= await closeServerSystemPromise(extensionId);
    return p1;
}
async function executingconnectingScanner(extensionId){
    const p1= await connectingScannerPromise(extensionId);
    return p1;
}
async function executinggoIdleStateScanner(extensionId){
    const p1= await goIdleStateScannerPromise(extensionId);
    return p1;
}
async function executingshutDownScanner(extensionId){
    const p1= await shutDownScannerPromise(extensionId);
    return p1;
}
async function executingscanningProcessing(extensionId){
    const p1= await scanningProcessingPromise(extensionId);
    return p1;
}
function launchClientSystemPromise(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "launchClient"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    }).then((response)=>{return response;}).catch((error)=>{return error;});
}

function launchServerSystemPromise(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "launchServer"},
        function(response) {
            if (!response || response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    }).then((response)=>{return response;}).catch((error=>{return error;}));
}

function checkingClientServerSystemPromise(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "checkingClientServerSystem"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    }).then((response)=>{return response;}).catch((error)=>{return error;});
}

function closeServerSystemPromise(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "closeServer"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    }).then((response)=>{return response;}).catch((error)=>{return error;});
}
export function shutDownLaunchSocketApp(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "shutDownLaunchSocketApp"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

function shutDownScannerPromise(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "shutDownScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    }).then((response)=>{return response;}).catch((error)=>{return error;});
}

function goIdleStateScannerPromise(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "goIdleStateScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    }).then((response)=>{return response;}).catch((error)=>{return error;});
}

function connectingScannerPromise(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "connectingScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    }).then((response)=>{return response;}).catch((error)=>{return error;});
}

function scanningProcessingPromise(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "scanning"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    }).then((response)=>{return response;}).catch((error)=>{return error;});   
}

async function executingcallingChuckInformation(message,extensionId){
    let chunk="";
    let information=message;
    while(chunk!="END_MESSAGE"){
        let valor= await chuckOfInformation(extensionId);
        chunk=valor.echo;
        if(chunk!="END_MESSAGE"){
            information=information.concat(chunk);
        }
    }
    return information; 
}

function chuckOfInformation(extensionId){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(extensionId, {connecting: "chuckOfInformation"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    }).then((response)=>{return response;}).catch((error)=>{return error;});   
}