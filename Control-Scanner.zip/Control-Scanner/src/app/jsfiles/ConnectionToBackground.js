//var editorExtensionId = "acoefgknodogkeannhciiekgpmhcfpma";
var editorExtensionId = "lkmhhpnhpbokjiglplbfidgjijlfgbpi";


export function launchClientSystem(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "launchClient"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function launchServerSystem(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "launchServer"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function closeServerSystem(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "closeServer"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function shutDownScanner(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "shutDownScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function goIdleStateScanner(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "goIdleStateScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function checkingClientServerSystem(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "checkingClientServerSystem"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        }); 
    });
}

export function connectingScanner(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "connectingScanner"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    });
}

export function scanningProcessing(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "scanning"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    });   
}

export async function callingChuckInformation(message){
    let chunk="";
    let information=message;
    while(chunk!="END_MESSAGE"){
        let valor= await chuckOfInformation();
        chunk=valor.echo;
        if(chunk!="END_MESSAGE"){
            information=information.concat(chunk);
        }
    }
    return information; 
}

export function chuckOfInformation(){
    return new Promise(function(resolve,reject){
        chrome.runtime.sendMessage(editorExtensionId, {connecting: "chuckOfInformation"},
        function(response) {
            if (response.error){
                reject("error")
            }
            resolve(response.connected);
        });
    });   
}