﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Text.RegularExpressions;

namespace ScannerControl
{
	public class Scanner : IScannerControl
	{
		DpocxLib.Dpocx dpOCX = null;
		ImageConvertion convertion = null;
		
		int M_MODE_AUTO_FEED = 0;
		int M_MODE_SINGLE_FEED = 1;
		int M_MODE_AUTO_FEED_WAIT_THREAD = 6;
		int M_MODE_SINGLE_FEED_WAIT_THREAD = 7;
		int M_MODE_AUTO_ID = 8;
		int M_MODE_SINGLE_ID = 9;
		int M_MODE_AUTO_ID_WAIT_THREAD = 10;
		int M_MODE_SINGLE_ID_WAIT_THREAD = 11;
		string M_MODE_NO_DEVICE_CONNECTED = "-1";
		int M_MODE_STATE_EXCEPTION = 6;

		public int MODE_AUTO_FEED { get { return M_MODE_AUTO_FEED; } }
		public int MODE_SINGLE_FEED { get { return M_MODE_SINGLE_FEED; } }
		public int MODE_AUTO_FEED_WAIT_THREAD { get { return M_MODE_AUTO_FEED_WAIT_THREAD; } }
		public int MODE_SINGLE_FEED_WAIT_THREAD { get { return M_MODE_SINGLE_FEED_WAIT_THREAD; } }
		public int MODE_AUTO_ID { get { return M_MODE_AUTO_ID; } }
		public int MODE_SINGLE_ID { get { return M_MODE_SINGLE_ID; } }
		public int MODE_AUTO_ID_WAIT_THREAD { get { return M_MODE_AUTO_ID_WAIT_THREAD; } }
		public int MODE_SINGLE_ID_WAIT_THREAD { get { return M_MODE_SINGLE_ID_WAIT_THREAD; } }
		public int FLAG_TO_GET_ALL_IMAGES { get; set; } = 0;
		public string CONCAT_IMAGES_FROM_SCANNER { get; set; } = "";
		public string CONCAT_CODE_LINE_FROM_SCANNER { get; set; } = "";
		public string NO_DEVICE_CONNECTED { get { return M_MODE_NO_DEVICE_CONNECTED; } }
		public int STATE_EXCEPTION { get { return M_MODE_STATE_EXCEPTION; } }

		//get_status: sirve para verificar el estado de scanner (OK, apagado, cartucho sin tinta, etc): Tenemos que definir los posibles códigos de error que podemos llegar a recibir
		//start_scanning_order: pedido de inicio de una nueva orden de escaneo de cheques
		//get_status_scanning_order: verificación del estado de la orden de escaneo de cheques
		//get_check: pedido de un cheque puntual (imagen frente / dorso / cmc7)
		//finish_scanning_order: finalizar orden de trabajo
		#region IScannerControl Event declaration

		public Object OnClose { get; set; }
		public Object OnBlackBandEvent { get; set; }
		public Object OnCLICaptured { get; set; }
		public Object OnConnected { get; set; } = 0;
		public Object OnDisconnected { get; set; } = 0;
		public Object OnDocComplete { get; set; }
		public Object OnDocImageComplete { get; set; } = "";
		public Object OnDocImageSnippetComplete { get; set; }
		public Object OnDocReadComplete { get; set; } = "";
		public Object OnDocRejected { get; set; }
		public Object OnExceptionComplete { get; set; } = 0;
		public Object OnExceptionInProgress { get; set; } = "";
		public Object OnFlowStopped { get; set; } = 0;
		public Object OnHopperEmpty { get; set; } = 0;
		public Object OnIdle { get; set; } = 0;
		public Object OnMachineDead { get; set; } = 0;
		public Object OnMakeReadyToFlowComplete { get; set; }
		public Object OnMFilmGetFilmLengthComplete { get; set; }
		public Object OnMFilmSkip { get; set; }
		public Object OnMFilmSlewComplete { get; set; }
		public Object OnMTREntered { get; set; }
		public Object OnMTRExited { get; set; }
		public Object OnMTRResponse { get; set; }
		public Object OnMTRResponseBinary { get; set; }
		public Object OnNVMReadComplete { get; set; }
		public Object OnPocketChange { get; set; }
		public Object OnPoweredDown { get; set; } = 0;
		public Object OnPoweredUp { get; set; } = 0;
		public Object OnPoweringUp { get; set; } = 0;
		public Object OnReadying { get; set; } = 0;
		public Object OnReadyToProcess { get; set; } = 0;
		public Object OnRecoveryComplete { get; set; }
		public Object OnRepassVerify { get; set; }
		public Object OnStackerButtonPressed { get; set; }
		public Object OnStateException { get; set; }
		public Object OnWarning { get; set; } = "";
		public Object AddressProject { get; set; } = "";

		#endregion

		#region IScannerControl properties

		public int CAPI_Version { get { return dpOCX.CAPI_Version; } set { dpOCX.CAPI_Version = value; } }
		public string cAppDocData { get { return dpOCX.cAppDocData; } set { dpOCX.cAppDocData = value; } }
		public string cAppDocDataExtSA { get { return dpOCX.cAppDocDataExtSA; } set { dpOCX.cAppDocDataExtSA = value; } }
		public string cAppDocDataSA { get { return dpOCX.cAppDocDataSA; } set { dpOCX.cAppDocDataSA = value; } }
		public int cAppDocDIN { get { return dpOCX.cAppDocDIN; } set { dpOCX.cAppDocDIN = value; } }
		public int cDocCompleteDevInfo { get { return dpOCX.cDocCompleteDevInfo; } set { dpOCX.cDocCompleteDevInfo = value; } }
		public short cDocCompleteStatus { get { return dpOCX.cDocCompleteStatus; } set { dpOCX.cDocCompleteStatus = value; } }
		public int ceDocId { get { return dpOCX.ceDocId; } set { dpOCX.ceDocId = value; } }
		public string ceEncData { get { return dpOCX.ceEncData; } set { dpOCX.ceEncData = value; } }
		public int cEndRearSequenceNumber { get { return dpOCX.cEndRearSequenceNumber; } set { dpOCX.cEndRearSequenceNumber = value; } }
		public int cfgDevicesFitted { get { return dpOCX.cfgDevicesFitted; } set { dpOCX.cfgDevicesFitted = value; } }
		public short cfgNumPockets { get { return dpOCX.cfgNumPockets; } set { dpOCX.cfgNumPockets = value; } }
		public int cfgNVMBase { get { return dpOCX.cfgNVMBase; } set { dpOCX.cfgNVMBase = value; } }
		public int cfgNVMLength { get { return dpOCX.cfgNVMLength; } set { dpOCX.cfgNVMLength = value; } }
		public int cpDocId { get { return dpOCX.cpDocId; } set { dpOCX.cpDocId = value; } }
		public short cpStkPocket { get { return dpOCX.cpStkPocket; } set { dpOCX.cpStkPocket = value; } }
		public int cSorterId { get { return dpOCX.cSorterId; } set { dpOCX.cSorterId = value; } }
		public short cStkPocket { get { return dpOCX.cStkPocket; } set { dpOCX.cStkPocket = value; } }
		public bool ecManualDropSwitch { get { return dpOCX.ecManualDropSwitch; } set { dpOCX.ecManualDropSwitch = value; } }
		public int ecSorterId { get { return dpOCX.ecSorterId; } set { dpOCX.ecSorterId = value; } }
		public string epExceptionCode { get { return dpOCX.epExceptionCode; } set { dpOCX.epExceptionCode = value; } }
		public int epExceptionDevice { get { return dpOCX.epExceptionDevice; } set { dpOCX.epExceptionDevice = value; } }
		public int epExceptionType { get { return dpOCX.epExceptionType; } set { dpOCX.epExceptionType = value; } }
		public int epSorterId { get { return dpOCX.epSorterId; } set { dpOCX.epSorterId = value; } }
		public int eSorterId { get { return dpOCX.eSorterId; } set { dpOCX.eSorterId = value; } }
		public short iEncPosition { get { return dpOCX.iEncPosition; } set { dpOCX.iEncPosition = value; } }
		public string iEndFontSetup { get { return dpOCX.iEndFontSetup; } set { dpOCX.iEndFontSetup = value; } }
		public int iEndorserLines { get { return dpOCX.iEndorserLines; } set { dpOCX.iEndorserLines = value; } }
		public int iEndRearSequenceNumberIncrement { get { return dpOCX.iEndRearSequenceNumberIncrement; } set { dpOCX.iEndRearSequenceNumberIncrement = value; } }
		public int iEndRearSequenceNumberStart { get { return dpOCX.iEndRearSequenceNumberStart; } set { dpOCX.iEndRearSequenceNumberStart = value; } }
		public bool iEntryIgnoreDogEarError { get { return dpOCX.iEntryIgnoreDogEarError; } set { dpOCX.iEntryIgnoreDogEarError = value; } }
		public bool iEntryStopOnBlackBand { get { return dpOCX.iEntryStopOnBlackBand; } set { dpOCX.iEntryStopOnBlackBand = value; } }
		public int iHSEMOptions { get { return dpOCX.iHSEMOptions; } set { dpOCX.iHSEMOptions = value; } }
		public bool iHSEMOutSort { get { return dpOCX.iHSEMOutSort; } set { dpOCX.iHSEMOutSort = value; } }
		public string iImageStoragePath { get { return dpOCX.iImageStoragePath; } set { dpOCX.iImageStoragePath = value; } }
		public string iImgAnnotate { get { return dpOCX.iImgAnnotate; } set { dpOCX.iImgAnnotate = value; } }
		public string iImgAnnotateExtSA { get { return dpOCX.iImgAnnotateExtSA; } set { dpOCX.iImgAnnotateExtSA = value; } }
		public string iImgAnnotateSA { get { return dpOCX.iImgAnnotateSA; } set { dpOCX.iImgAnnotateSA = value; } }
		public string iImgCarSetupFilePath { get { return dpOCX.iImgCarSetupFilePath; } set { dpOCX.iImgCarSetupFilePath = value; } }
		public string iImgImageDirectory { get { return dpOCX.iImgImageDirectory; } set { dpOCX.iImgImageDirectory = value; } }
		public int iMandatoryDevices { get { return dpOCX.iMandatoryDevices; } set { dpOCX.iMandatoryDevices = value; } }
		public short iMfilmLampIntensity { get { return dpOCX.iMfilmLampIntensity; } set { dpOCX.iMfilmLampIntensity = value; } }
		public int img1FrontPtr { get { return dpOCX.img1FrontPtr; } set { dpOCX.img1FrontPtr = value; } }
		public int img1FrontSize { get { return dpOCX.img1FrontSize; } set { dpOCX.img1FrontSize = value; } }
		public int img1RearPtr { get { return dpOCX.img1RearPtr; } set { dpOCX.img1RearPtr = value; } }
		public int img1RearSize { get { return dpOCX.img1RearSize; } set { dpOCX.img1RearSize = value; } }
		public int img2FrontPtr { get { return dpOCX.img2FrontPtr; } set { dpOCX.img2FrontPtr = value; } }
		public int img2FrontSize { get { return dpOCX.img2FrontSize; } set { dpOCX.img2FrontSize = value; } }
		public int img2RearPtr { get { return dpOCX.img2RearPtr; } set { dpOCX.img2RearPtr = value; } }
		public int img2RearSize { get { return dpOCX.img2RearSize; } set { dpOCX.img2RearSize = value; } }
		public int imgDocId { get { return dpOCX.imgDocId; } set { dpOCX.imgDocId = value; } }
		public int imgFrontColorPtr { get { return dpOCX.imgFrontColorPtr; } set { dpOCX.imgFrontColorPtr = value; } }
		public int imgFrontColorSize { get { return dpOCX.imgFrontColorSize; } set { dpOCX.imgFrontColorSize = value; } }
		public int imgRearColorPtr { get { return dpOCX.imgRearColorPtr; } set { dpOCX.imgRearColorPtr = value; } }
		public int imgRearColorSize { get { return dpOCX.imgRearColorSize; } set { dpOCX.imgRearColorSize = value; } }
		public int imgSnippetDocId { get { return dpOCX.imgSnippetDocId; } set { dpOCX.imgSnippetDocId = value; } }
		public int imgSnippetPtr { get { return dpOCX.imgSnippetPtr; } set { dpOCX.imgSnippetPtr = value; } }
		public int imgSnippetSize { get { return dpOCX.imgSnippetSize; } set { dpOCX.imgSnippetSize = value; } }
		public string imgSnippetSkewArray { get { return dpOCX.imgSnippetSkewArray; } set { dpOCX.imgSnippetSkewArray = value; } }
		public int imgSorterId { get { return dpOCX.imgSorterId; } set { dpOCX.imgSorterId = value; } }
		public string iOperatorName { get { return dpOCX.iOperatorName; } set { dpOCX.iOperatorName = value; } }
		public int iOptions { get { return dpOCX.iOptions; } set { dpOCX.iOptions = value; } }
		public short iOutputXML { get { return dpOCX.iOutputXML; } set { dpOCX.iOutputXML = value; } }
		public string iRdrFontLoadPath { get { return dpOCX.iRdrFontLoadPath; } set { dpOCX.iRdrFontLoadPath = value; } }
		public string iStkSetLogicalPocketsPath { get { return dpOCX.iStkSetLogicalPocketsPath; } set { dpOCX.iStkSetLogicalPocketsPath = value; } }
		public string iWorkType { get { return dpOCX.iWorkType; } set { dpOCX.iWorkType = value; } }
		public int iXcpHandlerStyle { get { return dpOCX.iXcpHandlerStyle; } set { dpOCX.iXcpHandlerStyle = value; } }
		public string iXcpSecFdrIdentity { get { return dpOCX.iXcpSecFdrIdentity; } set { dpOCX.iXcpSecFdrIdentity = value; } }
		public int iXcpSecFdrOptions { get { return dpOCX.iXcpSecFdrOptions; } set { dpOCX.iXcpSecFdrOptions = value; } }
		public short ledState { get { return dpOCX.ledState; } set { dpOCX.ledState = value; } }
		public string mtrDataSA { get { return dpOCX.mtrDataSA; } set { dpOCX.mtrDataSA = value; } }
		public string mtrRcvPacket { get { return dpOCX.mtrRcvPacket; } set { dpOCX.mtrRcvPacket = value; } }
		public string mtrSendPacket { get { return dpOCX.mtrSendPacket; } set { dpOCX.mtrSendPacket = value; } }
		public int nextEndRearFontNumber { get { return dpOCX.nextEndRearFontNumber; } set { dpOCX.nextEndRearFontNumber = value; } }
		public string nextEndRearLine1 { get { return dpOCX.nextEndRearLine1; } set { dpOCX.nextEndRearLine1 = value; } }
		public string nextEndRearLine2 { get { return dpOCX.nextEndRearLine2; } set { dpOCX.nextEndRearLine2 = value; } }
		public string nextEndRearLine3 { get { return dpOCX.nextEndRearLine3; } set { dpOCX.nextEndRearLine3 = value; } }
		public string nextEndRearLine4 { get { return dpOCX.nextEndRearLine4; } set { dpOCX.nextEndRearLine4 = value; } }
		public int nextEndRearLogoNumber { get { return dpOCX.nextEndRearLogoNumber; } set { dpOCX.nextEndRearLogoNumber = value; } }
		public int nextEndRearLogoPosition { get { return dpOCX.nextEndRearLogoPosition; } set { dpOCX.nextEndRearLogoPosition = value; } }
		public int nextEndRearOptions { get { return dpOCX.nextEndRearOptions; } set { dpOCX.nextEndRearOptions = value; } }
		public int nextEndRearPosition { get { return dpOCX.nextEndRearPosition; } set { dpOCX.nextEndRearPosition = value; } }
		public int nvmReadBlockIndex { get { return dpOCX.nvmReadBlockIndex; } set { dpOCX.nvmReadBlockIndex = value; } }
		public int nvmReadEventBlockIndex { get { return dpOCX.nvmReadEventBlockIndex; } set { dpOCX.nvmReadEventBlockIndex = value; } }
		public string nvmReadEventDataSA { get { return dpOCX.nvmReadEventDataSA; } set { dpOCX.nvmReadEventDataSA = value; } }
		public int nvmWriteBlockIndex { get { return dpOCX.nvmWriteBlockIndex; } set { dpOCX.nvmWriteBlockIndex = value; } }
		public string nvmWriteDataSA { get { return dpOCX.nvmWriteDataSA; } set { dpOCX.nvmWriteDataSA = value; } }
		public string pAppDocData { get { return dpOCX.pAppDocData; } set { dpOCX.pAppDocData = value; } }
		public string pAppDocDataExtSA { get { return dpOCX.pAppDocDataExtSA; } set { dpOCX.pAppDocDataExtSA = value; } }
		public string pAppDocDataSA { get { return dpOCX.pAppDocDataSA; } set { dpOCX.pAppDocDataSA = value; } }
		public string pAppDocDataXML { get { return dpOCX.pAppDocDataXML; } set { dpOCX.pAppDocDataXML = value; } }
		public int pAppDocDIN { get { return dpOCX.pAppDocDIN; } set { dpOCX.pAppDocDIN = value; } }
		public string pEncData { get { return dpOCX.pEncData; } set { dpOCX.pEncData = value; } }
		public int pEncOptions { get { return dpOCX.pEncOptions; } set { dpOCX.pEncOptions = value; } }
		public short pEndFrontFontNumber { get { return dpOCX.pEndFrontFontNumber; } set { dpOCX.pEndFrontFontNumber = value; } }
		public string pEndFrontLine1 { get { return dpOCX.pEndFrontLine1; } set { dpOCX.pEndFrontLine1 = value; } }
		public string pEndFrontLine2 { get { return dpOCX.pEndFrontLine2; } set { dpOCX.pEndFrontLine2 = value; } }
		public string pEndFrontLine3 { get { return dpOCX.pEndFrontLine3; } set { dpOCX.pEndFrontLine3 = value; } }
		public string pEndFrontLine4 { get { return dpOCX.pEndFrontLine4; } set { dpOCX.pEndFrontLine4 = value; } }
		public short pEndFrontLogoNumber { get { return dpOCX.pEndFrontLogoNumber; } set { dpOCX.pEndFrontLogoNumber = value; } }
		public short pEndFrontLogoPosition { get { return dpOCX.pEndFrontLogoPosition; } set { dpOCX.pEndFrontLogoPosition = value; } }
		public int pEndFrontOptions { get { return dpOCX.pEndFrontOptions; } set { dpOCX.pEndFrontOptions = value; } }
		public short pEndFrontPosition { get { return dpOCX.pEndFrontPosition; } set { dpOCX.pEndFrontPosition = value; } }
		public short pEndRearFontNumber { get { return dpOCX.pEndRearFontNumber; } set { dpOCX.pEndRearFontNumber = value; } }
		public string pEndRearLine1 { get { return dpOCX.pEndRearLine1; } set { dpOCX.pEndRearLine1 = value; } }
		public string pEndRearLine2 { get { return dpOCX.pEndRearLine2; } set { dpOCX.pEndRearLine2 = value; } }
		public string pEndRearLine3 { get { return dpOCX.pEndRearLine3; } set { dpOCX.pEndRearLine3 = value; } }
		public string pEndRearLine4 { get { return dpOCX.pEndRearLine4; } set { dpOCX.pEndRearLine4 = value; } }
		public short pEndRearLogoNumber { get { return dpOCX.pEndRearLogoNumber; } set { dpOCX.pEndRearLogoNumber = value; } }
		public short pEndRearLogoPosition { get { return dpOCX.pEndRearLogoPosition; } set { dpOCX.pEndRearLogoPosition = value; } }
		public int pEndRearOptions { get { return dpOCX.pEndRearOptions; } set { dpOCX.pEndRearOptions = value; } }
		public short pEndRearPosition { get { return dpOCX.pEndRearPosition; } set { dpOCX.pEndRearPosition = value; } }
		public short pImgCarDocType { get { return dpOCX.pImgCarDocType; } set { dpOCX.pImgCarDocType = value; } }
		public string pImgFilename { get { return dpOCX.pImgFilename; } set { dpOCX.pImgFilename = value; } }
		public int pImgOptions { get { return dpOCX.pImgOptions; } set { dpOCX.pImgOptions = value; } }
		public int pMfilmOptions { get { return dpOCX.pMfilmOptions; } set { dpOCX.pMfilmOptions = value; } }
		public string pMfilmVerticalAnnotation { get { return dpOCX.pMfilmVerticalAnnotation; } set { dpOCX.pMfilmVerticalAnnotation = value; } }
		public int pSorterId { get { return dpOCX.pSorterId; } set { dpOCX.pSorterId = value; } }
		public short pStkPocket { get { return dpOCX.pStkPocket; } set { dpOCX.pStkPocket = value; } }
		public short pStkPocketCELate { get { return dpOCX.pStkPocketCELate; } set { dpOCX.pStkPocketCELate = value; } }
		public short pStkWaterfallCascade { get { return dpOCX.pStkWaterfallCascade; } set { dpOCX.pStkWaterfallCascade = value; } }
		public short pStmpFrontPosition { get { return dpOCX.pStmpFrontPosition; } set { dpOCX.pStmpFrontPosition = value; } }
		public int pStmpOptions { get { return dpOCX.pStmpOptions; } set { dpOCX.pStmpOptions = value; } }
		public short pStmpRearPosition { get { return dpOCX.pStmpRearPosition; } set { dpOCX.pStmpRearPosition = value; } }
		public int pupOptions { get { return dpOCX.pupOptions; } set { dpOCX.pupOptions = value; } }
		public bool pupRemapCharsAbove80Hex { get { return dpOCX.pupRemapCharsAbove80Hex; } set { dpOCX.pupRemapCharsAbove80Hex = value; } }
		public string pupTrkBaseConfigPath { get { return dpOCX.pupTrkBaseConfigPath; } set { dpOCX.pupTrkBaseConfigPath = value; } }
		public string pupTrkBaseWritePath { get { return dpOCX.pupTrkBaseWritePath; } set { dpOCX.pupTrkBaseWritePath = value; } }
		public bool pXcpDeleteAllowed { get { return dpOCX.pXcpDeleteAllowed; } set { dpOCX.pXcpDeleteAllowed = value; } }
		public string pXcpIdentify { get { return dpOCX.pXcpIdentify; } set { dpOCX.pXcpIdentify = value; } }
		public int pXcpOptions { get { return dpOCX.pXcpOptions; } set { dpOCX.pXcpOptions = value; } }
		public string rDoubleDocAdcs { get { return dpOCX.rDoubleDocAdcs; } set { dpOCX.rDoubleDocAdcs = value; } }
		public short recDocCount { get { return dpOCX.recDocCount; } set { dpOCX.recDocCount = value; } }
		public short recDocIndex { get { return dpOCX.recDocIndex; } set { dpOCX.recDocIndex = value; } }
		public int rEndRearSequenceNumber { get { return dpOCX.rEndRearSequenceNumber; } set { dpOCX.rEndRearSequenceNumber = value; } }
		public int repassAppDocDIN { get { return dpOCX.repassAppDocDIN; } set { dpOCX.repassAppDocDIN = value; } }
		public int repassControl { get { return dpOCX.repassControl; } set { dpOCX.repassControl = value; } }
		public string repassEncData { get { return dpOCX.repassEncData; } set { dpOCX.repassEncData = value; } }
		public int repassEncFlag { get { return dpOCX.repassEncFlag; } set { dpOCX.repassEncFlag = value; } }
		public short repassRdr1CantReadCount { get { return dpOCX.repassRdr1CantReadCount; } set { dpOCX.repassRdr1CantReadCount = value; } }
		public string repassRdr1CodeLine { get { return dpOCX.repassRdr1CodeLine; } set { dpOCX.repassRdr1CodeLine = value; } }
		public short repassRdr2CantReadCount { get { return dpOCX.repassRdr2CantReadCount; } set { dpOCX.repassRdr2CantReadCount = value; } }
		public string repassRdr2CodeLine { get { return dpOCX.repassRdr2CodeLine; } set { dpOCX.repassRdr2CodeLine = value; } }
		public short repassRdr3CantReadCount { get { return dpOCX.repassRdr3CantReadCount; } set { dpOCX.repassRdr3CantReadCount = value; } }
		public string repassRdr3CodeLine { get { return dpOCX.repassRdr3CodeLine; } set { dpOCX.repassRdr3CodeLine = value; } }
		public short repassRdrDocLength { get { return dpOCX.repassRdrDocLength; } set { dpOCX.repassRdrDocLength = value; } }
		public int repassRdrDocStatus { get { return dpOCX.repassRdrDocStatus; } set { dpOCX.repassRdrDocStatus = value; } }
		public int rPktSetsCantCascade1 { get { return dpOCX.rPktSetsCantCascade1; } set { dpOCX.rPktSetsCantCascade1 = value; } }
		public int rPktSetsCantCascade2 { get { return dpOCX.rPktSetsCantCascade2; } set { dpOCX.rPktSetsCantCascade2 = value; } }
		public int rPktSetsNearFull1 { get { return dpOCX.rPktSetsNearFull1; } set { dpOCX.rPktSetsNearFull1 = value; } }
		public int rPktSetsNearFull2 { get { return dpOCX.rPktSetsNearFull2; } set { dpOCX.rPktSetsNearFull2 = value; } }
		public short rRdr1CantReadCount { get { return dpOCX.rRdr1CantReadCount; } set { dpOCX.rRdr1CantReadCount = value; } }
		public string rRdr1CodeLine { get { return dpOCX.rRdr1CodeLine; } set { dpOCX.rRdr1CodeLine = value; } }
		public short rRdr2CantReadCount { get { return dpOCX.rRdr2CantReadCount; } set { dpOCX.rRdr2CantReadCount = value; } }
		public string rRdr2CodeLine { get { return dpOCX.rRdr2CodeLine; } set { dpOCX.rRdr2CodeLine = value; } }
		public short rRdr3CantReadCount { get { return dpOCX.rRdr3CantReadCount; } set { dpOCX.rRdr3CantReadCount = value; } }
		public string rRdr3CodeLine { get { return dpOCX.rRdr3CodeLine; } set { dpOCX.rRdr3CodeLine = value; } }
		public int rRdrDocId { get { return dpOCX.rRdrDocId; } set { dpOCX.rRdrDocId = value; } }
		public short rRdrDocLength { get { return dpOCX.rRdrDocLength; } set { dpOCX.rRdrDocLength = value; } }
		public int rRdrDocStatus { get { return dpOCX.rRdrDocStatus; } set { dpOCX.rRdrDocStatus = value; } }
		public short rRdrMICRAnalogCantReadCount { get { return dpOCX.rRdrMICRAnalogCantReadCount; } set { dpOCX.rRdrMICRAnalogCantReadCount = value; } }
		public short rRdrMICRDigitalCantReadCount { get { return dpOCX.rRdrMICRDigitalCantReadCount; } set { dpOCX.rRdrMICRDigitalCantReadCount = value; } }
		public int rSorterId { get { return dpOCX.rSorterId; } set { dpOCX.rSorterId = value; } }
		public string rTrkEntryStatus { get { return dpOCX.rTrkEntryStatus; } set { dpOCX.rTrkEntryStatus = value; } }
		public string soundWavFile { get { return dpOCX.soundWavFile; } set { dpOCX.soundWavFile = value; } }
		public short StartSorterType { get { return dpOCX.StartSorterType; } set { dpOCX.StartSorterType = value; } }
		public short StartState { get { return dpOCX.StartState; } set { dpOCX.StartState = value; } }
		public string StartVersion { get { return dpOCX.StartVersion; } set { dpOCX.StartVersion = value; } }
		public string tDspWriteLine1 { get { return dpOCX.tDspWriteLine1; } set { dpOCX.tDspWriteLine1 = value; } }
		public string tDspWriteLine2 { get { return dpOCX.tDspWriteLine2; } set { dpOCX.tDspWriteLine2 = value; } }
		public int tGoIdleMode { get { return dpOCX.tGoIdleMode; } set { dpOCX.tGoIdleMode = value; } }
		public string tImgEOFAnnotation { get { return dpOCX.tImgEOFAnnotation; } set { dpOCX.tImgEOFAnnotation = value; } }
		public int tImgEOFMode { get { return dpOCX.tImgEOFMode; } set { dpOCX.tImgEOFMode = value; } }
		public string tImgEOFName { get { return dpOCX.tImgEOFName; } set { dpOCX.tImgEOFName = value; } }
		public int tMFilmDP1X00ReelNumber { get { return dpOCX.tMFilmDP1X00ReelNumber; } set { dpOCX.tMFilmDP1X00ReelNumber = value; } }
		public string tMfilmHorizontalAnnotate { get { return dpOCX.tMfilmHorizontalAnnotate; } set { dpOCX.tMfilmHorizontalAnnotate = value; } }
		public short tMfilmLength { get { return dpOCX.tMfilmLength; } set { dpOCX.tMfilmLength = value; } }
		public short TMfilmLengthDP1X00Spool { get { return dpOCX.TMfilmLengthDP1X00Spool; } set { dpOCX.TMfilmLengthDP1X00Spool = value; } }
		public int tMfilmOptions { get { return dpOCX.tMfilmOptions; } set { dpOCX.tMfilmOptions = value; } }
		public short tMfilmSlewLength { get { return dpOCX.tMfilmSlewLength; } set { dpOCX.tMfilmSlewLength = value; } }
		public string tMfilmVerticalAnnotation { get { return dpOCX.tMfilmVerticalAnnotation; } set { dpOCX.tMfilmVerticalAnnotation = value; } }
		public string tSerialNumber0 { get { return dpOCX.tSerialNumber0; } set { dpOCX.tSerialNumber0 = value; } }
		public int tSorterId { get { return dpOCX.tSorterId; } set { dpOCX.tSorterId = value; } }
		public int tTrackState { get { return dpOCX.tTrackState; } set { dpOCX.tTrackState = value; } }
		public int tTrackStatus { get { return dpOCX.tTrackStatus; } set { dpOCX.tTrackStatus = value; } }
		public bool ucEventInProgress { get { return dpOCX.ucEventInProgress; } set { dpOCX.ucEventInProgress = value; } }
		public bool ucUnreliableContainer { get { return dpOCX.ucUnreliableContainer; } set { dpOCX.ucUnreliableContainer = value; } }
		public short wAlert { get { return dpOCX.wAlert; } set { dpOCX.wAlert = value; } }
		public string wAlertEnglishText { get { return dpOCX.wAlertEnglishText; } set { dpOCX.wAlertEnglishText = value; } }
		public short wAlertPktsFull { get { return dpOCX.wAlertPktsFull; } set { dpOCX.wAlertPktsFull = value; } }
		public string zCheetah { get { return dpOCX.zCheetah; } set { dpOCX.zCheetah = value; } }

		#endregion

		public Scanner()
		{
			dpOCX = new DpocxLib.Dpocx();
			dpOCX.BlackBandEvent += new DpocxLib._DDpocxEvents_BlackBandEventEventHandler(dpOCX_BlackBandEvent);
			dpOCX.CLICaptured += new DpocxLib._DDpocxEvents_CLICapturedEventHandler(dpOCX_CLICaptured);
			dpOCX.Connected += new DpocxLib._DDpocxEvents_ConnectedEventHandler(dpOCX_Connected);
			dpOCX.Disconnected += new DpocxLib._DDpocxEvents_DisconnectedEventHandler(dpOCX_Disconnected);
			dpOCX.DocComplete += new DpocxLib._DDpocxEvents_DocCompleteEventHandler(dpOCX_DocComplete);
			dpOCX.DocImageComplete += new DpocxLib._DDpocxEvents_DocImageCompleteEventHandler(dpOCX_DocImageComplete);
			dpOCX.DocImageSnippetComplete += new DpocxLib._DDpocxEvents_DocImageSnippetCompleteEventHandler(dpOCX_DocImageSnippetComplete);
			dpOCX.DocReadComplete += new DpocxLib._DDpocxEvents_DocReadCompleteEventHandler(dpOCX_DocReadComplete);
			dpOCX.DocRejected += new DpocxLib._DDpocxEvents_DocRejectedEventHandler(dpOCX_DocRejected);
			dpOCX.ExceptionComplete += new DpocxLib._DDpocxEvents_ExceptionCompleteEventHandler(dpOCX_ExceptionComplete);
			dpOCX.ExceptionInProgress += new DpocxLib._DDpocxEvents_ExceptionInProgressEventHandler(dpOCX_ExceptionInProgress);
			dpOCX.FlowStopped += new DpocxLib._DDpocxEvents_FlowStoppedEventHandler(dpOCX_FlowStopped);
			dpOCX.HopperEmpty += new DpocxLib._DDpocxEvents_HopperEmptyEventHandler(dpOCX_HopperEmpty);
			dpOCX.Idle += new DpocxLib._DDpocxEvents_IdleEventHandler(dpOCX_Idle);
			dpOCX.MachineDead += new DpocxLib._DDpocxEvents_MachineDeadEventHandler(dpOCX_MachineDead);
			dpOCX.MakeReadyToFlowComplete += new DpocxLib._DDpocxEvents_MakeReadyToFlowCompleteEventHandler(dpOCX_MakeReadyToFlowComplete);
			dpOCX.MFilmGetFilmLengthComplete += new DpocxLib._DDpocxEvents_MFilmGetFilmLengthCompleteEventHandler(dpOCX_MFilmGetFilmLengthComplete);
			dpOCX.MFilmSkip += new DpocxLib._DDpocxEvents_MFilmSkipEventHandler(dpOCX_MFilmSkip);
			dpOCX.MFilmSlewComplete += new DpocxLib._DDpocxEvents_MFilmSlewCompleteEventHandler(dpOCX_MFilmSlewComplete);
			dpOCX.MTREntered += new DpocxLib._DDpocxEvents_MTREnteredEventHandler(dpOCX_MTREntered);
			dpOCX.MTRExited += new DpocxLib._DDpocxEvents_MTRExitedEventHandler(dpOCX_MTRExited);
			dpOCX.MTRResponse += new DpocxLib._DDpocxEvents_MTRResponseEventHandler(dpOCX_MTRResponse);
			dpOCX.MTRResponseBinary += new DpocxLib._DDpocxEvents_MTRResponseBinaryEventHandler(dpOCX_MTRResponseBinary);
			dpOCX.NVMReadComplete += new DpocxLib._DDpocxEvents_NVMReadCompleteEventHandler(dpOCX_NVMReadComplete);
			dpOCX.PocketChange += new DpocxLib._DDpocxEvents_PocketChangeEventHandler(dpOCX_PocketChange);
			dpOCX.PoweredDown += new DpocxLib._DDpocxEvents_PoweredDownEventHandler(dpOCX_PoweredDown);
			dpOCX.PoweredUp += new DpocxLib._DDpocxEvents_PoweredUpEventHandler(dpOCX_PoweredUp);
			dpOCX.PoweringUp += new DpocxLib._DDpocxEvents_PoweringUpEventHandler(dpOCX_PoweringUp);
			dpOCX.Readying += new DpocxLib._DDpocxEvents_ReadyingEventHandler(dpOCX_Readying);
			dpOCX.ReadyToProcess += new DpocxLib._DDpocxEvents_ReadyToProcessEventHandler(dpOCX_ReadyToProcess);
			dpOCX.RecoveryComplete += new DpocxLib._DDpocxEvents_RecoveryCompleteEventHandler(dpOCX_RecoveryComplete);
			dpOCX.RepassVerify += new DpocxLib._DDpocxEvents_RepassVerifyEventHandler(dpOCX_RepassVerify);
			dpOCX.StackerButtonPressed += new DpocxLib._DDpocxEvents_StackerButtonPressedEventHandler(dpOCX_StackerButtonPressed);
			dpOCX.StateException += new DpocxLib._DDpocxEvents_StateExceptionEventHandler(dpOCX_StateException);
			dpOCX.Warning += new DpocxLib._DDpocxEvents_WarningEventHandler(dpOCX_Warning);
			convertion = new ImageConvertion();
		}


		void dpOCX_Warning()
		{
			if (OnWarning != null)
			{
				OnWarning = "wAlert:" + wAlert.ToString() + ";";
			}
		}

		void dpOCX_StateException(ref string sState, ref string sMethod, ref string sMessage)
		{
			if (OnStateException != null)
			{
				OnStateException
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnStateException,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_StackerButtonPressed()
		{
			if (OnStackerButtonPressed != null)
			{
				OnStackerButtonPressed
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnStackerButtonPressed,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_RepassVerify()
		{
			if (OnRepassVerify != null)
			{
				OnRepassVerify
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnRepassVerify,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_RecoveryComplete()
		{
			if (OnRecoveryComplete != null)
			{
				OnRecoveryComplete
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnRecoveryComplete,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_Readying()
		{
			if (OnReadying != null)
			{
				OnReadying = 1;
			}
		}

		void dpOCX_ReadyToProcess()
		{
			if (OnReadyToProcess != null)
			{
				OnReadyToProcess = 1;
				OnIdle = 0;
			}
		}

		void dpOCX_PoweringUp()
		{
			if (OnPoweringUp != null)
			{
				OnPoweringUp = 1;
			}
		}

		void dpOCX_PoweredUp()
		{
			if (OnPoweredUp != null)
			{
				OnPoweredUp = 1;
				OnPoweredDown = 0;
			}
		}

		void dpOCX_PoweredDown()
		{
			if (OnPoweredDown != null)
			{
				OnPoweredDown = 1;
				OnPoweredUp = 0;
				OnConnected = 0;
				OnDisconnected = 0;
			}
		}

		void dpOCX_PocketChange(ref string LogicalToPhysicalPocket)
		{
			if (OnPocketChange != null)
			{
				OnPocketChange
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnPocketChange,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_NVMReadComplete()
		{
			if (OnNVMReadComplete != null)
			{
				OnNVMReadComplete
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnNVMReadComplete,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MTRResponseBinary()
		{
			if (OnMTRResponseBinary != null)
			{
				OnMTRResponseBinary
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnMTRResponseBinary,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MTRResponse()
		{
			if (OnMTRResponse != null)
			{
				OnMTRResponse
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnMTRResponse,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MTRExited()
		{
			if (OnMTRExited != null)
			{
				OnMTRExited
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnMTRExited,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MTREntered()
		{
			if (OnMTREntered != null)
			{
				OnMTREntered
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnMTREntered,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MFilmSlewComplete()
		{
			if (OnMFilmSlewComplete != null)
			{
				OnMFilmSlewComplete
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnMFilmSlewComplete,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MFilmSkip()
		{
			if (OnMFilmSkip != null)
			{
				OnMFilmSkip
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnMFilmSkip,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MFilmGetFilmLengthComplete()
		{
			if (OnMFilmGetFilmLengthComplete != null)
			{
				OnMFilmGetFilmLengthComplete
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnMFilmGetFilmLengthComplete,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MakeReadyToFlowComplete()
		{
			if (OnMakeReadyToFlowComplete != null)
			{
				OnMakeReadyToFlowComplete
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnMakeReadyToFlowComplete,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_MachineDead()
		{
			if (OnMachineDead != null)
			{
				OnMachineDead = 1;
			}
		}

		void dpOCX_Idle()
		{
			if (OnIdle != null)
			{
				OnIdle = 1;
				OnReadyToProcess = 0;
			}
		}

		void dpOCX_HopperEmpty()
		{
			if (OnHopperEmpty != null)
			{
				OnHopperEmpty = 1;
			}
		}

		void dpOCX_FlowStopped()
		{
			if (OnFlowStopped != null)
			{
				OnFlowStopped = 1;
			}
		}

		void dpOCX_DocRejected()
		{
			if (OnDocRejected != null)
			{
				OnDocRejected
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnDocRejected,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_DocReadComplete()
		{
			CONCAT_CODE_LINE_FROM_SCANNER = "";
			if (OnDocReadComplete != null)
			{
				FLAG_TO_GET_ALL_IMAGES = 0;
				string pattern = @"[^0-9]";
				string idDoc = "{idDoc>" + rRdrDocId.ToString() + ",";
				string dr1CodeLine = "dr1>" + Regex.Replace(rRdr1CodeLine.Trim(), pattern, "+") + "," + "err1>" + rRdr1CantReadCount.ToString() + ",";
				string dr2CodeLine = "dr2>" + rRdr2CodeLine.Trim() + "," + "err2>" + rRdr2CantReadCount.ToString() + ",";
				string dr3CodeLine = "dr3>" + rRdr3CodeLine.Trim() + "," + "err3>" + rRdr3CantReadCount.ToString() + "};";
				CONCAT_CODE_LINE_FROM_SCANNER = OnDocReadComplete.ToString() + string.Concat(idDoc, dr1CodeLine, dr2CodeLine, dr3CodeLine);
				OnDocReadComplete = CONCAT_CODE_LINE_FROM_SCANNER;
				DocAccept();
				DocProcess();
			}
		}

		void dpOCX_DocImageSnippetComplete()
		{
			if (OnDocReadComplete != null)
			{
				OnDocReadComplete
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnDocReadComplete,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_DocImageComplete()
		{
			CONCAT_IMAGES_FROM_SCANNER = "";
			if (OnDocImageComplete != null && FLAG_TO_GET_ALL_IMAGES != 0)
			{
				string idDoc = "{idDoc>" + imgDocId.ToString() + ",";
				string imgFront = "imgF>" + GetImage(img2FrontPtr, img2FrontSize) + ",";
				string imgRear = "imgR>" + GetImage(img2RearPtr, img2RearSize) + "};";
				CONCAT_IMAGES_FROM_SCANNER = OnDocImageComplete.ToString() + string.Concat(idDoc, imgFront, imgRear);
				OnDocImageComplete = CONCAT_IMAGES_FROM_SCANNER;
			}
			FLAG_TO_GET_ALL_IMAGES = 1;
		}

		void dpOCX_DocComplete()
		{
			if (OnDocComplete != null)
			{
				OnDocComplete
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnDocComplete,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_Disconnected()
		{
			if (OnDisconnected != null)
			{
				OnDisconnected = 1;
				OnConnected = 0;
			}
		}

		void dpOCX_Connected()
		{
			if (OnConnected != null)
			{
				OnConnected = 1;
				OnDisconnected = 0;
			}
		}

		void dpOCX_CLICaptured()
		{
			if (OnCLICaptured != null)
			{
				OnCLICaptured
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnCLICaptured,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_BlackBandEvent()
		{
			if (OnBlackBandEvent != null)
			{
				OnBlackBandEvent
				.GetType()
				.InvokeMember
				("",
				BindingFlags.InvokeMethod,
				null,
				OnBlackBandEvent,
				new object[] { dpOCX.tTrackState });
			}
		}

		void dpOCX_ExceptionComplete()
		{
			if (OnExceptionComplete != null)
			{
				OnExceptionComplete = 1;
			}
		}

		void dpOCX_ExceptionInProgress()
		{
			if (OnExceptionInProgress != null)
			{
				if (epExceptionType == 5 && tTrackState == STATE_EXCEPTION && tSerialNumber0.Equals(""))
				{
					OnExceptionInProgress = NO_DEVICE_CONNECTED;
				}
				else
				{
					OnExceptionInProgress = epExceptionCode;

				}
			}
		}



		public string GetImage(int addr, int length)
		{
			string base64String;
			unsafe
			{
				byte* p = (byte*)addr;
				byte[] managedArray = new byte[length];
				int i = 0;
				while (i < length)
				{
					managedArray[i] = *p;
					p++;
					i++;
				}
				base64String = System.Convert.ToBase64String(managedArray, Base64FormattingOptions.None);
			}
			return (base64String);
		}


		public void AboutBox()
		{
			dpOCX.AboutBox();
		}

		public void ClearTrack()
		{
			dpOCX.ClearTrack();
		}

		public void CLICapture(ref string CLIPath1, ref string CLIPath2)
		{
			dpOCX.CLICapture(CLIPath1, CLIPath2);
		}

		public void DisplayLine()
		{
			dpOCX.DisplayLine();
		}

		public void DocAccept()
		{
			dpOCX.DocAccept();
		}

		public void DocChangeEncode()
		{
			dpOCX.DocChangeEncode();
		}

		public void DocChangePocket()
		{
			dpOCX.DocChangePocket();
		}

		public void DocProcess()
		{
			dpOCX.DocProcess();
		}

		public void DocReject()
		{
			dpOCX.DocReject();
		}

		public void ExceptStart()
		{
			dpOCX.ExceptStart();
		}

		public void FlowStart(short FlowMode)
		{
			dpOCX.FlowStart(FlowMode);
		}

		public void FlowStop()
		{
			dpOCX.FlowStop();
		}

		public void GoIdle()
		{
			dpOCX.GoIdle();
		}

		public void GoReadyToProcess()
		{
			dpOCX.GoReadyToProcess();
		}

		public void ImageEndOfFile()
		{
			dpOCX.ImageEndOfFile();
		}

		public void MakeReadyToFlow()
		{
			dpOCX.MakeReadyToFlow();
		}

		public void MakeReadyToFlowTerminate()
		{
			dpOCX.MakeReadyToFlowTerminate();
		}

		public void MergeFeed(short MergeCount)
		{
			dpOCX.MergeFeed(MergeCount);
		}

		public void MFilmGetLength()
		{
			dpOCX.MFilmGetLength();
		}

		public void MFilmHorizontalAnnotate()
		{
			dpOCX.MFilmHorizontalAnnotate();
		}

		public void MFilmSlew()
		{
			dpOCX.MFilmSlew();
		}

		public void MFilmVerticalAnnotate()
		{
			dpOCX.MFilmVerticalAnnotate();
		}

		public void MTRCommand()
		{
			dpOCX.MTRCommand();
		}

		public void MTRCommandBinary(object mtrPacket)
		{
			dpOCX.MTRCommandBinary(mtrPacket);
		}

		public void MTREnter()
		{
			dpOCX.MTREnter();
		}

		public void MTRExit()
		{
			dpOCX.MTRExit();
		}

		public void PlaySound()
		{
			dpOCX.PlaySound();
		}

		public void PowerDown()
		{
			dpOCX.PowerDown();
		}

		public void PowerUp()
		{
			dpOCX.PowerUp();
		}

		public void PrintLine(ref string PrintLineData)
		{
			dpOCX.PrintLine(PrintLineData);
		}

		public void ReadNVM(int NVMOffset)
		{
			dpOCX.ReadNVM(NVMOffset);
		}

		public void ReadNVMBlock()
		{
			dpOCX.ReadNVMBlock();
		}

		public void ReadStart()
		{
			dpOCX.ReadStart();
		}

		public void Recover()
		{
			dpOCX.Recover();
		}

		public void ResumeFeeding()
		{
			dpOCX.ResumeFeeding();
		}

		public void SetLED()
		{
			dpOCX.SetLED();
		}

		public void StkResetPockets(short LogicalPocketNumber)
		{
			dpOCX.StkResetPockets(LogicalPocketNumber);
		}

		public void WriteNVM(int NVMOffset, int NVMData)
		{
			dpOCX.WriteNVM(NVMOffset, NVMData);
		}

		public void WriteNVMBlock()
		{
			dpOCX.WriteNVMBlock();
		}

		public void Close()
		{
			dpOCX = null;
		}

        public string ConvertImageTiffToBase64Jpg(string base64)
        {
			return convertion.covertTiffToBase64Jpg(base64);
		}

        public void ConfigurationOfFolderImage()
        {
            string pathProject = AddressProject.ToString();
			convertion.configurationOfFolderImage(pathProject);
        }
    }
}
