﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace ScannerControl
{
    [ComVisible(true)]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("41E85D5D-C57A-4386-B722-4031D0B1E1B7")]

    interface IScannerControl
    {
		int MODE_AUTO_FEED { get; }
		int MODE_SINGLE_FEED { get; }
		int MODE_AUTO_FEED_WAIT_THREAD { get; }
		int MODE_SINGLE_FEED_WAIT_THREAD { get; }
		int MODE_AUTO_ID { get; }
		int MODE_SINGLE_ID { get; }
		int MODE_AUTO_ID_WAIT_THREAD { get; }
		int MODE_SINGLE_ID_WAIT_THREAD { get; }
		int FLAG_TO_GET_ALL_IMAGES { get; set; }
		string CONCAT_IMAGES_FROM_SCANNER { get; set; }
		string CONCAT_CODE_LINE_FROM_SCANNER { get; set; }
		string NO_DEVICE_CONNECTED { get; }
		int STATE_EXCEPTION { get; }

		int CAPI_Version { get; set; }
		string cAppDocData { get; set; }
		string cAppDocDataExtSA { get; set; }
		string cAppDocDataSA { get; set; }
		int cAppDocDIN { get; set; }
		int cDocCompleteDevInfo { get; set; }
		short cDocCompleteStatus { get; set; }
		int ceDocId { get; set; }
		string ceEncData { get; set; }
		int cEndRearSequenceNumber { get; set; }
		int cfgDevicesFitted { get; set; }
		short cfgNumPockets { get; set; }
		int cfgNVMBase { get; set; }
		int cfgNVMLength { get; set; }
		int cpDocId { get; set; }
		short cpStkPocket { get; set; }
		int cSorterId { get; set; }
		short cStkPocket { get; set; }
		bool ecManualDropSwitch { get; set; }
		int ecSorterId { get; set; }
		string epExceptionCode { get; set; }
		int epExceptionDevice { get; set; }
		int epExceptionType { get; set; }
		int epSorterId { get; set; }
		int eSorterId { get; set; }
		short iEncPosition { get; set; }
		string iEndFontSetup { get; set; }
		int iEndorserLines { get; set; }
		int iEndRearSequenceNumberIncrement { get; set; }
		int iEndRearSequenceNumberStart { get; set; }
		bool iEntryIgnoreDogEarError { get; set; }
		bool iEntryStopOnBlackBand { get; set; }
		int iHSEMOptions { get; set; }
		bool iHSEMOutSort { get; set; }
		string iImageStoragePath { get; set; }
		string iImgAnnotate { get; set; }
		string iImgAnnotateExtSA { get; set; }
		string iImgAnnotateSA { get; set; }
		string iImgCarSetupFilePath { get; set; }
		string iImgImageDirectory { get; set; }
		int iMandatoryDevices { get; set; }
		short iMfilmLampIntensity { get; set; }
		int img1FrontPtr { get; set; }
		int img1FrontSize { get; set; }
		int img1RearPtr { get; set; }
		int img1RearSize { get; set; }
		int img2FrontPtr { get; set; }
		int img2FrontSize { get; set; }
		int img2RearPtr { get; set; }
		int img2RearSize { get; set; }
		int imgDocId { get; set; }
		int imgFrontColorPtr { get; set; }
		int imgFrontColorSize { get; set; }
		int imgRearColorPtr { get; set; }
		int imgRearColorSize { get; set; }
		int imgSnippetDocId { get; set; }
		int imgSnippetPtr { get; set; }
		int imgSnippetSize { get; set; }
		string imgSnippetSkewArray { get; set; }
		int imgSorterId { get; set; }
		string iOperatorName { get; set; }
		int iOptions { get; set; }
		short iOutputXML { get; set; }
		string iRdrFontLoadPath { get; set; }
		string iStkSetLogicalPocketsPath { get; set; }
		string iWorkType { get; set; }
		int iXcpHandlerStyle { get; set; }
		string iXcpSecFdrIdentity { get; set; }
		int iXcpSecFdrOptions { get; set; }
		short ledState { get; set; }
		string mtrDataSA { get; set; }
		string mtrRcvPacket { get; set; }
		string mtrSendPacket { get; set; }
		int nextEndRearFontNumber { get; set; }
		string nextEndRearLine1 { get; set; }
		string nextEndRearLine2 { get; set; }
		string nextEndRearLine3 { get; set; }
		string nextEndRearLine4 { get; set; }
		int nextEndRearLogoNumber { get; set; }
		int nextEndRearLogoPosition { get; set; }
		int nextEndRearOptions { get; set; }
		int nextEndRearPosition { get; set; }
		int nvmReadBlockIndex { get; set; }
		int nvmReadEventBlockIndex { get; set; }
		string nvmReadEventDataSA { get; set; }
		int nvmWriteBlockIndex { get; set; }
		string nvmWriteDataSA { get; set; }
		string pAppDocData { get; set; }
		string pAppDocDataExtSA { get; set; }
		string pAppDocDataSA { get; set; }
		string pAppDocDataXML { get; set; }
		int pAppDocDIN { get; set; }
		string pEncData { get; set; }
		int pEncOptions { get; set; }
		short pEndFrontFontNumber { get; set; }
		string pEndFrontLine1 { get; set; }
		string pEndFrontLine2 { get; set; }
		string pEndFrontLine3 { get; set; }
		string pEndFrontLine4 { get; set; }
		short pEndFrontLogoNumber { get; set; }
		short pEndFrontLogoPosition { get; set; }
		int pEndFrontOptions { get; set; }
		short pEndFrontPosition { get; set; }
		short pEndRearFontNumber { get; set; }
		string pEndRearLine1 { get; set; }
		string pEndRearLine2 { get; set; }
		string pEndRearLine3 { get; set; }
		string pEndRearLine4 { get; set; }
		short pEndRearLogoNumber { get; set; }
		short pEndRearLogoPosition { get; set; }
		int pEndRearOptions { get; set; }
		short pEndRearPosition { get; set; }
		short pImgCarDocType { get; set; }
		string pImgFilename { get; set; }
		int pImgOptions { get; set; }
		int pMfilmOptions { get; set; }
		string pMfilmVerticalAnnotation { get; set; }
		int pSorterId { get; set; }
		short pStkPocket { get; set; }
		short pStkPocketCELate { get; set; }
		short pStkWaterfallCascade { get; set; }
		short pStmpFrontPosition { get; set; }
		int pStmpOptions { get; set; }
		short pStmpRearPosition { get; set; }
		int pupOptions { get; set; }
		bool pupRemapCharsAbove80Hex { get; set; }
		string pupTrkBaseConfigPath { get; set; }
		string pupTrkBaseWritePath { get; set; }
		bool pXcpDeleteAllowed { get; set; }
		string pXcpIdentify { get; set; }
		int pXcpOptions { get; set; }
		string rDoubleDocAdcs { get; set; }
		short recDocCount { get; set; }
		short recDocIndex { get; set; }
		int rEndRearSequenceNumber { get; set; }
		int repassAppDocDIN { get; set; }
		int repassControl { get; set; }
		string repassEncData { get; set; }
		int repassEncFlag { get; set; }
		short repassRdr1CantReadCount { get; set; }
		string repassRdr1CodeLine { get; set; }
		short repassRdr2CantReadCount { get; set; }
		string repassRdr2CodeLine { get; set; }
		short repassRdr3CantReadCount { get; set; }
		string repassRdr3CodeLine { get; set; }
		short repassRdrDocLength { get; set; }
		int repassRdrDocStatus { get; set; }
		int rPktSetsCantCascade1 { get; set; }
		int rPktSetsCantCascade2 { get; set; }
		int rPktSetsNearFull1 { get; set; }
		int rPktSetsNearFull2 { get; set; }
		short rRdr1CantReadCount { get; set; }
		string rRdr1CodeLine { get; set; }
		short rRdr2CantReadCount { get; set; }
		string rRdr2CodeLine { get; set; }
		short rRdr3CantReadCount { get; set; }
		string rRdr3CodeLine { get; set; }
		int rRdrDocId { get; set; }
		short rRdrDocLength { get; set; }
		int rRdrDocStatus { get; set; }
		short rRdrMICRAnalogCantReadCount { get; set; }
		short rRdrMICRDigitalCantReadCount { get; set; }
		int rSorterId { get; set; }
		string rTrkEntryStatus { get; set; }
		string soundWavFile { get; set; }
		short StartSorterType { get; set; }
		short StartState { get; set; }
		string StartVersion { get; set; }
		string tDspWriteLine1 { get; set; }
		string tDspWriteLine2 { get; set; }
		int tGoIdleMode { get; set; }
		string tImgEOFAnnotation { get; set; }
		int tImgEOFMode { get; set; }
		string tImgEOFName { get; set; }
		int tMFilmDP1X00ReelNumber { get; set; }
		string tMfilmHorizontalAnnotate { get; set; }
		short tMfilmLength { get; set; }
		short TMfilmLengthDP1X00Spool { get; set; }
		int tMfilmOptions { get; set; }
		short tMfilmSlewLength { get; set; }
		string tMfilmVerticalAnnotation { get; set; }
		string tSerialNumber0 { get; set; }
		int tSorterId { get; set; }
		int tTrackState { get; set; }
		int tTrackStatus { get; set; }
		bool ucEventInProgress { get; set; }
		bool ucUnreliableContainer { get; set; }
		short wAlert { get; set; }
		string wAlertEnglishText { get; set; }
		short wAlertPktsFull { get; set; }
		string zCheetah { get; set; }

		void Close();
		string GetImage(int addr, int length);
		void AboutBox();
		void ClearTrack();
		void CLICapture(ref string CLIPath1, ref string CLIPath2);
		void DisplayLine();
		void DocAccept();
		void DocChangeEncode();
		void DocChangePocket();
		void DocProcess();
		void DocReject();
		void ExceptStart();
		void FlowStart(short FlowMode);
		void FlowStop();
		void GoIdle();
		void GoReadyToProcess();
		void ImageEndOfFile();
		void MakeReadyToFlow();
		void MakeReadyToFlowTerminate();
		void MergeFeed(short MergeCount);
		void MFilmGetLength();
		void MFilmHorizontalAnnotate();
		void MFilmSlew();
		void MFilmVerticalAnnotate();
		void MTRCommand();
		void MTRCommandBinary(object mtrPacket);
		void MTREnter();
		void MTRExit();
		void PlaySound();
		void PowerDown();
		void PowerUp();
		void PrintLine(ref string PrintLineData);
		void ReadNVM(int NVMOffset);
		void ReadNVMBlock();
		void ReadStart();
		void Recover();
		void ResumeFeeding();
		void SetLED();
		void StkResetPockets(short LogicalPocketNumber);
		void WriteNVM(int NVMOffset, int NVMData);
		void WriteNVMBlock();
		string ConvertImageTiffToBase64Jpg(string base64);
		void ConfigurationOfFolderImage();

		Object OnClose { get; set; }
		Object OnBlackBandEvent { get; set; }
		Object OnCLICaptured { get; set; }
		Object OnConnected { get; set; }
		Object OnDisconnected { get; set; }
		Object OnDocComplete { get; set; }
		Object OnDocImageComplete { get; set; }
		Object OnDocImageSnippetComplete { get; set; }
		Object OnDocReadComplete { get; set; }
		Object OnDocRejected { get; set; }
		Object OnExceptionComplete { get; set; }
		Object OnExceptionInProgress { get; set; }
		Object OnFlowStopped { get; set; }
		Object OnHopperEmpty { get; set; }
		Object OnIdle { get; set; }
		Object OnMachineDead { get; set; }
		Object OnMakeReadyToFlowComplete { get; set; }
		Object OnMFilmGetFilmLengthComplete { get; set; }
		Object OnMFilmSkip { get; set; }
		Object OnMFilmSlewComplete { get; set; }
		Object OnMTREntered { get; set; }
		Object OnMTRExited { get; set; }
		Object OnMTRResponse { get; set; }
		Object OnMTRResponseBinary { get; set; }
		Object OnNVMReadComplete { get; set; }
		Object OnPocketChange { get; set; }
		Object OnPoweredDown { get; set; }
		Object OnPoweredUp { get; set; }
		Object OnPoweringUp { get; set; }
		Object OnReadying { get; set; }
		Object OnReadyToProcess { get; set; }
		Object OnRecoveryComplete { get; set; }
		Object OnRepassVerify { get; set; }
		Object OnStackerButtonPressed { get; set; }
		Object OnStateException { get; set; }
		Object OnWarning { get; set; }
		Object AddressProject { get; set; }
	}
}
