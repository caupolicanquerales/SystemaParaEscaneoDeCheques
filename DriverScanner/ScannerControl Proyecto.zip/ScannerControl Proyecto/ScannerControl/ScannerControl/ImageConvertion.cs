﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spire.Pdf;
using System.Drawing;
using System.Drawing.Imaging;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace ScannerControl
{
    class ImageConvertion
    {
        string IMAGE = "image.jpeg";
        string IMAGE_FOLDER = "images";
        string PDF_IMAGE = "pdfImage.pdf";
        string folderPath = "";
        string imagePath = "";
        string pdfPath = "";
        public ImageConvertion()
        {
        }
        public void configurationOfFolderImage(string projectPath)
        {
            folderPath = System.IO.Path.Combine(projectPath, IMAGE_FOLDER);
            imagePath = System.IO.Path.Combine(folderPath, IMAGE);
            pdfPath = System.IO.Path.Combine(folderPath, PDF_IMAGE);
            System.IO.Directory.CreateDirectory(folderPath);
        }
        public string covertTiffToBase64Jpg(string base64)
        {
            convertBase64ToImage(imagePath, base64);
            convertTiffToPdf(imagePath, pdfPath);
            return convertPdfToImage(pdfPath);
        }

        private void convertBase64ToImage(string imagePath, string base64)
        {
            byte[] bytes = Convert.FromBase64String(base64);
            File.WriteAllBytes(imagePath, bytes);
        }

        private void convertTiffToPdf(string imagePath, string pdfPath)
        {
            System.Drawing.Image image = System.Drawing.Image.FromFile(imagePath);
            iTextSharp.text.Document document = new iTextSharp.text.Document();
            var pgSize = new iTextSharp.text.Rectangle(image.Width, image.Height);
            document.SetPageSize(pgSize);
            Bitmap bitmap = new Bitmap(imagePath);
            PdfWriter writer = PdfWriter.GetInstance(document, new System.IO.FileStream(pdfPath, System.IO.FileMode.Create));
            int totalPages = bitmap.GetFrameCount(System.Drawing.Imaging.FrameDimension.Page);
            document.Open();
            PdfContentByte cb = writer.DirectContent;
            for (int pageNumber = 0; pageNumber < totalPages; ++pageNumber)
            {
                bitmap.SelectActiveFrame(System.Drawing.Imaging.FrameDimension.Page, pageNumber);
                iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(bitmap, ImageFormat.Tiff);
                img.ScalePercent(img.DpiX, img.DpiY);
                img.SetAbsolutePosition(0, 0);
                cb.AddImage(img);
                document.NewPage();
            }
            document.Close();
        }

        private string convertPdfToImage(string pdfPath)
        {
            string base64String = "";
            Spire.Pdf.PdfDocument pdfdocument = new Spire.Pdf.PdfDocument(pdfPath);
            for (int i = 0; i < pdfdocument.Pages.Count; i++)
            {
                System.Drawing.Image image = pdfdocument.SaveAsImage(i, 100, 100);
                using (MemoryStream ms = new MemoryStream())
                {
                    image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    byte[] byteArray = ms.ToArray();
                    base64String = Convert.ToBase64String(byteArray);
                }
            }
            return base64String;
        }

    }
}
