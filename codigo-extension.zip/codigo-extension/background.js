
var hostName = "conexion.programa.autoejecutable";
var hostServer="conexion.programa.serversocket";
var port= null;
var portServer=null;
var mensaje=null;

chrome.runtime.onMessageExternal.addListener(
  function(request, sender, sendResponse) {
    if (request.connecting == "launchClient"){
      launchVentanaMultiProceso(sendResponse);
    }
    if(request.connecting == "connectingScanner"){
      connectingScanner(sendResponse);
    }
    if(request.connecting=="scanning"){
      scanningMethod(sendResponse);
    }
    if(request.connecting=="launchServer"){
      launchServerSocket(sendResponse);
    }
    if(request.connecting=="checkingClientServerSystem"){
      checkingClientServerSystem(sendResponse);
    }
    if(request.connecting=="chuckOfInformation"){
      chunkOfInformation(sendResponse);
    }
    if(request.connecting=="closeServer"){
      closeServerSocket(sendResponse);
    }
    if(request.connecting=="shutDownScanner"){
      shutDownScanner(sendResponse);
    }
    if(request.connecting=="goIdleStateScanner"){
      goIdleStateScanner(sendResponse);
    }
});

function launchServerSocket(sendResponse){
  try{
    port = chrome.runtime.connectNative(hostServer);
    port.postMessage({text:"Hola App"});
    port.onMessage.addListener(onNativeMessage);
    port.onDisconnect.addListener(function() {
      console.log("Disconnected");
    });
    sendResponse({connected: "conectado"})
  }catch(error){
    sendResponse({error: "error"});
  }
}


function launchVentanaMultiProceso(sendResponse){
  try{
    port = chrome.runtime.connectNative(hostName);
    port.postMessage({text:"Hola App"});
    port.onMessage.addListener(onNativeMessage);
    sendResponse({connected: "conectado"})
  }catch(error){
    sendResponse({error: "error"});
  }
}

function checkingClientServerSystem(sendResponse){
  try{
    port.postMessage({text:"SERVE"});
    mensajeCapturado().then(respuesta=>{
      sendResponse({connected: respuesta});
    }).catch(error=>{
      console.log(error);
    })
  }catch(error){
    sendResponse({error: "error"});
  }
}

function connectingScanner(sendResponse){
  try{
    port.postMessage({text:"CONEC"});
    mensajeCapturado().then(respuesta=>{
      sendResponse({connected: respuesta});
    }).catch(error=>{
      console.log(error);
    })
  }catch(error){
    sendResponse({error: "error"});
  }
}

function scanningMethod(sendResponse){
  try{
    port.postMessage({text:"START"});
    mensajeCapturado().then(respuesta=>{
      sendResponse({connected: respuesta});
    }).catch(error=>{
      console.log(error);
    })
  }catch(error){
    sendResponse({error: "error"});
  }
}

function chunkOfInformation(sendResponse){
  try{
    port.postMessage({text:"INFOR"});
    mensajeCapturado().then(respuesta=>{
      sendResponse({connected: respuesta});
    }).catch(error=>{
      console.log(error);
    })
  }catch(error){
    sendResponse({error: "error"});
  }
}

function closeServerSocket(sendResponse){
  try{
    port.postMessage({text:"SALIR"});
    mensajeCapturado().then(respuesta=>{
      sendResponse({connected: respuesta});
    }).catch(error=>{
      console.log(error);
    })
  }catch(error){
    sendResponse({error: "error"});
  }
}

function shutDownScanner(sendResponse){
  try{
    port.postMessage({text:"SHUTD"});
    mensajeCapturado().then(respuesta=>{
      sendResponse({connected: respuesta});
    }).catch(error=>{
      console.log(error);
    })
  }catch(error){
    sendResponse({error: "error"});
  }
}

function goIdleStateScanner(sendResponse){
  try{
    port.postMessage({text:"GIDLE"});
    mensajeCapturado().then(respuesta=>{
      sendResponse({connected: respuesta});
    }).catch(error=>{
      console.log(error);
    })
  }catch(error){
    sendResponse({error: "error"});
  }
}

function onNativeMessage(message) {
  if(message!=null){
    return message;
  }
}

function mensajeCapturado(){
  return new Promise(function(resolve,reject){
    port.onMessage.addListener(function(message){
      if(message){
        resolve(message);
      }
      reject("error de datos");
    });
  });   
}

