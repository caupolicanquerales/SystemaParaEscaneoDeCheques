'''
Created on Jan 19, 2021

@author: c.querales.salas
'''

from interface import Interface

class ScannerI(Interface):
    
    def ejecutarModo(self,scannerDll):
        pass
    