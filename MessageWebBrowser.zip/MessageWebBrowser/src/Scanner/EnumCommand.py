'''
Created on Jan 4, 2021

@author: c.querales.salas
'''

from enum import Enum

class EnumCommands(Enum):
    START='ejecutar',
    CONEC='conectar',
    SERVE='server',
    SALIR='salir',
    INFOR='informacion',
    SHUTD='cerrar_escaner',
    GIDLE='idle_state',
    SCHRO='leave_chrome_system',
    SFIRE='leave_firefox_system'
        