'''
Created on Feb 8, 2021

@author: c.querales.salas
'''

from interface import implements 
from Scanner.ScannerInterface_version2 import ScannerI

class ScannerGoIdleState(implements(ScannerI)):
    
    __STATE_IDLE=2;
    __STATE_READY=4;
    __NO_ACTIVE_VALUE=0;
    __ACTIVE_VALUE=1;
    __EMPTY_EXCEPTION="";
    __readyToProcess=0;
    __flowStopped=0;
    __hopperEmpty=0;
    __disconnected=0;
    __connected=0;
    __onIdle=0;
    __exceptionInProgress="";
    __state="";

    def __init__(self):
        self.__setInitialConditionsVariables()
    
    def ejecutarModo(self,scannerDll):
        self.scannerDll=scannerDll
        self.__resetValueOfVariable(scannerDll)
        if(scannerDll.tTrackState== self.__STATE_READY):
            self.__goToIdleState(scannerDll)
        return self.__buildMessage()
    
    def __goToIdleState(self,scannerDll):
        while(self.__disconnected==self.__NO_ACTIVE_VALUE and self.__onIdle==self.__NO_ACTIVE_VALUE):
            self.__getValueOfVariable(scannerDll)
            self.__setGoIdle(scannerDll)
    
    def __setInitialConditionsVariables(self):
        self.__disconnected= self.__NO_ACTIVE_VALUE
        self.__connected= self.__NO_ACTIVE_VALUE
        self.__onIdle= self.__NO_ACTIVE_VALUE
        self.__readyToProcess= self.__NO_ACTIVE_VALUE
        self.__flowStopped= self.__NO_ACTIVE_VALUE
        self.__hopperEmpty= self.__NO_ACTIVE_VALUE
        self.__exceptionInProgress= self.__EMPTY_EXCEPTION   
    
    def __resetValueOfVariable(self,scannerDll):
        scannerDll.OnDisconnected=self.__NO_ACTIVE_VALUE
        scannerDll.OnIdle=self.__NO_ACTIVE_VALUE
    
    def __getValueOfVariable(self,scannerDll):
        self.__disconnected= int(scannerDll.OnDisconnected)
        self.__connected= int(scannerDll.OnConnected)
        self.__onIdle= int(scannerDll.OnIdle)
        self.__readyToProcess= int(scannerDll.OnReadyToProcess)
        self.__flowStopped= int(scannerDll.OnFlowStopped)
        self.__hopperEmpty= int(scannerDll.OnHopperEmpty)
        self.__exceptionInProgress= str(scannerDll.OnExceptionInProgress)
        self.__state='{state:'+str(scannerDll.tTrackState)+'}*sc*{serial:'+scannerDll.tSerialNumber0+'}*sc*'
    
    def __setGoIdle(self,scannerDll):
        if(self.__conditionGoIdleNormalProcess(scannerDll) or self.__conditionErrorReadyState(scannerDll)):
            scannerDll.GoIdle()
    
    def __conditionGoIdleNormalProcess(self,scannerDll):
        return self.__conditionReadyState(scannerDll) and self.__conditionWhenProcessIsFinished() 
    
    def __conditionReadyState(self,scannerDll):
        return scannerDll.tTrackState== self.__STATE_READY and self.__readyToProcess== self.__ACTIVE_VALUE
    
    def __conditionWhenProcessIsFinished(self):
        return self.__flowStopped== self.__ACTIVE_VALUE or self.__hopperEmpty== self.__ACTIVE_VALUE
    
    def __conditionErrorReadyState(self,scannerDll):
        return scannerDll.tTrackState== self.__STATE_READY and self.__exceptionInProgress!= self.__EMPTY_EXCEPTION
    
    def __buildMessage(self):
        return (self.__state+'{exep:'+self.__exceptionInProgress+'}')