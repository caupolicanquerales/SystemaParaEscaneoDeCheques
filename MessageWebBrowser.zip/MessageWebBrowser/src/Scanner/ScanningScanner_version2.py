'''
Created on Jan 20, 2021

@author: c.querales.salas
'''

from interface import implements 
from Scanner.ScannerInterface_version2 import ScannerI

class Scanning_version2(implements(ScannerI)):
    
    __STATE_IDLE=2
    __STATE_READY=4
    __STATE_FLOWING=5
    __NO_ACTIVE_VALUE=0
    __ACTIVE_VALUE=1
    __EMPTY_EXCEPTION=""
    __disconnected=0
    __connected=0
    __onIdle=0
    __readyToProcess=0
    __flowStopped=0
    __hopperEmpty=0
    __exceptionInProgress=""
    __docReadComplete=""
    __docImageComplete=""
    __state=""
    __readerini=""
    __endorseini=""
    __imageini=""
    __flag_state_idle=False
    __READER_FILE="\\\READER.INI"
    __ENDORSE_FILE="\\\ENDORSE.INI"
    __IMAGE_FILE="\\\IMAGE.INI"
    
    def __init__(self,fullPath):
        self.fullPath=fullPath
        self.readerini= self.fullPath+self.__READER_FILE
        self.endorseini= self.fullPath+self.__ENDORSE_FILE
        self.imageini= self.fullPath+self.__IMAGE_FILE
        self.__setInitialConditionsVariables()
    
    def ejecutarModo(self,scannerDll):
        self.scannerDll=scannerDll
        scannerDll.OnDocReadComplete=self.__EMPTY_EXCEPTION
        scannerDll.OnDocImageComplete=self.__EMPTY_EXCEPTION
        self.__getValueOfVariable(scannerDll)
        if(self.scannerDll.tTrackState== self.__STATE_IDLE and self.__exceptionInProgress== self.__EMPTY_EXCEPTION):
            self.__flag_state_idle=True
            self.__resetValueOfVariable(scannerDll)
            self.__getValueOfVariable(scannerDll)
            self.__processOfScanning(self.scannerDll)
        if(self.scannerDll.tTrackState== self.__STATE_READY and self.__exceptionInProgress== self.__EMPTY_EXCEPTION
           and self.__flag_state_idle==False):
            scannerDll.OnFlowStopped=self.__NO_ACTIVE_VALUE
            scannerDll.OnHopperEmpty=self.__NO_ACTIVE_VALUE
            self.__setInitialConditionsVariables()
            self.__processOfScanningReadyState(scannerDll)
        self.__docImageComplete=self.__convertTiffToJpg(scannerDll)
        return self.__buildMessage()
    
    def __processOfScanning(self,scannerDll):
        while(self.__flowStopped==self.__NO_ACTIVE_VALUE and self.__hopperEmpty==self.__NO_ACTIVE_VALUE 
              and self.__exceptionInProgress==self.__EMPTY_EXCEPTION):
            self.__getValueOfVariable(scannerDll)
            self.__setGoReadyToProcess(scannerDll)
            self.__setFlowStart(scannerDll)
    
    def __processOfScanningReadyState(self,scannerDll):
        while(self.__flowStopped==self.__NO_ACTIVE_VALUE and self.__hopperEmpty==self.__NO_ACTIVE_VALUE 
              and self.__exceptionInProgress==self.__EMPTY_EXCEPTION):
            self.__getValueOfVariable(scannerDll)
            self.__setFlowStart(scannerDll)
            
    def __setInitialConditionsVariables(self):
        self.__disconnected= self.__NO_ACTIVE_VALUE
        self.__connected= self.__NO_ACTIVE_VALUE
        self.__readyToProcess= self.__NO_ACTIVE_VALUE
        self.__onIdle= self.__NO_ACTIVE_VALUE
        self.__flowStopped= self.__NO_ACTIVE_VALUE
        self.__hopperEmpty= self.__NO_ACTIVE_VALUE
        self.__exceptionInProgress= self.__EMPTY_EXCEPTION
        self.__docImageComplete=self.__EMPTY_EXCEPTION
    
    def __getValueOfVariable(self,scannerDll):
        self.__disconnected= int(scannerDll.OnDisconnected)
        self.__connected= int(scannerDll.OnConnected)
        self.__readyToProcess= int(scannerDll.OnReadyToProcess)
        self.__onIdle= int(scannerDll.OnIdle)
        self.__flowStopped= int(scannerDll.OnFlowStopped)
        self.__hopperEmpty= int(scannerDll.OnHopperEmpty)
        self.__exceptionInProgress= str(scannerDll.OnExceptionInProgress)
        self.__docReadComplete= str(scannerDll.OnDocReadComplete)
        self.__docImageComplete= str(scannerDll.OnDocImageComplete)
        self.__state='{state:'+str(scannerDll.tTrackState)+'}*sc*{serial:'+scannerDll.tSerialNumber0+'}*sc*'
    
    def __resetValueOfVariable(self,scannerDll):
        scannerDll.OnDisconnected=self.__NO_ACTIVE_VALUE
        scannerDll.OnReadyToProcess=self.__NO_ACTIVE_VALUE
        scannerDll.OnIdle=self.__NO_ACTIVE_VALUE
        scannerDll.OnFlowStopped=self.__NO_ACTIVE_VALUE
        scannerDll.OnHopperEmpty=self.__NO_ACTIVE_VALUE
       
    def __setGoReadyToProcess(self,scannerDll):
        if(self.__conditionIdleState(scannerDll) and self.__exceptionInProgress== self.__EMPTY_EXCEPTION):
            scannerDll.iImageStoragePath= self.fullPath
            scannerDll.iRdrFontLoadPath= self.readerini
            scannerDll.iEndFontSetup= self.endorseini
            scannerDll.iImgCarSetupFilePath= self.imageini
            scannerDll.iOptions= 0
            scannerDll.iEndorserLines= 0
            scannerDll.iEndRearSequenceNumberIncrement= 1
            scannerDll.iEndRearSequenceNumberStart= 1
            scannerDll.iImgImageDirectory= ""
            scannerDll.GoReadyToProcess()
    
    
    def __setFlowStart(self,scannerDll):
        if(self.__conditionReadyState(scannerDll) and self.__exceptionInProgress== self.__EMPTY_EXCEPTION):
            scannerDll.FlowStart(0)
    
    def __conditionGoIdleNormalProcess(self,scannerDll):
        return self.__conditionReadyState(scannerDll) and self.__conditionWhenProcessIsFinished() 
    
    def __conditionIdleState(self,scannerDll):
        return (scannerDll.tTrackState==self.__STATE_IDLE and self.__connected==self.__ACTIVE_VALUE 
                and self.__onIdle== self.__NO_ACTIVE_VALUE) 
    
    def __conditionReadyState(self,scannerDll):
        return scannerDll.tTrackState== self.__STATE_READY and self.__readyToProcess== self.__ACTIVE_VALUE
    
    def __conditionWhenProcessIsFinished(self):
        return self.__flowStopped== self.__ACTIVE_VALUE or self.__hopperEmpty== self.__ACTIVE_VALUE
    
    def __conditionErrorReadyState(self,scannerDll):
        return scannerDll.tTrackState== self.__STATE_READY and self.__exceptionInProgress!= self.__EMPTY_EXCEPTION
    
    def __conditionErrorFlowingState(self,scannerDll):
        return (scannerDll.tTrackState== self.__STATE_FLOWING and self.__connected== self.__ACTIVE_VALUE
                and self.__onIdle== self.__NO_ACTIVE_VALUE)
    
    def __convertTiffToJpg(self,scannerDll):
        if self.__docImageComplete!=self.__EMPTY_EXCEPTION:
            scannerDll.AddressProject=self.fullPath
            docImageCompleteJpg=""
            imagesDoc=self.__docImageComplete.split(';')
            scannerDll.ConfigurationOfFolderImage()
            for information in imagesDoc:
                if information!=self.__EMPTY_EXCEPTION:
                    docImageCompleteJpg=docImageCompleteJpg+self.__convertImagesToJpg(information,scannerDll)
            return docImageCompleteJpg
        return  self.__docImageComplete
    
    def __convertImagesToJpg(self,information,scannerDll):
        images=information.split(',')
        imgF=images[1].replace('imgF>','')
        imgR=images[2].replace('imgR>','')
        imgR=imgR.replace('}','')
        imgF=self.__getFrontImageJpg(imgF,scannerDll)
        imgR=self.__getRearImageJpg(imgR,scannerDll)
        result=images[0]+',imgF>'+imgF+',imgR>'+imgR+'};'
        return result 
    
    def __getFrontImageJpg(self,imgF,scannerDll):
        if imgF!=self.__EMPTY_EXCEPTION:
            return scannerDll.ConvertImageTiffToBase64Jpg(imgF)
        return imgF
    
    def __getRearImageJpg(self,imgR,scannerDll):
        if imgR!=self.__EMPTY_EXCEPTION:
            return scannerDll.ConvertImageTiffToBase64Jpg(imgR)
        return imgR
    
    def __buildMessage(self):
        return (self.__state+'{docRead:['+self.__docReadComplete+']}*sc*'+'{docImage:['+self.__docImageComplete+']}*sc*'
                +'{exep:'+self.__exceptionInProgress+'}')