'''
Created on Jan 19, 2021

@author: c.querales.salas
'''

from interface import implements 
from Scanner.ScannerInterface_version2 import ScannerI

class Connection_version2(implements(ScannerI)):
    
    __STATE_POWER_OFF=1;
    __NO_ACTIVE_VALUE=0;
    __ACTIVE_VALUE=1;
    __disconnected=0;
    __exceptionInProgress="";
    __poweredUp=0;
    __EMPTY_EXCEPTION="";
    
    def __init__(self):
        self.__setInitialConditionsVariables()
    
    def ejecutarModo(self,scannerDll):
        self.scannerDll=scannerDll
        self.__resetProcessVariables(scannerDll)
        if(self.scannerDll.StartState==1 and self.scannerDll.tTrackState==self.__STATE_POWER_OFF):
            self.__powerUpProcess()
        return self.__buildMessage() 
    
    def __setInitialConditionsVariables(self):
        self.__exceptionInProgress=self.__EMPTY_EXCEPTION
        self.__disconnected=self.__NO_ACTIVE_VALUE
        self.__poweredUp=self.__NO_ACTIVE_VALUE
    
    
    def __resetProcessVariables(self,scannerDll):
        scannerDll.OnExceptionInProgress=self.__EMPTY_EXCEPTION
        scannerDll.OnDocReadComplete=self.__EMPTY_EXCEPTION
        scannerDll.OnDocImageComplete=self.__EMPTY_EXCEPTION
    
    def __powerUpProcess(self):
        poweringUp= self.__NO_ACTIVE_VALUE
        while(self.__poweredUp==self.__NO_ACTIVE_VALUE and self.__disconnected==self.__NO_ACTIVE_VALUE
              and self.__exceptionInProgress==self.__EMPTY_EXCEPTION):
            self.__exceptionInProgress= str(self.scannerDll.OnExceptionInProgress)
            self.__disconnected= int(self.scannerDll.OnDisconnected)
            self.__poweredUp= int(self.scannerDll.OnPoweredUp)
            if(poweringUp== self.__NO_ACTIVE_VALUE):
                poweringUp= self.__ACTIVE_VALUE
                self.scannerDll.PowerUp()
    
    def __buildMessage(self):
        state='{state:'+str(self.scannerDll.tTrackState)+'}*sc*'
        serial='{serial:'+self.scannerDll.tSerialNumber0+'}*sc*'
        exception='{exep:'+self.__exceptionInProgress+'}'
        return state+serial+exception