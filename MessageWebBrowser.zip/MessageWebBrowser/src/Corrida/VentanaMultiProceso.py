'''
Created on Jan 20, 2021

@author: c.querales.salas
'''

import sys
import threading
import struct
import ast
import time
import traceback
import os
from queue import Queue
from Operations.Writter import writter
from Operations.Enum import MensajesEnum
from Scanner.EnumCommand import EnumCommands
from SocketSimpleCommunication.ConectionClient import Connection
from SocketSimpleCommunication.SplitScanningResult import SplitScanningResult


try:
    path=str(os.getcwdb())[1::]
    fullPath=path[:-1:][0:0:]+path[:-1:][1::]
except Exception:
    traceback.print_exc()

def sendMessage_thread(queueResultado,queueScanningResult,queueShutDownApplication,splitResult):
    enter=True
    while enter:
        resultado=queueResultado.get()
        resultado=splitResult.getResultFromScanning(resultado,queueScanningResult)
        sendingMessage(resultado)
        time.sleep(0.3)
        queueShutDownApplication.put(resultado)
        
def read_thread_func(queue,queueResultado,queueScanningResult,queueShutDownApplication,splitResult):
    hilo=None
    enter=True
    while enter:
        try:
            text_length_bytes = sys.stdin.buffer.read(4)
            if len(text_length_bytes) == 0:
                if queue:
                    queue.put(None)
                sys.exit(0)
                
            text_length = struct.unpack('i', text_length_bytes)[0]
            text = sys.stdin.buffer.read(text_length).decode('utf-8')
            #text = sys.stdin.buffer.read(18).decode('utf-8')
            queue.put(text)
            command=getCommand(text,'text')
            if(command is not None and command!=EnumCommands.SFIRE.name):
                checkedCommand=searchCommandSalirChrome(command)
                hilo=executingThread(hilo,checkedCommand,queueResultado,queueScanningResult,splitResult)
                enter=conditionThreadAlive(checkedCommand)
            else:
                sendingMessage(MensajesEnum.LEAVE_APP_FOR_FIREFOX.value)
                queueShutDownApplication.put(MensajesEnum.LEAVE_APP.value)
                enter=False
        except Exception:
            traceback.print_exc()
            sendingMessage(str(traceback.format_exc()))
    sys.exit(0)


def executingThread(hilo,command,queueResultado,queueScanningResult,splitResult):
    try:
        if hilo is not None and hilo.is_alive():
            sendingMessage(MensajesEnum.OPERACION_EN_USO.value)
        if conditionForThread(hilo) and searchForCommand(command):
            hilo= Connection(command,queueResultado,fullPath,queueScanningResult,splitResult)
            hilo.daemon = True
            hilo.start()
        return hilo
    except Exception:
        traceback.print_exc()
        sendingMessage(str(traceback.format_exc()))

def conditionThreadAlive(command):
    if(command==MensajesEnum.SALIR.value):
        return False
    return True    

def searchForCommand(command):
    try:
        resultado=EnumCommands[command]
        return True
    except Exception:
        return False

def conditionForThread(hilo):
    return hilo is None or (hilo is not None and hilo.is_alive() is not True)

def sendingMessage(texto):
    informacion='"'+texto+'"'
    mensaje='{"echo": %s}' %informacion
    writter.send_message(mensaje,mensaje)

def getCommand(texto,palabra):
    try:
        if texto is not None:
            dictionary= ast.literal_eval(texto)
            return dictionary[palabra]
        return None
    except Exception:
        traceback.print_exc()
        sendingMessage(str(traceback.format_exc()))

def searchCommandSalirChrome(command):
    if command==EnumCommands.SCHRO.name:
        return EnumCommands.SALIR.name
    return command

def start(queueShutDownApplication):
    condition=True
    while condition:
        leaveApp= queueShutDownApplication.get()
        if(leaveApp is not None and leaveApp==MensajesEnum.LEAVE_APP.value):
            condition=False
    sys.exit(0)

         
def Main():
    queue = Queue()
    queueResultado=Queue()
    queueScanningResult= Queue()
    queueShutDownApplication= Queue()
    splitResult=SplitScanningResult()
    thread = threading.Thread(target=read_thread_func, args=(queue,queueResultado,queueScanningResult,queueShutDownApplication,splitResult,))
    thread.daemon = True
    thread.start()
    threadResultado = threading.Thread(target=sendMessage_thread, args=(queueResultado,queueScanningResult,queueShutDownApplication,splitResult,))
    threadResultado.daemon = True
    threadResultado.start()
    start(queueShutDownApplication)
    sys.exit(0)

if __name__ == '__main__':
    Main()