'''
Created on Jan 20, 2021

@author: c.querales.salas
'''

import sys
import threading
import struct
import ast
import time
import traceback
import os
from Operations.Writter import writter
from Operations.Enum import MensajesEnum
from Scanner.EnumCommand import EnumCommands
from SocketSimpleCommunication.ConectionClient import Connection
from SocketSimpleCommunication.SplitScanningResult import SplitScanningResult

try:
    import tkinter
    import tkinter.messagebox
    from queue import Queue
except ImportError:
    tkinter = None

try:
    path=str(os.getcwdb())[1::]
    fullPath=path[:-1:][0:0:]+path[:-1:][1::]
except Exception:
    traceback.print_exc()

def sendMessage_thread(queueResultado,queueScanningResult,splitResult):
    enter=True
    while enter:
        resultado=queueResultado.get()
        resultado=splitResult.getResultFromScanning(resultado,queueScanningResult)
        sendingMessage(resultado)
        time.sleep(0.3)
        
def read_thread_func(queue,queueResultado,queueScanningResult,splitResult):
    hilo=None
    enter=True
    while enter:
        try:
            text_length_bytes = sys.stdin.buffer.read(4)
            if len(text_length_bytes) == 0:
                if queue:
                    queue.put(None)
                sys.exit(0)
                
            text_length = struct.unpack('i', text_length_bytes)[0]
            text = sys.stdin.buffer.read(text_length).decode('utf-8')
            #text = sys.stdin.buffer.read(18).decode('utf-8')
            queue.put(text)
            command=getCommand(text,'text')
            hilo=executingThread(hilo,command,queueResultado,queueScanningResult,splitResult)
            enter=conditionThreadAlive(command)
        except Exception:
            traceback.print_exc()
            sendingMessage(str(traceback.format_exc()))
    sys.exit(0)


def executingThread(hilo,command,queueResultado,queueScanningResult,splitResult):
    try:
        if hilo is not None and hilo.is_alive():
            sendingMessage(MensajesEnum.OPERACION_EN_USO.value)
        if conditionForThread(hilo) and searchForCommand(command):
            hilo= Connection(command,queueResultado,fullPath,queueScanningResult,splitResult)
            hilo.daemon = True
            hilo.start()
        return hilo
    except Exception:
        traceback.print_exc()
        sendingMessage(str(traceback.format_exc()))

def conditionThreadAlive(command):
    if(command==MensajesEnum.SALIR.value):
        return False
    return True    

def searchForCommand(command):
    try:
        resultado=EnumCommands[command]
        return True
    except Exception:
        return False

def conditionForThread(hilo):
    return hilo is None or (hilo is not None and hilo.is_alive() is not True)

def sendingMessage(texto):
    informacion='"'+texto+'"'
    mensaje='{"echo": %s}' %informacion
    writter.send_message(mensaje,mensaje)

def getCommand(texto,palabra):
    try:
        if texto is not None:
            dictionary= ast.literal_eval(texto)
            return dictionary[palabra]
        return None
    except Exception:
        traceback.print_exc()
        sendingMessage(str(traceback.format_exc()))

if tkinter:
    class NativeMessagingWindow(tkinter.Frame):
        
        def __init__(self,queue):
            self.queue = queue
            tkinter.Frame.__init__(self)
            self.pack()
            
            self.text = tkinter.Text(self)
            self.text.grid(row=0, column=0, padx=10, pady=10, columnspan=2)
            self.text.config(state=tkinter.DISABLED, height=10, width=40)
            
            self.messageContent = tkinter.StringVar()
            self.sendEntry = tkinter.Entry(self, textvariable=self.messageContent)
            self.sendEntry.grid(row=1, column=0, padx=10, pady=10)
            self.sendButton = tkinter.Button(self, text="Send", command=self.onSend)
            self.sendButton.grid(row=1, column=1, padx=10, pady=10)
            self.after(100, self.processMessages)
            
        
        def processMessages(self):
            while not self.queue.empty():
                message = self.queue.get()
                if message == None:
                    self.quit()
                    return
                self.text.delete(0,'end')
                self.text.config(background='blue')
                self.log("Received %s" % message)
            self.after(100, self.processMessages)
           
        def onSend(self):
            try:
                text = self.messageContent.get()
                self.text.config(background='yellow')
                self.log('Sending '+self.sendEntry.get())
                self.sendEntry.delete(0,'end')
                sendingMessage(text)
            except Exception:
                tkinter.messagebox.showinfo('Native Messaging Example',
                              'Failed to send '+text+' Error '+sys.exc_info()[0])
                sys.exit(1)
        
        def log(self, message):
            self.text.config(state=tkinter.NORMAL)
            self.text.insert(tkinter.END, message + "\n")
            self.text.config(state=tkinter.DISABLED)
        
def Main():
    queue = Queue()
    queueResultado=Queue()
    queueScanningResult= Queue()
    splitResult=SplitScanningResult()
    main_window = NativeMessagingWindow(queue)
    main_window.master.title('Native Messaging Example')
    thread = threading.Thread(target=read_thread_func, args=(queue,queueResultado,queueScanningResult,splitResult,))
    thread.daemon = True
    thread.start()
    threadResultado = threading.Thread(target=sendMessage_thread, args=(queueResultado,queueScanningResult,splitResult,))
    threadResultado.daemon = True
    threadResultado.start()
    main_window.mainloop()
    sys.exit(0)

if __name__ == '__main__':
    Main()