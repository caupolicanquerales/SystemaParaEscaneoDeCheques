'''
Created on Jan 19, 2021

@author: c.querales.salas
'''
import socket
import traceback
import os
from queue import Queue
from Scanner.EnumCommand import EnumCommands
from SocketSimpleCommunication.ConnectionScanner import ConnectionScanner
from SocketSimpleCommunication.RecoverCommandAndValue import RecoverCommandAndValue


try:
    import clr
    path=str(os.getcwdb())[1::]
    fullPath=path[:-1:][0:0:]+path[:-1:][1::]
    clr.AddReference(fullPath+"\\\Scanner.dll")
    from ScannerControl import Scanner
except Exception:
    traceback.print_exc()


HOST = ''                 # The remote host
PORT = 50007              # Arbitrary non-privileged port
END_PROCESS="SALIR"
EMPTY_STRING=""
ADDRESS_TXT_FILE=""

def start(queue,scannerDll):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((HOST, PORT))
    sock.listen()
    PROCESS=True
    while PROCESS:
        conn, addr = sock.accept()
        print ('Connected by', addr)
        while 1:
            data = conn.recv(1024)
            if not data: break
            value=__getMessageInArray(data.decode('utf-8'),fullPath)
            PROCESS=endTheProcess(value,PROCESS)
            global ADDRESS_TXT_FILE
            ADDRESS_TXT_FILE=__setAddressTxtFile(value,ADDRESS_TXT_FILE)
            scanner= ConnectionScanner(value,queue,scannerDll,fullPath,ADDRESS_TXT_FILE)
            scanner.run()
            valor= queue.get()
            conn.sendall(str.encode(valor))
    conn.close()


def endTheProcess(value,PROCESS):
    if value[0]==END_PROCESS:
        return False         
    return PROCESS

def __getMessageInArray(message,fullPath):
    recover=RecoverCommandAndValue()
    return recover.getCommandWhichWasSent(message,fullPath)

def __setAddressTxtFile(value,ADDRESS_TXT_FILE):
    if value[0]==EnumCommands.SERVE.name:
        return value[2]
    return ADDRESS_TXT_FILE


def main():
    queue = Queue()
    scannerDll= Scanner()
    start(queue,scannerDll)

if __name__ == '__main__':
    main()