'''
Created on Jan 19, 2021

@author: c.querales.salas
'''

import threading
import socket
from TextFile.TextFile import TextFile
from Scanner.EnumCommand import EnumCommands

class Connection(threading.Thread):
    
    __HOST = '127.0.0.1'      # The remote host
    __PORT = 50007              # The same port as used by the server
    __FILE_NAME="\\\scanneo.txt"

    def __init__(self,command, queueResultado,fullPath,queueScanningResult,splitResult):
        threading.Thread.__init__(self)
        self.command=command
        self.queueResultado=queueResultado
        self.fullPath=fullPath+self.__FILE_NAME
        self.queueScanningResult=queueScanningResult
        self.splitResult=splitResult
    
    def run(self):
        if self.command!=EnumCommands.INFOR.name:
            self.__configuration()
        else:
            result=self.__readFile()
            self.queueScanningResult.put(EnumCommands.START.name+"-"+result)
            self.splitResult.chunkOfInformation(self.queueScanningResult,self.queueResultado)    
        
        
    def __configuration(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((self.__HOST, self.__PORT))
        menssage_byte=self.__getMessage()
        sock.sendall(menssage_byte)
        data = sock.recv(1024).decode('utf-8')
        self.__getInformationFronFile(data)
        sock.close()
    
    def __getMessage(self):
        if self.command==EnumCommands.SERVE.name:
            return str.encode('{"'+self.command+'":"'+self.fullPath+'"}')
        return str.encode('{"'+self.command+'":"'+self.command+'"}')
    
    def __getInformationFronFile(self,data):
        if data==EnumCommands.SALIR.name:
            self.queueResultado.put(data)
        else:
            self.__setResultForScanning()
    
    def __setResultForScanning(self):
        result=self.__readFile()
        if(self.command==EnumCommands.START.name):
            self.queueResultado.put(EnumCommands.START.name+"-"+result)
        else:
            self.queueResultado.put(result)
    
    def __readFile(self):
        file=TextFile()
        result=file.readTextFile(self.fullPath)
        return result 