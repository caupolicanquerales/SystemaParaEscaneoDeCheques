'''
Created on Mar 30, 2021

@author: c.querales.salas
'''

import traceback
import os
import sys
import ast
import threading
import struct
import time
from queue import Queue
from Operations.Enum import MensajesEnum
from Operations.Writter import writter

try:
    import clr
    path=str(os.getcwdb())[1::]
    fullPath=path[:-1:][0:0:]+path[:-1:][1::]
    fullPath=fullPath+"\\\SocketSimpleServerFireFox.exe"
except Exception:
    traceback.print_exc()


def read_thread_func(queueShutDownApplication,queueResultado):
    enter=True
    while enter:
        try:
            text_length_bytes = sys.stdin.buffer.read(4)
            if len(text_length_bytes) == 0:
                sys.exit(0)
            text_length = struct.unpack('i', text_length_bytes)[0]
            text = sys.stdin.buffer.read(text_length).decode('utf-8')
            #text = sys.stdin.buffer.read(18).decode('utf-8')
            command=getCommand(text,'text')
            queueShutDownApplication.put(command)
            queueResultado.put(command)
            enter= leaveThread(command)
        except Exception:
            traceback.print_exc()
    sys.exit(0)

def getCommand(texto,palabra):
    try:
        if texto is not None:
            dictionary= ast.literal_eval(texto)
            return dictionary[palabra]
        return None
    except Exception:
        traceback.print_exc()

def leaveThread(command):
    if(command is not None and command==MensajesEnum.SALIR.value):
        return False
    return True

def sendingMessage(texto):
    informacion='"'+texto+'"'
    mensaje='{"echo": %s}' %informacion
    writter.send_message(mensaje,mensaje)

def start(queueShutDownApplication):
    condition=True
    while condition:
        leaveApp= queueShutDownApplication.get()
        if(leaveApp is not None and leaveApp==MensajesEnum.SALIR.value):
            sendingMessage(leaveApp)
            time.sleep(2)
            condition=False
    sys.exit(0)

def main():
    os.startfile(fullPath)
    queueResultado=Queue()
    queueShutDownApplication= Queue()
    thread = threading.Thread(target=read_thread_func, args=(queueShutDownApplication,queueResultado,))
    thread.daemon = True
    thread.start()
    start(queueShutDownApplication)
    sys.exit(0)

if __name__ == '__main__':
    main()