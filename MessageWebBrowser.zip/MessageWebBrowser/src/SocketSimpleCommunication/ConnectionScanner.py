'''
Created on Jan 19, 2021

@author: c.querales.salas
'''

import threading
from Scanner.EnumCommand import EnumCommands
from TextFile.TextFile import TextFile

class ConnectionScanner(threading.Thread):
    
    __ADDRESS_TXT_FILE=""
    __MESSAGE_RESULT=""
    __COMMANDS=[EnumCommands.CONEC.name,EnumCommands.SERVE.name,EnumCommands.START.name,EnumCommands.SALIR.name,
                EnumCommands.GIDLE,EnumCommands.SHUTD]
    
    def __init__(self,messageArray,queue, scannerDll,fullPath,addressTxtFile):
        threading.Thread.__init__(self)
        self.scannerDll=scannerDll
        self.queue=queue
        self.__ADDRESS_TXT_FILE=addressTxtFile
        self.command=messageArray[0]
        self.object=messageArray[1]
        self.__MESSAGE_RESULT=messageArray[2]
        self.fullPath=fullPath
        
     
    def run(self):
        if(self.object is not None):
            result=self.object.ejecutarModo(self.scannerDll)
            self.__creationOfTextFile(result)
        else:
            self.__MESSAGE_RESULT=self.__messageForServer(self.__MESSAGE_RESULT)
            self.__creationOfTextFile(self.__MESSAGE_RESULT)
    
    
    def __creationOfTextFile(self,informacion):
        file= TextFile()
        file.createTextFile(self.__ADDRESS_TXT_FILE, informacion)
        self.queue.put("SUCCESS OPERATION")
    
    def __messageForServer(self,messageResult):
        if self.command==EnumCommands.SERVE.name:
            return "SERVER IS OK"
        return messageResult