'''
Created on Jan 26, 2021

@author: c.querales.salas
'''
import math

class SplitScanningResult(object):
    
    __INITIAL_POSITION=0
    __LAST_POSITION=0
    __SIZE_OF_CHUNK=300000
    __CURRENT_CHUNK=0
    __CHUNK_INFORMATION=""
    __END_MESSAGE="END_MESSAGE"
    __FLAG_SCANNING_RESULT=False
    __chunks=0
    __CONDITION_STATE=["{state:6}","{state:4}","{state:5}"]
    
    def __init__(self):
        self
    
    def getResultFromScanning(self,message,queueScanningResult):
        if "START-" in message and self.__FLAG_SCANNING_RESULT==False:
            self.__FLAG_SCANNING_RESULT=True
            return self.__splitMessageInitialProcess(message)
        return message
    
    def chunkOfInformation(self,queueScanningResult,queueResultado):
        message=queueScanningResult.get()
        result=message.replace("START-","").strip()
        self.__chunks=math.ceil(len(result)/self.__SIZE_OF_CHUNK)
        chunkInformation=self.__getChunkOfInformation(self.__chunks,result)
        queueResultado.put(chunkInformation)

    def __splitMessageInitialProcess(self,message):
        result=message.replace("START-","").strip()
        chunks=math.ceil(len(result)/self.__SIZE_OF_CHUNK)
        return self.__getChunkOfInformation(chunks,result)
    
    def __getChunkOfInformation(self,chunks,result):
        if (chunks-self.__CURRENT_CHUNK)>1:
            self.__LAST_POSITION=self.__SIZE_OF_CHUNK+self.__LAST_POSITION
            self.__CHUNK_INFORMATION=result[self.__INITIAL_POSITION:self.__LAST_POSITION:]
            self.__INITIAL_POSITION=self.__LAST_POSITION
            self.__CURRENT_CHUNK+=1
        elif (chunks-self.__CURRENT_CHUNK)==1:
            sizeOfLastChar=len(result)-self.__LAST_POSITION
            self.__CHUNK_INFORMATION=result[self.__LAST_POSITION:self.__LAST_POSITION+sizeOfLastChar:]
            self.__resetFlagScanningInException(self.__CHUNK_INFORMATION)
            self.__CURRENT_CHUNK+=1
        elif chunks==self.__CURRENT_CHUNK:
            self.__CHUNK_INFORMATION=self.__END_MESSAGE
            self.__resetVariables()
        return self.__CHUNK_INFORMATION
    
    def __resetVariables(self):
        self.__CURRENT_CHUNK=0
        self.__INITIAL_POSITION=0
        self.__LAST_POSITION=0
        self.__FLAG_SCANNING_RESULT=False
    
    def __resetFlagScanningInException(self,CHUNK_INFORMATION):
        if any(state in CHUNK_INFORMATION for state in self.__CONDITION_STATE):
            self.__FLAG_SCANNING_RESULT=False
    
