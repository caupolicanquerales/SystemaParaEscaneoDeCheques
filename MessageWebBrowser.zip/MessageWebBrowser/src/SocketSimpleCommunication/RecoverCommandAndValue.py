'''
Created on Jan 25, 2021

@author: c.querales.salas
'''

import ast
from Scanner.EnumCommand import EnumCommands
from Scanner.ConnectScanner_version2 import Connection_version2
from Scanner.ScanningScanner_version2 import Scanning_version2
from Scanner.ScannerShutDown import ScannerShutDown
from Scanner.ScannerGoIdleState import ScannerGoIdleState 

class RecoverCommandAndValue(object):

    __RESULT=""
    __COMMANDS=[EnumCommands.CONEC.name,EnumCommands.SERVE.name,EnumCommands.START.name,EnumCommands.SALIR.name,
                EnumCommands.SHUTD.name,EnumCommands.GIDLE.name]
    
    def __init__(self):
        self
   
    def getCommandWhichWasSent(self,message,fullPath):
        self.fullPath=fullPath
        for command in self.__COMMANDS:
            self.__RESULT=self.__getValueOfMessage(message,command)
            if self.__RESULT is not None:
                return [command,self.__getCommandExecution(command),self.__RESULT]
                break

    def __getCommandExecution(self,command):
            if command==EnumCommands.CONEC.name:
                return Connection_version2()
            if command==EnumCommands.START.name:
                return Scanning_version2(self.fullPath)
            if command==EnumCommands.SERVE.name:
                return None
            if command==EnumCommands.GIDLE.name:
                return ScannerGoIdleState()
            if command==EnumCommands.SHUTD.name:
                return ScannerShutDown()
            if command==EnumCommands.SALIR.name:
                self.__RESULT="EXIT IS OK"
                return None
    
    def __getValueOfMessage(self,texto,palabra):
            try:
                if texto is not None:
                    dictionary= ast.literal_eval(texto)
                    return dictionary[palabra]
                return None
            except Exception:
                return None 