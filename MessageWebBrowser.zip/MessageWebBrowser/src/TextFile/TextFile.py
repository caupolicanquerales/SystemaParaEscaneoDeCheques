'''
Created on Jan 19, 2021

@author: c.querales.salas
'''

class TextFile(object):

    def __init__(self):
        self
    
    def createTextFile(self,fullPath,result):
        open(fullPath,"w+").close() 
        file= open(fullPath,"a+")
        file.write(result)
    
    def readTextFile(self,fullPath):
        file=open(fullPath,"r")
        return file.read()