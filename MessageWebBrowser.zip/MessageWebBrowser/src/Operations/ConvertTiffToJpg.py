'''
Created on Jan 29, 2021

@author: c.querales.salas
'''

import base64
import io
from base64 import decodestring
from TextFile.TextFile import TextFile
from PIL import Image
from fpdf import FPDF


class ConvertTiffToJpg(object):

    def __init__(self):
        self
    
    def readTextFile(self,fullPath):
        pathFile=fullPath+"\\\imgF.txt"
        file=TextFile()
        return file.readTextFile(pathFile)
        
    
    def convertBase64ToJpg(self,base,fullPath):
        pathFile=fullPath+"\\\images\\\image.jpg"
        pathFile2=fullPath+"\\\images\\\image2.jpeg"
        bytes_base64 = base.encode()
        data = base64.b64decode(bytes_base64)
        file=open(pathFile2,'wb').write(data)
        
        
        
        
    def convertJpgToPdf(self,fullPath):
        pathFile=fullPath+"\\\images\\\image2.jpeg"
        pathFile3=fullPath+"\\\images\\\cheque.jpg"
        pathFile4=fullPath+"\\\images\\\image3.jpeg"
        pathFilePdf=fullPath+"\\\images\\\prueba.pdf"    
        image1=Image.open(pathFile)
        image2=Image.open(pathFile3)
        w,h= image2.size
        image3= Image.new('RGB',(w,h),(100,100,100))
        image3.paste(image1,(0,50))
        #image3.paste(image2,(w,0))
        image3.save(pathFile4)
        #pdf= FPDF(unit="pt",format=[width,height])
        #pdf.add_page()
        #pdf.image(pathFile3, 0, 0, width, height)
        #pdf.output(pathFilePdf, "F")
        print("hola")
        
        
    '''
    data = open(pathFile, 'rb').read()
    bytes_base64 = base64.b64encode(data)
    result= bytes_base64.decode()
    '''