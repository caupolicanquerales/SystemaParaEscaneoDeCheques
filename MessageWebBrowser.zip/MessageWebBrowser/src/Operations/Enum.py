'''
Created on Nov 30, 2020

@author: c.querales.salas
'''

from enum import Enum

class MensajesEnum(Enum):
    SALIR='SALIR'
    OPERACION_EN_USO='Operacion en uso'
    PROBLEMA_OPERACION='Problema de operacion'
    PROBLEMA_SUMA='Problema con operacion de suma'
    PROBLEMA_RESTA='Problema con operacion de resta'
    PROBLEMA_DIVISION='Problema con operacion de division'
    PROBLEMA_IMAGEN='Problema con operacion de imagen'
    PROBLEMA_CONVERSION_DIC='Problema con conversion a diccionario imagen'
    PROBLEMA_EN_HILO_LECTURA='Problema en el hilo de lectura'
    PROBLEMA_EN_HILO='Problema en crear nueva instancia de hilo'
    LEAVE_APP="EXIT IS OK"
    LEAVE_APP_FOR_FIREFOX="EXIT IS OK FIREFOX"