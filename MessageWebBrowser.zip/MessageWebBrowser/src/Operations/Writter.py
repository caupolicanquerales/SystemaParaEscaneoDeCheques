'''
Created on Nov 30, 2020

@author: c.querales.salas
'''
import sys
import struct
import tkinter.messagebox

class writter(object):


    def __init__(self):
        self
    
    def send_message(self,message):
        try:
            sys.stdout.buffer.write(struct.pack('I', len(message)))#esto envia los byte de dimension del mensaje
            sys.stdout.write(message)
            sys.stdout.flush()
        except Exception:
            tkinter.messagebox.showinfo('Native Messaging Example',
                                  'Failed to send for stdout '+sys.exc_info()[0])
            