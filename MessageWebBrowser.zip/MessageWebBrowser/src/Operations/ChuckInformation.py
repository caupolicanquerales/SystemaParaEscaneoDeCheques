'''
Created on Jan 27, 2021

@author: c.querales.salas
'''
import sys
from TextFile.TextFile import TextFile
from SocketSimpleCommunication.SplitScanningResult import SplitScanningResult 


def getInformationFromFile():
    fullPath="C:\\Users\\c.querales.salas\\Desktop\\Programas\\Python\\MessageWebBrowser\\src\\Corrida\\scanneo.txt"
    file=TextFile()
    result=file.readTextFile(fullPath)
    size=len(result)
    return "START-"+result


def chunkInformation(chunk,message):
    chunk=SplitScanningResult()
    chunkInformation=""
    paso=0
    while (chunkInformation!="END_MESSAGE"):
        #chunkInformation=chunk.chunkOfInformation_2(message)
        paso+=1
        print(str(paso)+" "+str(sys.getsizeof(chunkInformation))+" " +chunkInformation)
'''    
    def chunkOfInformation_2(self,message):
    result=message.replace("START-","").strip()
    chunks=math.ceil(len(result)/self.__SIZE_OF_CHUNK)
    chunkInformation=self.__getChunkOfInformation(chunks,result)
    return chunkInformation
'''  


def main():
    chunk=SplitScanningResult()
    result=getInformationFromFile()
    chunkInformation(chunk,result)

if __name__ == '__main__':
    main()