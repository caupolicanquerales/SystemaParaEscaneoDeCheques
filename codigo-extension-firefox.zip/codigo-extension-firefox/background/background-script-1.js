
var hostName = "conexion.programa.autoejecutable";
var hostServer = "conexion.programa.serversocket";
var port0 = null;
var port1 = null;
var portServer = null;
var mensaje = null;

browser.runtime.onMessage.addListener(handleMessage);
  
function handleMessage(request, sender, sendResponse) {

  if (request.connecting == "launchClient"){
    launchVentanaMultiProceso(sendResponse);
  }
  if(request.connecting == "connectingScanner"){
    connectingScanner(sendResponse);
  }
  if(request.connecting=="scanning"){
    scanningMethod(sendResponse);
  }
  if(request.connecting=="launchServer"){
    launchServerSocket(sendResponse);
  }
  if(request.connecting=="checkingClientServerSystem"){
    checkingClientServerSystem(sendResponse);
  }
  if(request.connecting=="chuckOfInformation"){
    chunkOfInformation(sendResponse);
  }
  if(request.connecting=="closeServer"){
    closeServerSocket(sendResponse);
  }
  if(request.connecting=="shutDownScanner"){
    shutDownScanner(sendResponse);
  }
  if(request.connecting=="goIdleStateScanner"){
    goIdleStateScanner(sendResponse);
  }
  if(request.connecting=="shutDownLaunchSocketApp"){
    shutDownLaunchSocketApp(sendResponse);
  }
}

function launchServerSocket(sendResponse){
  try{
    port0 = browser.runtime.connectNative(hostServer);
    port0.postMessage({text:"Hola App"});
    port0.onMessage.addListener(onNativeMessage);
    port0.onDisconnect.addListener(function() {
      console.log("Disconnected");
    });
    sendResponse({connected: "conectado"});
  }catch(error){
    sendResponse({error: "SocketServer levantada, comprobar"});
  }
}

function launchVentanaMultiProceso(sendResponse){
  try{
    port1 = browser.runtime.connectNative(hostName);
    port1.postMessage({text:"Hola App"});
    port1.onMessage.addListener(onNativeMessage);
    sendResponse({connected: "conectado"});
  }catch(error){
    sendResponse({error: "error"});
  }
}

function checkingClientServerSystem(sendResponse){
  try{
    port1.postMessage({text:"SERVE"});
    var respuesta = mensajeCapturado().then(
      (response) => {  return {connected: response}; }
    ).catch(
      (error) => { console.log(error); }
    );
    sendResponse(respuesta);
  }catch(error){
    sendResponse({error: "error"});
  }
}

function connectingScanner(sendResponse){
  try{
    port1.postMessage({text:"CONEC"});
    var respuesta = mensajeCapturado().then(
      (response) => {  return {connected: response}; }
    ).catch(
      (error) => { return console.log(error); }
    );
    sendResponse(respuesta);
  }catch(error){
    sendResponse({error: "error"});
  }
}

function scanningMethod(sendResponse){
  try{
    port1.postMessage({text:"START"});
    var respuesta = mensajeCapturado().then(
      (response) => {  return {connected: response}; }
    ).catch(
      (error) => { return console.log(error); }
    );
    sendResponse(respuesta);

  }catch(error){
    sendResponse({error: "error"});
  }
}

function chunkOfInformation(sendResponse){
  try{
    port1.postMessage({text:"INFOR"});
    var respuesta = mensajeCapturado().then(
      (response) => { 
         return {connected: response}; }
    ).catch(
      (error) => { return console.log(error); }
    );
    sendResponse(respuesta);
  }catch(error){
    sendResponse({error: "error"});
  }
}

function closeServerSocket(sendResponse){
  try{
    port1.postMessage({text:"SFIRE"});
    var respuesta = mensajeCapturado().then(
      (response) => {  return {connected: response}; }
    ).catch(
      (error) => { return console.log(error); }
    );
    sendResponse(respuesta);
  }catch(error){
    sendResponse({error: "error"});
  }
}

function shutDownLaunchSocketApp(sendResponse){
  try{
    port0.postMessage({text:"SALIR"});
    var respuesta = mensajeCapturadoLaunchSocket().then(
      (response) => {  return {connected: response}; }
    ).catch(
      (error) => { return console.log(error); }
    );
    sendResponse(respuesta);
  }catch(error){
    sendResponse({error: "error"});
  }
}

function shutDownScanner(sendResponse){
  try{
    port1.postMessage({text:"SHUTD"});
    var respuesta = mensajeCapturado().then(
      (response) => {  return {connected: response}; }
    ).catch(
      (error) => { return console.log(error); }
    );
    sendResponse(respuesta);
  }catch(error){
    sendResponse({error: "error"});
  }
}

function goIdleStateScanner(sendResponse){
  try{
    port1.postMessage({text:"GIDLE"});
    var respuesta = mensajeCapturado().then(
      (response) => {  return {connected: response}; }
    ).catch(
      (error) => { return console.log(error); }
    );
    sendResponse(respuesta);
  }catch(error){
    sendResponse({error: "error"});
  }
}

function onNativeMessage(message) {
  if(message !== null){

    console.log("onNativeMessage: " + message.echo);

    return message.echo;
  }
}

function mensajeCapturado(){
  return new Promise(
    function(resolve,reject){
      port1.onMessage.addListener(
        function(message){
          if(message !== null){
            resolve(message.echo);
          }else{
            reject("error de datos");
          }

        }
      );
    }
  );   
}
function mensajeCapturadoLaunchSocket(){
  return new Promise(
    function(resolve,reject){
      port0.onMessage.addListener(
        function(message){
          if(message !== null){
            resolve(message.echo);
          }else{
            reject("error de datos");
          }

        }
      );
    }
  );   
}