
//Receive message from ConnectingToBackgroundFirefox.js

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window && event.data) {
        executeCorrectPromise(event);        
    }
}, false);

function executeCorrectPromise(event){
    if(event.data.direction=="launchClientSystem"){
        launchClientSystem(event.data.message);
    }else if(event.data.direction=="launchServerSystem"){
        launchServerSystem(event.data.message);
    }else if(event.data.direction=="closeServerSystem"){
        closeServerSystem(event.data.message);
    }else if(event.data.direction=="shutDownScanner"){
        shutDownScanner(event.data.message);
    }else if(event.data.direction=="goIdleStateScanner"){
        goIdleStateScanner(event.data.message);
    }else if(event.data.direction=="checkingClientServerSystem"){
        checkingClientServerSystem(event.data.message);
    }else if(event.data.direction=="connectingScanner"){
        connectingScanner(event.data.message);
    }else if(event.data.direction=="scanningProcessing"){
        scanningProcessing(event.data.message);
    }else if(event.data.direction=="chuckOfInformation"){
        chuckOfInformation(event.data.message);
    }else if(event.data.direction=="shutDownLaunchSocketApp"){
        shutDownLaunchSocketApp(event.data.message);
    }
}
//Functions which connect to extension background-script.js

function launchClientSystem(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "launchClient"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}

function launchServerSystem(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "launchServer"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}

function closeServerSystem(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "closeServer"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}

function shutDownScanner(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "shutDownScanner"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}

function goIdleStateScanner(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "goIdleStateScanner"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}

function checkingClientServerSystem(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "checkingClientServerSystem"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}

function connectingScanner(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "connectingScanner"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}

function scanningProcessing(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "scanning"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}

function chuckOfInformation(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "chuckOfInformation"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}
function shutDownLaunchSocketApp(extensionId){
    var sending = browser.runtime.sendMessage(extensionId, {connecting: "shutDownLaunchSocketApp"});
    sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
}


//Send response to ConnectingToBackgroundFirefox.js

function handleResponse(response) {

    //console.log("handleResponse");
    //console.log(response);

    window.postMessage({
        direction: "handleResponse",
        message: response.connected
    }, "*");
}

function handleError(error) {

    //console.log("handleError");
    //console.log(error);

    window.postMessage({
        direction: "handleError",
        message: error.error
    }, "*");
}
