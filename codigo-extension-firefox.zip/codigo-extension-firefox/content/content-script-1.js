
//Receive message from ConnectingToBackgroundFirefox.js

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "launchClientSystem") {
        
            window.removeEventListener("message", event_rep_res)
            launchClientSystem(event.data.message);
    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "launchServerSystem") {
        
            window.removeEventListener("message", event_rep_res)
            launchServerSystem(event.data.message);
    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "closeServerSystem") {
        
            window.removeEventListener("message", event_rep_res)
            closeServerSystem(event.data.message);

    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "shutDownScanner") {
        
            window.removeEventListener("message", event_rep_res)
            shutDownScanner(event.data.message);
    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "goIdleStateScanner") {
        
            window.removeEventListener("message", event_rep_res)
            goIdleStateScanner(event.data.message);
    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "checkingClientServerSystem") {
        
            window.removeEventListener("message", event_rep_res)
            checkingClientServerSystem(event.data.message);
    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "connectingScanner") {

            window.removeEventListener("message", event_rep_res)
            connectingScanner(event.data.message);
    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "scanningProcessing") {

            window.removeEventListener("message", event_rep_res)
            scanningProcessing(event.data.message);
    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "chuckOfInformation") {
        
            window.removeEventListener("message", event_rep_res)
            chuckOfInformation(event.data.message);
    }
}, false);

var event_rep_res = window.addEventListener("message", (event) => {
    if (event.source == window &&
        event.data &&
        event.data.direction == "shutDownLaunchSocketApp") {
        
            window.removeEventListener("message", event_rep_res)
            shutDownLaunchSocketApp(event.data.message);
    }
}, false);

//Functions which connect to extension background-script.js

function launchClientSystem(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "launchClient"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}

function launchServerSystem(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "launchServer"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}

function closeServerSystem(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "closeServer"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}

function shutDownScanner(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "shutDownScanner"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}

function goIdleStateScanner(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "goIdleStateScanner"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}

function checkingClientServerSystem(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "checkingClientServerSystem"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}

function connectingScanner(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "connectingScanner"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}

function scanningProcessing(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "scanning"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}

function chuckOfInformation(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "chuckOfInformation"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}
function shutDownLaunchSocketApp(extensionId){
    return new Promise(function(resolve,reject){
        var sending = browser.runtime.sendMessage(extensionId, {connecting: "shutDownLaunchSocketApp"});
        sending.then((response) => {handleResponse(response)}).catch((response) => {handleError(response)});
    });
}


//Send response to ConnectingToBackgroundFirefox.js

function handleResponse(response) {

    console.log("handleResponse");
    console.log(response);

    window.postMessage({
        direction: "handleResponse",
        message: response.connected
    }, "*");
}

function handleError(error) {

    console.log("handleError");
    console.log(error);

    window.postMessage({
        direction: "handleError",
        message: error.error
    }, "*");
}
