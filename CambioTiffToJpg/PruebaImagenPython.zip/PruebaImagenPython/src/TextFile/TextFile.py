'''
Created on Mar 1, 2021

@author: c.querales.salas
'''

class TextFile(object):

    def __init__(self):
        self
    
    @staticmethod
    def createTextFile(fullPath,result):
        open(fullPath,"w+").close() 
        file= open(fullPath,"a+")
        file.write(result)
    
    @staticmethod
    def readTextFile(fullPath):
        file=open(fullPath,"r")
        return file.read()
        