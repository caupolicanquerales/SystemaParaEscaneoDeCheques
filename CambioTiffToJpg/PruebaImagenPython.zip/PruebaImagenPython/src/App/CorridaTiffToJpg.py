'''
Created on Mar 1, 2021

@author: c.querales.salas
'''

import os
import traceback
import base64
from PIL import Image
from TextFile.TextFile import TextFile

try:
    path=str(os.getcwdb())[1::]
    fullPath=path[:-1:][0:0:]+path[:-1:][1::]
    imageFileTiff=fullPath+"\\\imageT.tiff"
    imageFileJpg = fullPath+ "\\\imageJ.jpg"
except Exception:
    traceback.print_exc()

def convertBase64ToTiff():
    pathFileText = fullPath+"\\\imgF.txt"
    imageBase64= TextFile.readTextFile(pathFileText)
    bytes_base64= imageBase64.encode()
    data = base64.b64decode(bytes_base64)
    open(imageFileTiff, 'wb').write(data)

def convertTiffToJpg():
    im = Image.open(imageFileTiff)
    im.save(imageFileJpg)
    
def convertJpgToBase64():
    data = open(imageFileJpg, 'rb').read()
    bytes_base64 = base64.b64encode(data)
    text_base64 = bytes_base64.decode()
    pathFileText = fullPath+"\\\imgResultante.txt"
    TextFile.createTextFile(pathFileText, text_base64)
    
def main():
    convertBase64ToTiff()
    convertTiffToJpg()
    convertJpgToBase64()

if __name__ == '__main__':
    main()